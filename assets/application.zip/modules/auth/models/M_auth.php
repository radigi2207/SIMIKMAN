<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_auth extends CI_Model {

function cek_user($data)
{
    return $this->db->where('username', $data['username'])
                    ->where('active',1)
                    ->get('tb_users');
}
function set_cookie($data,$id)
{
    $this->db->where('id', $id);
    $this->db->update('tb_users', $data);
    return $this->db->affected_rows();
    
}

function logout($id)
{
    $data = array('remember_code' => null );
    $this->db->where('id', $id);
    $this->db->update('tb_users', $data);
    return $this->db->affected_rows();
    
}

function cek_session()
{

    if($this->session->userdata('login'))
    {
        return true;
    }
    else
        redirect(site_url());
}

    

}

/* End of file M_auth.php */
?>