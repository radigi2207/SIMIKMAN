<?
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model(array('M_auth'));
        $this->load->helper('security');
    }

    public function index()
    {
        if(empty($this->session->userdata('login')))
        {
            $post = $this->input->post();
            $remember = (isset($post['remember'])) ? true : false ;
            if(!empty($post))
            {
                $user = $this->M_auth->cek_user($post);
                if($user->num_rows() == 1)
                {
                    $user = $this->M_auth->cek_user($post)->row();
                    if(password_verify($post['password'],$user->password))
                    {
                        $session = array('login'    => true,
                                        'username' => $user->username,
                                        'id'       => $user->id,
                                        'people'   =>  $user->first_name." ". $user->last_name,
                                        'inisial'  =>  $user->inisial);            
                        $this->session->set_userdata($session);
                        if($remember)
                        {
                            $val = random_string('sha1', 16);
                            $cookie = array('name'   => 'auth',
                                            'value'  => $val,
                                            'expire' => 24 *3600,
                                            'path'   => '/',
                            );
                            set_cookie($cookie);
                            $this->M_auth->set_cookie(array('remember_code' => $val,
                                                            'last_login'    => now(),
                                                            'ip_address'    => $this->input->ip_address()),$user->id);
                        }
                        redirect(site_url('#dasbord'));
                        return;
                    }
                    else
                    {                    
                        $data['msg']    = $this->lang->line('login_invalid_username_and_password');
                        $this->session->set_flashdata('login_faild',$data);
                    }
                }
                else
                {                    
                    $data['msg']    = $this->lang->line('login_invalid_username_and_password');
                    $this->session->set_flashdata('login_faild',$data);
                }    
                
            }
            $this->load->view('login');
            return;
        }
        else
        {
            redirect(site_url('#dasbord'));
            return;
        }
    }
    function logout()
    {       
        $this->session->sess_destroy();
        delete_cookie('auth');
        // $id = $this->session->userdata('id');
        // $this->M_auth->logout($id);
        redirect(site_url('auth'));
    }

    private function cookies()
    {

    }

    function blank($x=null)
    {
        $plain_text = 25;
        $ciphertext = encode_url(25);
        // Outputs: This is a plain-text message!
        //echo $ciphertext;
        //echo decode_url($x,'edit');
        echo urldecode($x);
    }

    function cek_session()
    {
        echo json_encode($this->session->userdata('login'));
    }
    


}

/* End of file Auth.php */
?>