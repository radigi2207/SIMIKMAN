<?php

//initilize the page
//require_once("inc/init.php");

//require UI configuration (nav, ribbon, etc.)
//require_once("inc/config.ui.php");

/*---------------- PHP Custom Scripts ---------

YOU CAN SET CONFIGURATION VARIABLES HERE BEFORE IT GOES TO NAV, RIBBON, ETC.
E.G. $page_title = "Custom Title" */

$page_title = "Login";

/* ---------------- END PHP Custom Scripts ------------- */

//include header
//you can add your custom css in $page_css array.
//Note: all css files are inside css/ folder

$data['page_title'] = "";
$data['no_main_header'] = false; //set true for lock.php and login.php
$data['page_body_prop'] = array(); //optional properties for <body>
$data['page_html_prop'] = array(); //optional properties for <html>
$data['no_main_header'] = true;
$data['page_body_prop'] = array("id"=>"extr-page", "class"=>"animated fadeInDown");

$this->load->view('header',$data,FALSE);

?>
<!-- ==========================CONTENT STARTS HERE ========================== -->
<!-- possible classes: minified, no-right-panel, fixed-ribbon, fixed-header, fixed-width-->


<div id="main" role="main">
	<!-- MAIN CONTENT -->
	<div id="content" class="container">
		<div class="row">
			<div class="col-lg-2 col-lg-offset-5">
				<center><img src="<?=base_url('assets/img/logo.png')?>" height="148px;"></center>
			</div>
		</div>
		<div class="row">
			<!--<div class="col-xs-12 col-sm-12 col-md-7 col-lg-8 hidden-xs hidden-sm">
				<?
				$this->load->helper('directory');
				$map = directory_map('./assets/img/realestate', TRUE, TRUE);
				$items = array();
				foreach($map as $row)
				{
					array_push($items,base_url('assets/img/realestate/'.$row));
				}
				//$this->smartadmin->nav($this->session->userdata('id'));
				$carousel = $this->smartadmin->create_carousel($items);
				$carousel->options('style', 'fade') 
						->print_html();
				?>
			</div>-->
			<div class="col-xs-10 col-xs-offset-1 col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4 col-lg-4 col-lg-offset-4">
				<div class="well no-padding">
					<form method="post" id="login-form" class="smart-form client-form">
						<header>
							Sign In
						</header>
						<?
						if(!empty($this->session->flashdata('login_faild'))):
							$msg = $this->session->flashdata('login_faild');
						?>
						<div class="alert alert-danger fade in no-margin-bottom" style="margin-bottom:0">
							<button class="close" data-dismiss="alert">
								×
							</button>
							<i class="fa-fw fa fa-times"></i>
							<strong>Error!</strong> <?=$msg['msg']?>
						</div>
						<?
						endif;
						?>
						<fieldset>
							
							<section>
								<label class="label">E-mail</label>
								<label class="input"> <i class="icon-append fa fa-user"></i>
									<input type="text" autocomplete="off" name="username" placeholder="Masukan alamat E-mail">
								</label>
							</section>

							<section>
								<label class="label">Password</label>
								<label class="input"> <i class="icon-append fa fa-lock"></i>
									<input type="password" name="password" placeholder="Masukan Password">
									</label>
								<div class="note hidden">
									<a href="<?=site_url('forgotpassword')?>">Lupa password?</a>
								</div>
							</section>

							<section class="hidden">
								<label class="checkbox">
									<input type="checkbox" name="remember">
									<i></i>Tetap Masuk</label>
							</section>
						</fieldset>
						<footer>
							<button type="submit" class="btn btn-primary">
								Sign in
							</button>
						</footer>
					</form>

				</div>
				
				
				
			</div>
		</div>
	</div>

</div>
<!-- END MAIN PANEL -->
<!-- ==========================CONTENT ENDS HERE ========================== -->

<?php 
	//include required scripts
	$this->load->view('script');
?>

<!-- PAGE RELATED PLUGIN(S) 
<script src="..."></script>-->

<script type="text/javascript">
	runAllForms();
	$(function() {
		// Validation
		$("#login-form").validate({
			// Rules for form validation
			rules : {
				username : {
					required : true
				},
				password : {
					required : true,
					minlength : 3,
					maxlength : 20
				}
			},

			// Messages for form validation
			messages : {
				username : {
					required : '<?=$this->lang->line('employees_username_required')?>'
				},
				password : {
					required : '<?=$this->lang->line('employees_password_required')?>'
				}
			},

			// Do not change code below
			errorPlacement : function(error, element) {
				error.insertAfter(element.parent());
			}
		});
	});
</script>