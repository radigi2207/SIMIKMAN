<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modal extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model(array('gudang/M_gudang','transaksi/M_transaksi'));
        $this->load->model('karyawan/karyawan_model','M_user');
    }

    function new_produk($kode_item = null)
    {
        
        $field = array();
        $item = $this->M_gudang->get_item($kode_item);
        $row_field = $item->list_fields();
        if($kode_item == null)
        {
            
            for($i=0; $i < count($row_field);$i++)
            {
                $field[$row_field[$i]] = null;
            }
        }
        else
        {
            $field = $item->result_array()[0];
        }
        $data['item'] = $field;
        $data['kategori'] = $this->M_gudang->list_kategori();
        $this->load->view('new_produk', $data, FALSE);
    }

    function new_kategori()
    {
        $this->load->view('new_kategori',[], FALSE);
    }

    function new_member($id= null)
    {
        $member = $this->M_user->get_member($id);
        $field = array();
        $row_field = $member->list_fields();
        if($id == null)
        {
            for($i=0; $i < count($row_field);$i++)
            {
                $field[$row_field[$i]] = null;
            }
        }
        else
        {
            $field = $member->result_array()[0];
        }
        $data['member'] = $field;
        $this->load->view('new_member',$data, FALSE);
    }

    function bayar($faktur = null)
    {
        (!$this->input->is_ajax_request() || $faktur == null)?show_404():true;

        $data['cart']       = $this->M_transaksi->get_all_cart($faktur);
        $data['faktur']     = $this->M_transaksi->get_faktur($faktur)->row();
        $this->load->view('bayar', $data, FALSE);
    }

    function setor($id)
    {
        //(!$this->input->is_ajax_request())? show_404(): true;
        $new_id = intval(decode_url($id,'setor'));
        if(is_int($new_id) && $new_id != 0)
        {
            $data['setor'] = $this->M_transaksi->detail_setor($new_id)->row();
            $this->load->view('setor', $data, FALSE);
        }
        else
        {
            $new_id = intval(decode_url($id,'konfirmasi'));
            if(is_int($new_id) && $new_id != 0)
            {
                $data['setor'] = $this->M_transaksi->detail_setor($new_id)->row();
                $this->load->view('konfirmasi_setor', $data, FALSE);
            }
        }      
        
    }
    

}

/* End of file Modal.php */
?>