<div class="modal-header"> <i class="fa fa-plus" aria-hidden="true"></i> Kategri Baru</div> 
<form action="<?=site_url('new_kategori')?>" id="new_kategori" method='post' novalidate="novalidate" enctype="multipart/form-data">
<div class="modal-body no-padding smart-form">
    <fieldset>
        <section>
            <label for="nama_kategori" class="input">
                <input type="text" name="nama_kategori" placeholder="Nama Kategori" maxlength="50" autocomplete="off">
            </label>
        </section>
        <section>
            <label class="textarea"> 										
                <textarea rows="3" name="ket" placeholder="Keterangan"></textarea> 
            </label>
        </section>
    </fieldset>
    <footer>
        <button type="button" class="btn btn-danger" data-dismiss="modal" id="close_modal">
           <i class="fa fa-close"></i> Keluar
        </button>
        <button type="submit" class="btn btn-primary">
           <i class="fa fa-save"></i> Simpan
        </button>
    </footer>
</div>
</form>
<script type="text/javascript">
pageSetUp();
var pagefunction = function(){
    var new_kategori = $("#new_kategori").validate({
        // Rules for form validation
        rules : {
            
            nama_kategori : {
                required : true
            }
        },

        // Messages for form validation
        messages : {
            nama_kategori : {
                required : 'Silahkan masukan nama kategori'
            }
        },

        // Ajax form submition
        submitHandler : function(form) {
            $(form).ajaxSubmit({
                dataType:'json',
                success : function(data) {
                    if(data.code == 200)
                    {
                        var color = "#739E73";
                        var time  = 3000;
                    }
                    else
                    {
                        var color = "#C46A69";
                        var time  = 6000;
                    }
                    $.smallBox({
                        title : ""+$("input[name=nama_kategori]").val()+"",
                        content : "<i>"+data.msg+"</i>",
                        color : color,
                        iconSmall : "fa fa-tags bounce animated",
                        timeout : time
                    });
                    $("#new_kategori").resetForm();

                }
            });
        },

        // Do not change code below
        errorPlacement : function(error, element) {
            error.insertAfter(element.parent());
        }
    });
};
loadScript("<?=base_url("assets/js/plugin/jquery-form/jquery-form.min.js")?>", pagefunction);
</script>