<div class="modal-header"> <i class="fa fa-plus" aria-hidden="true"></i> Produk Baru</div>  
<div class="modal-body no-padding">
    <div class='row'>        
        <section class='col col-lg-12'>
            <fieldset>
                
            </fieldset>
            <fieldset class='no-padding'>
                <table class='table table-hover table-striped'>
                    <thead>
                        <tr>
                            <th>Nama Barang</th>
                            <th class='text-right'>Harga</th>
                            <th class='text-right'>Qty</th>
                            <th class='text-right'>Diskon</th>
                            <th class='text-right'>Jumlah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?
                        $td = 0;
                        $total = 0;
                        foreach($cart->result_array() as $row):?>
                        <tr>
                            <?
                            $diskon = ($row['harga'] * $row['qty'])* $row['diskon']/100;
                            $td += $diskon;
                            ?>
                            <td><?=$row['nama_item']?></td>
                            <td class='text-right'><?=number_format($row['harga'],0,',','.')?></td>
                            <td class='text-right'><?=$row['qty']?></td>
                            <td class='text-right'><?=number_format($diskon,0,',','.')?></td>
                            <td class='text-right'><?
                            $jml = ($row['harga'] * $row['qty']);
                            $total += $jml;
                            echo number_format($jml,0,',','.');
                            ?></td>
                        </tr>
                        <?endforeach;?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan='4' class='text-right'>JUMLAH:</td>
                            <td class='text-right'><?=number_format($total,0,',','.')?></td>
                        </tr>
                        <tr>
                            <td colspan='4' class='text-right'>DISKON :</td>
                            <td class='text-right'><?=number_format($td,0,',','.')?></td>
                        </tr>
                        <tr>
                            <td colspan='4' class='text-right'>TOTAL :</td>
                            <td class='text-right'><?=number_format($total-$td,0,',','.')?></td>
                        </tr>
                        <tr>
                            <td colspan='4' class='text-right'>UANG MUKA :</td>
                            <td class='text-right'><?=number_format($faktur->total_bayar,0,',','.')?></td>
                        </tr>
                        <tr>
                            <td colspan='4' class='text-right'>SISA BAYAR :</td>
                            <td class='text-right'><?=number_format($total-$td - $faktur->total_bayar,0,',','.')?></td>
                        </tr>
                    </tfoot>
                </table>
            </fieldset>
            <fieldset class="padding-10">
                <p>Catatan :</p>
                <blockquote>
                    <p><?=(strlen($faktur->ket) > 0)? $faktur->ket:'-'?></p>
                    
                </blockquote>
            </fieldset>
    <form action="<?=site_url('transaksi/bayar')?>"  id="bayar" method='post' class="smart-form" novalidate="novalidate">
            <input type="hidden" name="faktur" value="<?=$faktur->kode_faktur?>">
            <input type="hidden" name="sb" value="<?=$total-$td - $faktur->total_bayar?>">
            <fieldset class="npt">
                <label class="input"> <i class="icon-prepend input-lg fa fa-money"></i>
                    <input type="text" class="text-right input-lg" maxlength="13" name="bayar" placeholder="0,00" autocomplete="off" style="text-align: right;">
                    <b class="tooltip tooltip-top-right font-sm">Masukan Nominal Pembayaran</b>
                </label>
            </fieldset>
            <footer>
                    
                <button type="button" class="btn btn-danger" data-dismiss="modal" id="close_modal">
                <i class="fa fa-close"></i> Batal
                </button>
                <button type="submit" id='simpan' class="btn btn-primary">
                <i class="fa fa-money"></i> Bayar
                </button>
            </footer>
        </section>
    </div>
    </form>
</div>
<style>
table tfoot{
    font-weight:bold;
}
</style>
<script type="text/javascript">

pageSetUp();
var pagefunction = function(){
    $("input[name=bayar]").inputmask("decimal",{
        radixPoint:",", 
        groupSeparator: ".", 
        digits: 0,
        autoGroup: true,
        removeMaskOnSubmit:true
	});
    var bayar = $("#bayar").validate({
        rules : {            
            bayar : {
                required : true
            }
        },

        messages : {
            bayar : {
                required : ''
            }
        },

        // Ajax form submition
        submitHandler : function(form) {
            $(form).ajaxSubmit({
                dataType:'json',
                success : function(data) {
                    if(data.code)
                    {
                        var color = "#739E73";
                        var time  = 3000;
                    }
                    else
                    {
                        var color = "#C46A69";
                        var time  = 6000;
                    }
                    $.smallBox({
                        title : "Pembayaran Tagihan",
                        content : "<i>"+data.msg+"</i>",
                        color : color,
                        iconSmall : "fa fa-shopping-cart bounce animated",
                        timeout : time
                    });
                    $('a#refresh').click();
                   
                }
            });
        },

        // Do not change code below
        errorPlacement : function(error, element) {
            error.insertAfter(element.parent());
        }
    });
};
loadScript("<?=base_url("assets/js/plugin/jquery-form/jquery-form.min.js")?>", pagefunction);

</script>