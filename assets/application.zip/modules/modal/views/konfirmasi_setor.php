<div class="modal-header"> <i class="fa fa-arrow-down" aria-hidden="true"></i> Setor Kasir</div>  
<div class="modal-body no-padding">
    <div class='row'>        
        <section class='col col-lg-12'>
            <fieldset>
                
            </fieldset>
            <fieldset class='no-padding'>
                <div class="col-sm-12">
                    <br>
                    <div>
                        <div class="font-md">
                            <strong>Kasir:</strong>
                            <span class="pull-right"> <i class="fa fa-user"></i> <?=$setor->name?> </span>
                        </div>
                    </div>
                    <div>
                        <div class="font-md">
                            <strong>Tanggal Pendapatan:</strong>
                            <span class="pull-right"> <i class="fa fa-calendar"></i> <?=$setor->tgl?> </span>
                        </div>
                    </div>
                    <br>
                    <div class="well well-sm  bg-color-darken txt-color-white no-border">
                        <div class="fa-lg">
                            Total Pendapatan :
                            <span class="pull-right"> Rp. <?=number_format($setor->pendapatan,0,',','.')?> </span>
                        </div>

                    </div>
                    </br>

                </div>
            </fieldset>
    <form action="<?=site_url('transaksi/konfirmasi_setor/'.encode_url($setor->id,'konfirmasi'))?>" method='post' id="konfirmasi" class="smart-form">
            <fieldset class="npt">
                <section>
                    <label class="textarea"> 										
                        <textarea rows="3" name="ket_status" placeholder="Catatan"></textarea> 
                    </label>
                </section>
            </fieldset>
            <footer>
                
                <button type="button" class="btn btn-danger" data-dismiss="modal" id="close_modal">
                <i class="fa fa-close"></i> Batal
                </button>
                <button type="submit" id='simpan' class="btn btn-primary">
                <i class="fa fa-money"></i> Konfirmasi
                </button>
            </footer>
        </section>
    </div>
    </form>
</div>
<style>
table tfoot{
    font-weight:bold;
}
</style>
<script type="text/javascript">

pageSetUp();

var pagefunction = function(){
    var bayar = $("#konfirmasi").validate({
        submitHandler : function(form) {
            $(form).ajaxSubmit({
                dataType:'json',
                success : function(data) {
                    if(data.code)
                    {
                        var color = "#739E73";
                        var time  = 3000;
                    }
                    else
                    {
                        var color = "#C46A69";
                        var time  = 6000;
                    }
                    $.smallBox({
                        title : "Pembayaran Tagihan",
                        content : "<i>"+data.msg+"</i>",
                        color : color,
                        iconSmall : "fa fa-shopping-cart bounce animated",
                        timeout : time
                    });
                    $('a#refresh').click();
                   
                }
            });
        },

        // Do not change code below
        errorPlacement : function(error, element) {
            error.insertAfter(element.parent());
        }
    });
};
loadScript("<?=base_url("assets/js/plugin/jquery-form/jquery-form.min.js")?>", pagefunction);


</script>