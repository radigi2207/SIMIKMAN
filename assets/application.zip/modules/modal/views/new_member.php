<div class="modal-header"> <i class="fa fa-user-plus" aria-hidden="true"></i> Member baru</div> 
<form <?=($member['id'] != null)? "action='".site_url('edit_member')."'":"action='".site_url('new_member')."'"?> id="new_member" class="smart-form" method='get' novalidate="novalidate" enctype="multipart/form-data">
<div class="modal-body no-padding ">
    <div class="alert alert-block alert-success nmb">
        <a class="close" data-dismiss="alert" href="#">×</a>
        <h4 class="alert-heading"><i class="fa fa-check-square-o"></i> 
        Member baru</h4>
        <p>
            Silahkan masukan data dengan benar dan sesuai dengan kartu identitas!
        </p>
    </div>
    <fieldset>
        <div class="row">
            <section class="col col-6">
                <label for="id" class="input">
                    <input type="text" name="id" value='<?=$member['id']?>' <?=($member['id'] != null)? "readonly":""?>  placeholder="ID Pelanggan" maxlength="50" autocomplete="off">
                </label>
            </section>
            <section class="col col-6">
                <label for="no_identitas" class="input"> 										
                    <input type="text" value='<?=$member['no_identitas']?>' name="no_identitas" placeholder="Nomor kartu identitas">
                </label>
            </section>
        </div>
        <section>
            <label for="nama" class="input">
                <input type="text" name="nama" value='<?=$member['nama']?>' placeholder="Nama Pelanggan" autocomplete="off">
            </label>
        </section>
        <div class="row">
            <section class="col col-6">
                <label for="tgl_lahir" class="input"> 										
                    <input type="text" name="tgl_lahir" value='<?=$member['tgl_lahir']?>' placeholder="Tgl. Lahir">
                </label>
            </section>
            <section class="col col-6">
                <label for="no_hp" class="input"> 										
                    <input type="text" name="no_hp" value='<?=$member['no_hp']?>' placeholder="Telpon / HP">
                </label>
            </section>
        </div>
        <section>
            <label for="alamat" class="textarea">
                <textarea type="text" rows="3"  name="alamat" placeholder="Alamat Lengkap" maxlength="50" autocomplete="off"><?=$member['alamat']?></textarea>
            </label>
        </section>
    </fieldset>
    <footer>
        <button type="button" class="btn btn-danger" data-dismiss="modal" id="close_modal">
           <i class="fa fa-close"></i> Keluar
        </button>
        <button type="submit" class="btn btn-primary">
           <i class="fa fa-save"></i> Simpan
        </button>
        
    </footer>
</div>
</form>
<script type="text/javascript">
pageSetUp();
var pagefunction = function(){
    $("input[name=id]").inputmask({
        mask: ["999-9-999-999"],
        placeholder: "X",
        showTooltip: true,
        removeMaskOnSubmit:true 
    });
    $("input[name=no_identitas]").inputmask({
        mask: ["9999-9999-9999-9999-9999"],
        placeholder: "X",
        showTooltip: true,
        removeMaskOnSubmit:true 
    });

    $("input[name=no_hp]").inputmask({
        mask: ["(9999)-9999-9999"],
        placeholder: "X",
        showTooltip: true,
        removeMaskOnSubmit:true 
    });

    $('input[name=tgl_lahir]').datepicker({
        dateFormat : 'yy-mm-dd',
        prevText : '<i class="fa fa-chevron-left"></i>',
        nextText : '<i class="fa fa-chevron-right"></i>',
        defaultDate:"1991-07-22",
        changeMonth:true,
        changeYear:true
    });
    var new_kategori = $("#new_member").validate({
        // Rules for form validation
        rules : {
            id:{
                required:true
            },
            no_identitas:{
                required:true
            },
            nama:{
                required:true,
                minlength: 3,
                maxlength: 50
            },
            no_hp:{
                required : true
            },
            tgl_lahir : {
                required : true,
                date:true
            }
        },

        // Messages for form validation
        messages : {
            id:{
                required:'silahkan masukan no id pelanggan'
            },
            no_identitas:{
                required:'silahkan masukan nomor identitas'
            },
            nama:{
                required:'silahkan masukan nama lengkap',
                minlength: 'nama diperbolehkan minimal 3 karakter atau lebih',
                maxlength: 'nama maksimal 50 karakter atau kurang',
            },
            tgl_lahir : {
                required : 'silahkan masukan tgl. Lahir',
                date : 'Format tanggal YYYY-MM-DD'
            },
            no_hp:{
                required : 'silahkan masukan no Tlp. / HP'
            }
        },

        // Ajax form submition
        submitHandler : function(form) {
            $(form).ajaxSubmit({
                dataType:'json',
                success : function(data) {
                    if(data.code == 200)
                    {
                        var color = "#739E73";
                        var time  = 3000;
                    }
                    else
                    {
                        var color = "#C46A69";
                        var time  = 6000;
                    }
                    $.smallBox({
                        title : "",
                        content : "<i>"+data.msg+"</i>",
                        color : color,
                        iconSmall : "fa fa-user-plus bounce animated",
                        timeout : time
                    });
                    $("#close_modal").click();
                    $("#new_member").resetForm();
                    


                }
            });
        },

        // Do not change code below
        errorPlacement : function(error, element) {
            error.insertAfter(element.parent());
        }
    });
};
loadScript("<?=base_url("assets/js/plugin/jquery-form/jquery-form.min.js")?>", pagefunction);
</script>