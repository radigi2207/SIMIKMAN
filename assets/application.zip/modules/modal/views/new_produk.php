<div class="modal-header"> <i class="fa fa-plus" aria-hidden="true"></i> Produk Baru</div>  
<div class="modal-body no-padding">
    <form <?=($item['kode_item'] != null)? "action='".site_url('edit_produk')."'":"action='".site_url('new_produk')."'"?>  id="new_produk" method='post' class="smart-form" novalidate="novalidate" enctype="multipart/form-data">
    <div class='row'>
        
        <section class='col col-lg-12'>
                <fieldset>
                    <div class="alert alert-block alert-info">
                        <h4 class="alert-heading"><i class="fa fa-check-square-o"></i> Form Produk Baru!</h4>
                        <p>
                            Silahkan masukan data produk baru!
                        </p>
                    </div>
                    <div class="row">
                        <section class="col col-6">
                            <label class="input"> <i class="icon-prepend fa fa-barcode"></i>
                                <input <?=($item['kode_item'] != null)? "readonly":""?> value="<?=$item['kode_item']?>" autocomplete="off" type="text" maxlength='13' minlength='10' name="kode_item" placeholder="Kode Produk" >
                            </label>
                        </section>
                    </div>

                    <div class="row">
                        <section class="col col-6">
                            <label class="input"> <i class="icon-prepend fa fa-qrcode"></i>
                                <input type="text" value="<?=$item['nama_item']?>" name="nama_item" placeholder="Nama Produk">
                            </label>
                        </section>
                        <section class="col col-6">
                            <label class="select">
                                <select name='kategori'>
                                    <option selected disabled>pilih kategori</option>
                                <?foreach($kategori->result_array() as $row):?>
                                    <option value='<?=$row['id']?>' <?=($item['kategori'] == $row['id']) ? 'selected':''?>><?=$row['nama_kategori']?></option>
                                <?endforeach;?>
                                </select>
                            </label>
                        </section>
                    </div>
                    <div class="row">
                        <section class="col col-6">
                            <label class="input"> <i class="icon-prepend fa fa-money"></i>
                                <input type="text" value="<?=$item['harga_produk']?>" class="text-right" maxlength='13' name="harga_produk" placeholder="Harga Produksi">
                            </label>
                        </section>
                        <section class="col col-6">
                            <label class="input"> <i class="icon-prepend fa fa-cart-plus"></i>
                                <input type="text" value="<?=$item['harga_jual']?>" class="text-right" maxlength='13' name="harga_jual" placeholder="Harga Jual">
                            </label>
                        </section>
                    </div>
                    <section>
                        <label for="file" class="input input-file">
                            <div class="button"><input type="file" name="file" onchange="this.parentNode.nextSibling.value = this.value">Browse</div><input type="text" placeholder="Pilih file gambar" readonly="">
                        </label>
                    </section>
                    
                </fieldset>

                <fieldset>
                    <div class="row">
                        <section class="col col-4">
                            <label class="input"> <i class="icon-prepend fa fa-percent"></i>
                                <input type="number" value="<?=$item['diskon']?>" autocomplete="off" class="text-right" name="diskon" placeholder="Diskon">
                            </label>
                        </section>
                        <section class="col col-4">
                            <label class="input"> <i class="icon-append fa fa-calendar"></i>
                                <input type="text" value="<?=$item['start_diskon']?>" name="start_diskon" readonly id="startdate" placeholder="Mulai Periode Diskon">
                            </label>
                        </section>
                        <section class="col col-4">
                            <label class="input"> <i class="icon-append fa fa-calendar"></i>
                                <input type="text" name="finish_diskon" value="<?=$item['finish_diskon']?>" readonly id="finishdate" placeholder="Akhir Periode Diskon">
                            </label>
                        </section>
                    </div>
                    <div class='row'>
                        <section class="col col-6">
                            <label class="checkbox">
                                <input type="checkbox" name="stok" <?=($item['stok'] == null && $item['kode_item'] != null)?'checked':''?>>
                                <i></i>Stok selalu tersedia</label>
                        </section>
                        <section class="col col-6">
                            <label class="input"> <i class="icon-prepend fa fa-cubes"></i>
                                <input value="<?=$item['stok']?>" type="number" class='text-right' name="limit_stok" placeholder="Stok Produk">
                            </label>
                        </section>
                    </div>
                </fieldset>

                <footer>
                    
                    <button type="button" class="btn btn-danger" data-dismiss="modal" id="close_modal">
                    <i class="fa fa-close"></i> Keluar
                    </button>
                    <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i> Simpan
                    </button>
                </footer>
            
        </section>
    </div>
    <?=($item['thumbs'] != null)? "<input type='hidden' name='thumb' value='".$item['thumbs']."'>":''?>
    
    </form>
</div>
<script type="text/javascript">
pageSetUp();
var pagefunction = function(){

    $("input[name=harga_produk],input[name=harga_jual]").inputmask("decimal",{
        radixPoint:",", 
        groupSeparator: ".",
        digits: 0,
        autoGroup: true,
        removeMaskOnSubmit:true
	});

    $('#startdate').datepicker({
        dateFormat : 'yy-mm-dd',
        prevText : '<i class="fa fa-chevron-left"></i>',
        nextText : '<i class="fa fa-chevron-right"></i>',
        onSelect : function(selectedDate) {
            $('#finishdate').datepicker('option', 'minDate', selectedDate);
        }
    });
    
    $('#finishdate').datepicker({
        dateFormat : 'yy-mm-dd',
        prevText : '<i class="fa fa-chevron-left"></i>',
        nextText : '<i class="fa fa-chevron-right"></i>',
        onSelect : function(selectedDate) {
            $('#startdate').datepicker('option', 'maxDate', selectedDate);
        }
    });

    var new_produk = $("#new_produk").validate({
        // Rules for form validation
        rules : {
            kode_item : {
                required : true,
                minlength : 10,
                maxlength : 13
            },
            nama_item : {
                required : true
            },
            kategori : {
                required : true
            },
            harga_produk: {
                required : true
            },
            harga_jual:{
                required :true
            },
            diskon:{
                min : 1,
                max : 100
            }
        },

        // Messages for form validation
        messages : {
            kode_item : {
                required : 'Silahkan masukan kode produk'
            },
            nama_item : {
                required : 'Silahkan masukan nama produk'
            },
            kategori : {
                required : 'Silahkan pilih kategori'
            },
            harga_produk : {
                required : 'Silahkan masukan harga produksi'
            },
            harga_jual : {
                required : 'Silahkan masukan harga jual'
            },
            diskon:{
                min: 'minimal 1 %',
                max: 'maksimal 100%'
            }
        },

        // Ajax form submition
        submitHandler : function(form) {
            $(form).ajaxSubmit({
                dataType:'json',
                success : function(data) {
                    var kode = $("input[name=kode_item]").val();
                    if(data.code == 200)
                    {
                        var color = "#739E73";
                        var time  = 3000;
                        <?=($item['kode_item'] == null)? '$("#new_produk").resetForm();': '$("span#refresh").click();'?>
                        
                    }
                    else
                    {
                        var color = "#C46A69";
                        var time  = 6000;
                    }
                    $.smallBox({
                        title : "["+kode+"] "+ $("input[name=nama_item]").val(),
                        content : "<i>"+data.msg+"</i>",
                        color : color,
                        iconSmall : "fa fa-cubes bounce animated",
                        timeout : time
                    });
                    
                }
            });
        },

        // Do not change code below
        errorPlacement : function(error, element) {
            error.insertAfter(element.parent());
        }
    });
};
// function search_produk(v)
// {
//     $.ajax({
//         url:"<?=site_url('gudang/search_produk_key')?>",
//         type:"post",
//         dataType:"json",
//         data:{kode_item:v},
//         success : function(data){
//             if(data != null)
//             {
//                 $.SmartMessageBox({
//                     title : "["+data.kode_item+"] "+ data.nama_item,
//                     content : "Produk dengan kode item <strong>["+data.kode_item+"]</strong> telh tersedia </br> apakah anda akan mengubahnya?",
//                     buttons : '[Tidak][Ya]'
//                 }, function(ButtonPressed) {
//                     if (ButtonPressed === "Ya") {
//                         $("input[name=nama_item]").val(data.nama_item);
//                         $("input[name=harga_produk]").val(data.harga_produk);
//                         $("input[name=harga_jual]").val(data.harga_jual);
//                         $("input[name=diskon]").val(data.diskon);
//                         $("select[name=kategori]").val(data.kategori);
//                         $("input[name=start_diskon]").val(data.start_diskon);
//                         $("input[name=finish_diskon]").val(data.finish_diskon);
//                         if(data.stok == null)
//                         {
//                             $("input[name=stok]").attr("checked",true);
//                         }
//                         else
//                         {
//                             $("input[name=stok]").attr("checked",false);
//                             $("input[name=limit_stok]").val(data.stok);
//                         }
//                         var form = $("#new_produk");
//                         form.attr('action','<?=site_url('edit_produk')?>');
//                         $("input[name=kode_item]").attr("readonly","readonly");

//                         if($("input[name=thumb]").length == 0)
//                             form.append("<input type='hidden' name='thumb' value='"+data.thumbs+"'>");
//                         else
//                             $("input[name=thumb]").val(data.thumbs);
//                     }
//                     if (ButtonPressed === "Tidak") {
//                         $("#new_produk").resetForm();
//                         $("#new_produk").attr('action','<?=site_url('new_produk')?>');
//                     }
        
//                 });
//             }            
//         }
//     });
// }
loadScript("<?=base_url("assets/js/plugin/jquery-form/jquery-form.min.js")?>", pagefunction);
</script>