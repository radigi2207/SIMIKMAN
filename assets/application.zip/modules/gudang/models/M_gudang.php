<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_gudang extends CI_Model {

    function datatable_list_produk($where,$limit,$order,$like)
	{
		$this->db->select("*");
		$this->db->from("tb_produk p");
        $this->db->join('tb_kategori k', 'k.id = p.kategori');
        if(count($like) != 0)
        {
            $this->db->group_start();
            $this->db->like($like);
            $this->db->group_end();
        }
        $this->db->group_start();
		$this->db->or_like($where);
        $this->db->group_end();
        if(!empty($limit))
		    $this->db->limit($limit['limit'],$limit['start']);
		$this->db->order_by($order['field'],$order['dir']);		
		return $this->db->get();
		
	}

    function datatable_count_list_produk()
    {
        $this->db->from('tb_produk');
		return $this->db->count_all_results();
        //return $this->db->get('tb_produk p');
    }

    function list_kategori()
    {
        $this->db->select("k.nama_kategori, IFNULL(COUNT(kode_item),0) AS 'jml', k.id");
        $this->db->join('tb_produk p', 'k.id = p.kategori','left');
        $this->db->group_by('k.id');
        $this->db->order_by('k.nama_kategori', 'asc');
        return $this->db->get('tb_kategori k');
    }
    function get_item($data)
    {
        $this->db->where('kode_item',$data);
        return $this->db->get('tb_produk');
    }
    function new_produk($data)
    {
        return $this->db->insert('tb_produk', $data);
    }
    function edit_produk($data)
    {
        $this->db->where('kode_item', $data['kode_item']);
        return $this->db->update('tb_produk', $data);
    }

    function new_kategori($data)
    {
        return $this->db->insert('tb_kategori', $data);
    }

    function get_item_key($v)
    {
        $this->db->where('kode_item', $v);
        return $this->db->get('tb_produk');
    }

    

}

/* End of file M_gudang.php */
?>