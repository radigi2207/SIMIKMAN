<section id="widget-grid" class="">
	<div class="row">
		<article class="col-sm-12 col-md-12 col-lg-12">
			<div class="jarviswidget jarviswidget-color-darken" id="wid-id-1" data-widget-editbutton="false" data-widget-custombutton="false"
             data-widget-deletebutton="false">
				<header>
                    <span class="widget-icon"> <i class="fa fa-cubes"></i> </span>
                    <h2>
                        Daftar Item Barang
                    </h2>
                </header>
				<div>
					<div class="widget-body no-padding">
                        <!--<div class="form-inline text-right" role="toolbar" style="padding: 10px 7px 0px;background: #fafafa;">
                            <a class="btn btn-primary btn-sm" href="<?=site_url('modal/new_produk')?>" data-toggle='modal' data-target='#modal_new_produk'
                             >
                                <span class="fa fa-plus">&nbsp; </span>Produk Baru
                            </a>
                            <a class="btn btn-warning btn-sm  hidden" data-toggle='modal' data-target='#modal_new_kategori'
                             href="<?=site_url('modal/new_kategori')?>" title="Editing Multiple Items">
                                <span class="fa fa-tags">&nbsp; </span>Kategori Baru</a>
                        </div>-->
                        <table id="item" class="table table-striped table-bordered table-hover" width="100%">
                            <thead>
                                <tr>
                                    
                                    <th data-class="expand" class='text-center'>upc/ean/isbn</th>
                                    <th class='text-center'>Nama Produk</th>
                                    <th data-hide="phone" class='text-center'>Kategori</th>
                                    <th data-hide="phone" class='text-center'>Harga Produksi</th>
                                    <th data-hide="phone,tablet" class='text-center'>Harga Jual</th>
                                    <th data-hide="phone,tablet" class='text-center'>Diskon</th>
                                    <th data-hide="phone,tablet" class='text-center'>Kuantitas</th>
                                    <th data-hide="phone,tablet" class='text-center'>Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
					</div>
				</div>
			</div>
		</article>
	</div>
</section>

<div class="modal fade" id="modal_new_produk" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="remoteModalLabel" aria-hidden="true">  
    <div class="modal-dialog">  
        <div class="modal-content">

        </div>  
    </div>  
</div>
<div class="launcher visible-xs">
<button href="<?=site_url('modal/new_produk')?>" data-toggle="modal" data-target="#modal_new_produk" class="btn btn-primary btn-circle btn-lg "><i class="fa fa-plus"></i></button>
</div>

<script type="text/javascript">
pageSetUp();
    var pagefunction = function() {
    
	var responsiveHelper_datatable_fixed_column = undefined;
    var breakpointDefinition = {
				tablet : 1024,
				phone : 480
			};
    
    var itable = $('#item').DataTable({
            "sDom": "<'dt-toolbar'<'col-xs-12 col-sm-6'f><'col-sm-6 col-xs-12 hidden-xs'l>r>"+
                "t"+
                "<'dt-toolbar-footer'<'col-sm-6 col-xs-12 hidden-xs'i><'col-xs-12 col-sm-6'p>>",
            "bFilter": true,
            //"bInfo": false,
            //"bLengthChange": false
            //"bAutoWidth": false,
            //"bPaginate": false,
            //"bStateSave": true, // saves sort state using localStorage
            "bServerSide": true,
            "language" : {
                "sSearchPlaceholder":"Silahkan masukan Kode Item, Nama Item, Kategori Item, Harga Item",
                "emptyTable":     "Tak ada data yang tersedia pada tabel",
                "info":           "Tampil _START_ sampai _END_ dari _TOTAL_ records",
                "infoEmpty":      "Tampil 0 sampai 0 dari 0 records",
                "infoFiltered":   "(Pencarian dari _MAX_ total records)",
                "infoPostFix":    "",
                "thousands":      ",",
                "lengthMenu":     " _MENU_",
                "loadingRecords": "Loading...",
                "processing":     "Memproses...",
                "search":         "_INPUT_",
                "zeroRecords":    "Tidak ada data yang cocok ditemukan",
                "paginate":{
                    "first":      "Pertama",
                    "last":       "Terakhir",
                    "next":       "Berikutnya",
                    "previous":   "Sebelumnya"
                }
            },
            "sAjaxSource": "<?=site_url("datatable/list_gudang_produk")?>",
            "autoWidth" : true,
			"preDrawCallback" : function() {
				// Initialize the responsive datatables helper once.
				if (!responsiveHelper_datatable_fixed_column) {
					responsiveHelper_datatable_fixed_column = new ResponsiveDatatablesHelper($('#item'), breakpointDefinition);
				}
			},
			"rowCallback" : function(nRow) {
				responsiveHelper_datatable_fixed_column.createExpandIcon(nRow);
			},
			"drawCallback" : function(oSettings) {
				responsiveHelper_datatable_fixed_column.respond();
			}
        });
        $('.dataTables_length label').prepend('<a class="btn btn-primary btn-sm" href="<?=site_url('modal/new_produk')?>" data-toggle="modal" data-target="#modal_new_produk"'+
                             '><span class="fa fa-plus">&nbsp; </span>Produk Baru</a> ');
        
    };
    


loadScript("<?=base_url('assets')?>/js/plugin/datatables/jquery.dataTables.min.js", function(){
    loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.colVis.min.js", function(){
        loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.tableTools.min.js", function(){
            loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.bootstrap.min.js", function(){
                loadScript("<?=base_url('assets')?>/js/plugin/datatable-responsive/datatables.responsive.min.js", pagefunction)
            });
        });
    });
});
</script>