<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gudang extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_gudang');
    }

    function datatable_list_produk()
    {
        $get = $this->input->GET();
		$coloumns = array(
                        'kode_item',
						'nama_item',
						'nama_kategori',
                        'harga_produk',
						'harga_jual',
                        'diskon',
						'stok',
                        'opsi');

		$count_coloums = $get['iColumns'];
		$limit = array("start"	=> $get['iDisplayStart'],
						"limit" => $get['iDisplayLength']);
        $get['iSortCol_0'] = ($get['iSortCol_0'] == 6 )? 1: $get['iSortCol_0'];
		$order = array("field"	=> $coloumns[($get['iSortCol_0'])],
						"dir"	=> $get['sSortDir_0']);
		$or_like = array();
		for($i=0; $i< $count_coloums -1; $i++)
		{
            
			$or_like["UPPER(".$coloumns[$i].")"] = strtoupper($get['sSearch']);
			
		}
        $like = array();
		for($i=0; $i< $count_coloums-1; $i++)
		{
            if(strlen($get['sSearch_'.$i]) != 0)
            {
                $like["UPPER(".$coloumns[$i].")"] = strtoupper($get['sSearch_'.$i]);
                
            }			
		}
		
		unset($or_like[0]);
        unset($like[0]);
		$data_filter = $this->M_gudang->datatable_list_produk($or_like,$limit,$order,$like);
        $query = $this->db->last_query();
		$field = $data_filter->list_fields();
        $output = array(
            "sEcho" => intval($get['sEcho']),
            "iTotalRecords" => $this->M_gudang->datatable_count_list_produk(),
            "iTotalDisplayRecords" => $this->M_gudang->datatable_list_produk($or_like,array(),$order,$like)->num_rows(),
            "data" => array()
        );
		foreach($data_filter->result_array() as $row)
		{
            $url = "<button class='btn btn-xs btn-success' href='".site_url('modal/new_produk/'.$row['kode_item'])."' data-toggle='modal' data-target='#modal_new_produk'><i class='fa fa-edit'></i> edit</button>
                    ";
			$arow = array();
            
            $arow[] = "$row[kode_item]";
            $arow[]	= "$row[nama_item]";
            $arow[]	= "$row[nama_kategori]";
            $arow[]	= "<span class='pull-right'>".number_format($row['harga_produk'],0,',','.')."</span>";
            $arow[]	= "<span class='pull-right'>".number_format($row['harga_jual'],0,',','.')."</span>";            
            $arow[]	= ($row['diskon'] != null)? "<center>".$row['diskon']." % </center>" : "";
            $arow[]	= "<center>$row[stok]</center>";
            $arow[] = "<center>".$url."</center>";

			$output['data'][] = $arow;
		}
		
		echo json_encode($output);
    }
    function item()
    {
        $this->benchmark->mark('code_start');
        (!$this->input->is_ajax_request())? show_404():true;

        $html = $this->load->view('item', [], TRUE);
        $this->benchmark->mark('code_end');

        echo json_encode(array("times" =>$this->benchmark->elapsed_time('code_start', 'code_end'),
                               "html"  => $html));
            
    }

    function new_produk()
    {
        $response = array("code" => 200,
                          "msg"  => 'Produk Berhasil disimpan');
        $post = $this->input->post();
        if($this->input->is_ajax_request() || true)
        {
            $post['stok']   = (isset($post['stok'])) ? null : $post['limit_stok'] ;
            $post['diskon'] = (empty($post['diskon'])) ? null : $post['diskon'] ;
            $post['start_diskon']   = (empty($post['start_diskon'])) ? null : $post['start_diskon'] ;
            $post['finish_diskon']   = (empty($post['finish_diskon'])) ? null : $post['finish_diskon'] ;
            unset($post['limit_stok']);
            if(isset($_FILES['file']))
            {
                $config['upload_path']          = './assets/img/produk/';
                $config['allowed_types']        = 'gif|jpg|jpeg|png|bmp';
                $config['encrypt_name']			= true;
                $config['max_size']				= '12000';

                $this->load->library('upload', $config);

                if($this->upload->do_upload('file'))
                {
                    $file = $this->upload->data();
                    if($file['image_width'] > $file['image_height'])
                    {
                        $r = $file['image_width'] / $file['image_height'];
                        $new_w = 512 * $r;
                        $new_h = $new_w / $r;
                        $p = 'P';
                        $x = round(($new_w - 512)/2);
                        $y = 0 ;
                    }
                    else
                    {
                        $r = $file['image_height'] / $file['image_width'];
                        $new_h = 512 * $r;
                        $new_w = $new_h / $r;
                        $y = round(($new_h - 512)/2);
                        $x = 0 ;
                    }

                    $min  = min($file['image_width'],$file['image_height']);
                    $max  = max($file['image_width'],$file['image_height']);
                    $scale = $max/$min;
                    $new_ratio = 256;
                    $config['image_library'] = 'gd2';
                    $config['source_image'] = $file['full_path'];
                    $config['new_image'] = './assets/img/produk/thumbs';
                    $config['maintain_ratio'] = TRUE;
                    $config['width']         = $new_w;
                    $config['height']       = $new_h;
                    
                    $this->load->library('image_lib');
                    $this->image_lib->initialize($config);
                    $this->image_lib->resize();
                    unlink($file['full_path']);
                    
                    $config2['image_library'] = 'gd2';
                    $config2['source_image'] = $file['file_path'].'thumbs/'.$file['file_name'];
                    $config2['new_image'] = './assets/img/produk/thumbs';
                    $config2['maintain_ratio'] = FALSE;
                    $config2['create_thumb'] = TRUE;
                    $config2['thumb_marker'] = '_thumb';
                    $config2['quality'] = "100%";
                    $config2['width'] = 512;
                    $config2['height'] = 512;
                    $config2['x_axis'] = $x;
                    $config2['y_axis'] = $y;
                    $config['dynamic_output'] = TRUE;
                    $this->load->library('image_lib'); 
                    $this->image_lib->initialize($config2);
                    $this->image_lib->crop();
                    $response['img'] = $file;
                    $post['thumbs'] = 'assets/img/produk/thumbs/'.$file['raw_name'].'_thumb'.$file['file_ext'];
                }
                else
                {
                    $response['code'] = '201';
                    $response['msg']  = 'Upload File gagal Silahkan ulangi kembali!<br>File yang diizinkan jpg/png/gif/bmp ukuran < 12Mb';
                }
            }
            else
                $post['thumbs'] = 'assets/img/produk/item.png';

            unset($post['file']);
            $this->db->db_debug = FALSE;
            $post['kode_item'] = strtoupper($post['kode_item']);
            $this->M_gudang->new_produk($post);
            $error = $this->db->error();

            if($error['code'] == 1062)
            {
                $response['code'] = 201;
                $response['msg']  = 'Kode Item '.$post['kode_item'].' sudah ada silakan gunakan kode lain';
                if(!empty($response['img']))
                    unlink($post['thumbs']);
            }
            
            echo json_encode($response);
            return;
        }
        show_404();
    }

    function edit_produk()
    {
        $response = array("code" => 200,
                          "msg"  => 'perubahan Produk Berhasil disimpan');
        $post = $this->input->post();
        if($this->input->is_ajax_request() || true)
        {
            $post['stok']   = (isset($post['stok'])) ? null : $post['limit_stok'] ;
            $post['diskon'] = (empty($post['diskon'])) ? null : $post['diskon'] ;
            $post['start_diskon']   = (empty($post['start_diskon'])) ? null : $post['start_diskon'] ;
            $post['finish_diskon']   = (empty($post['finish_diskon'])) ? null : $post['finish_diskon'] ;
            unset($post['limit_stok']);
            $unlink = (strpos('produk/item.png',$post['thumb']) > 0 ) ? unlink($post['thumb']) : false ;
            unset($post['thumb']);
            if(isset($_FILES['file']))
            {
                $config['upload_path']          = './assets/img/produk/';
                $config['allowed_types']        = 'gif|jpg|jpeg|png|bmp';
                $config['encrypt_name']			= true;
                $config['max_size']				= '12000';

                $this->load->library('upload', $config);

                if($this->upload->do_upload('file'))
                {
                    $file = $this->upload->data();
                    if($file['image_width'] > $file['image_height'])
                    {
                        $r = $file['image_width'] / $file['image_height'];
                        $new_w = 512 * $r;
                        $new_h = $new_w / $r;
                        $p = 'P';
                        $x = round(($new_w - 512)/2);
                        $y = 0 ;
                    }
                    else
                    {
                        $r = $file['image_height'] / $file['image_width'];
                        $new_h = 512 * $r;
                        $new_w = $new_h / $r;
                        $y = round(($new_h - 512)/2);
                        $x = 0 ;
                    }

                    $min  = min($file['image_width'],$file['image_height']);
                    $max  = max($file['image_width'],$file['image_height']);
                    $scale = $max/$min;
                    $new_ratio = 256;
                    $config['image_library'] = 'gd2';
                    $config['source_image'] = $file['full_path'];
                    $config['new_image'] = './assets/img/produk/thumbs';
                    $config['maintain_ratio'] = TRUE;
                    $config['width']         = $new_w;
                    $config['height']       = $new_h;
                    
                    $this->load->library('image_lib');
                    $this->image_lib->initialize($config);
                    $this->image_lib->resize();
                    unlink($file['full_path']);
                    
                    $config2['image_library'] = 'gd2';
                    $config2['source_image'] = $file['file_path'].'thumbs/'.$file['file_name'];
                    $config2['new_image'] = './assets/img/produk/thumbs';
                    $config2['maintain_ratio'] = FALSE;
                    $config2['create_thumb'] = TRUE;
                    $config2['thumb_marker'] = '_thumb';
                    $config2['quality'] = "100%";
                    $config2['width'] = 512;
                    $config2['height'] = 512;
                    $config2['x_axis'] = $x;
                    $config2['y_axis'] = $y;
                    $config['dynamic_output'] = TRUE;
                    $this->load->library('image_lib'); 
                    $this->image_lib->initialize($config2);
                    $this->image_lib->crop();
                    $response['img'] = $file;
                    $post['thumbs'] = 'assets/img/produk/thumbs/'.$file['raw_name'].'_thumb'.$file['file_ext'];
                }
                else
                {
                    $response['code'] = '201';
                    $response['msg']  = 'Upload File gagal Silahkan ulangi kembali!<br>File yang diizinkan jpg/png/gif/bmp ukuran < 12Mb';
                }
            }
            else
                $post['thumbs'] = 'assets/img/produk/item.png';

            unset($post['file']);
            $this->db->db_debug = FALSE;   
            $this->M_gudang->edit_produk($post);
            $error = $this->db->error();

            if($error['code'] != 0)
            {
                $response['code'] = 201;
                $response['msg']  = 'Kode Item '.$post['kode_item'].' sudah ada silakan gunakan kode lain';
                if(!empty($response['img']))
                    unlink($post['thumbs']);
            }
            echo json_encode($response);
            return;
        }
        show_404();
    }

    function kategori()
    {
        $this->benchmark->mark('code_start');
        (!$this->input->is_ajax_request())?  show_404():true;
        $data['kategori'] = $this->M_gudang->list_kategori();
        $html = $this->load->view('kategori', $data, TRUE) ;
        $this->benchmark->mark('code_end');
        echo json_encode(array("times" =>$this->benchmark->elapsed_time('code_start', 'code_end'),
                               "html"  => $html));
    }
    function new_kategori()
    {
        $post = $this->input->post();
        $response = array("code" => 200,
                          "msg"  => "Kategori baru Berhasil di simpan");
        if(!$this->M_gudang->new_kategori($post))
        {
            $response['code'] = 201;
            $response['msg']  = "Kategori gagal disimpan silahkan ulangi kembali";
        }
        echo json_encode($response);

        //$this->load->view('new_produk', [], FALSE);

    }

    function search_produk_key()
    {
        $key = $this->input->post('kode_item');
        if($this->input->is_ajax_request())
        {
            $row = $this->M_gudang->get_item_key($key)->row();
            echo json_encode($row);
            return;
        }
        show_404();
    }

}

/* End of file Gudang.php */
?>