<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Server extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Server_model','server');
        $this->load->helper('Security');
    }

    public function sync()
    {
        $req = json_decode($this->mc_decode($this->getHeader()['X-Data']));
        $query = $this->server->log_query($req->log_date);
        $response = array('log_count' => $query,
                          'query' => $this->db->last_query(),
                          'signature' => $this->getHeader());
        echo json_encode($response);
    }

    public function sync_submit()
    {
        $data = $this->getHeader();

    }

    public function ceck_update()
    {
        $data = array('hash'     => sha1('2017/04/23 11:24:01'),       
                      'url_file' => 'http://localhost/Test-Auto-Updater-master.zip',
                      'tgl'      => '2017/04/23 11:24:00');
        echo json_encode($data);
    }

    public function test()
    {
        $this->load->helper('file');
        $this->load->helper('directory');
        $this->curl->create('http://localhost/wenk/server/ceck_update');
        $data = json_decode($this->curl->execute(),true);
        if($data['hash'] != $this->config->item('last_update'))
        {
            copy($data['url_file'],$this->config->item('update_temp')."/".$data['hash'].".zip");
            $this->load->library('zip');
            $this->zip->read_dir("application/modules",false);
            $this->zip->archive("./assets/application.zip");
            $this->load->library('Unzip');
            $this->unzip->extract($this->config->item('update_temp')."/".$data['hash'].".zip",".//");

            $this->db->set('value', $data['hash']);
            $this->db->where('key', 'last_update');
            $this->db->update('tb_app_config');
        }
        else
        {
            echo 'aplikasi terbarukan';
        }

    }

    private function getHeader()
    {
        $headers = array();
		foreach ($_SERVER as $k => $v)
		{
			if (substr($k, 0, 5) == "HTTP_")
			{
				$k = str_replace('_', ' ', substr($k, 5));
				$k = str_replace(' ', '-', ucwords(strtolower($k)));
				$headers[$k] = $v;
			}
		}
        
		return $headers;
    }

    private function signature($keycode,$time) 
	{	
        $options = ['cost' => 5,
                    'salt' => mcrypt_create_iv(22, MCRYPT_DEV_URANDOM),
                   ];
        return password($keycode, $options);
		//return base64_encode(hash_hmac('sha256', $id."&".$pass, $time, true));
	}

    private function mc_encode($string)
    {
        $string = $this->encryption->encrypt($string);
        return $string;
        return strtr($string,array('+' => '.',
                                    '=' => '_',
                                    '/' => '`'));
    }
    private function mc_decode($string)
    {
        // return $string;
        $string = strtr(($string),array('.' => '+',
                                    '_' => '=',
                                    '`' => '/'));
        return $this->encryption->decrypt($string);
    }
    
    
    

}

/* End of file Server.php */
?>