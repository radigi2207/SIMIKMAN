<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Server_model extends CI_Model {

    function log_count()  
    {
        return $this->db->count_all('tb_log');
    }

    function log_date()
    {
        $this->db->select("max(date) AS date ");
        return $this->db->get('tb_log')->row();
    }

    function log_query($date)
    {
        $this->db->where("date > ","'$date'", false);
        return $this->db->get('tb_log')->result_array();
    }

}

/* End of file Server_model.php */
?>