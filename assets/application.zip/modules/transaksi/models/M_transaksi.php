<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_transaksi extends CI_Model {

    function kategori()
    {

    }

    function get_all_cart($id_cart)
    {
        $this->db->select('p.nama_item, p.kode_item, t.diskon, t.qty, t.id, t.harga');
        $this->db->join('tb_produk p', 'p.kode_item = t.kode_item');
        $this->db->where('t.kode_transaksi', $id_cart);
        $this->db->order_by('t.id', 'asc');
        return $this->db->get('tb_transaksi t');
    }

    function add_to_cart($insert)
    {
        $this->db->where('kode_item', $insert['kode_item']);
        $produk = $this->db->get('tb_produk');
        $response = array('status' => array('code' => true,
                                            'msg'  => 'Berhasil ditambahkan'));
        if($produk->num_rows() == 1)
        {
            $produk = $produk->row();
            $response['produk'] = $produk;
            if($produk->stok >= $insert['qty'] || $produk->stok == null)
            {
                $this->db->where('kode_transaksi', $insert['kode_transaksi']);
                $this->db->where('kode_item', $insert['kode_item']);
                $cart = $this->db->get('tb_transaksi');
                if($cart->num_rows() == 1)
                {
                    $cart = $cart->row();
                    if($produk->stok >= 1 || $produk->stok == null)
                    {
                        $this->db->where('kode_transaksi', $insert['kode_transaksi']);
                        $this->db->where('kode_item', $insert['kode_item']);
                        $update = array('qty' => ($cart->qty +1));
                        $this->db->update('tb_transaksi', $update);
                        
                    }
                    else
                    {
                        $response['status']['code'] = false;
                        $response['status']['msg']  = 'Stok Tidak Tersedia atau Permintaan penjualan melebihi stok yang ada.';
                    }
                   
                }
                else
                {
                    $id['id'] = null;
                    $insert['harga']    = $produk->harga_jual;
                    $insert['qty']      = 1;
                    $diskon = (mysql_to_unix($produk->finish_diskon) >  mysql_to_unix(mdate("%Y-%m-%d",time())) && mysql_to_unix($produk->start_diskon) <= mysql_to_unix(mdate("%Y-%m-%d",time()))) ? $produk->diskon : null ;
                    $insert['diskon']   = $diskon;
                    $insert['margin']   = ($produk->harga_jual - $produk->harga_jual * ($diskon/100)) - $produk->harga_produk;
                    $gabung= array_merge($id,$insert);
                    $this->db->insert('tb_transaksi',$gabung);
                    
                }
                log_query($this->db->last_query(),$this->db->insert_id());
                // //log['query'] = ;
                // $log['query'] = str_replace('VALUES (NULL','VALUES ('.$this->db->insert_id(),$this->db->last_query());
                // $this->db->insert('tb_log', $log);       
            }
            else
            {
                $response['status']['code'] = false;
                $response['status']['msg']  = 'Stok Tidak Tersedia atau Permintaan penjualan melebihi stok yang ada.';
            }

            return $response;
        }
    }

    function update_qty_cart($data)
    {
        $this->db->where('kode_item', $data['kode_item']);
        $produk = $this->db->get('tb_produk');
        $response = array('status' => array('code' => true,
                                            'msg'  => 'Jumlah barang berhasil ditambahkan'));
        if($produk->num_rows() == 1)
        {
            $produk = $produk->row();
            $response['produk'] = $produk;
            $this->db->where('kode_transaksi', $data['kode_transaksi']);
            $this->db->where('kode_item', $data['kode_item']);
            $cart = $this->db->get('tb_transaksi');
            $cartr = $cart->row();
            if(($produk->stok+$cartr->qty) >= $data['qty'] || $produk->stok == null)
            {
                
                if($cart->num_rows() == 1)
                {
                    $this->db->where('kode_transaksi', $data['kode_transaksi']);
                    $this->db->where('kode_item', $data['kode_item']);
                    $update = array('qty' => $data['qty']);
                    $this->db->update('tb_transaksi', $update);

                    
                }          
            }
            else
            {
                $response['status']['code'] = false;
                $response['status']['msg']  = 'Stok Tidak Tersedia atau Permintaan penjualan melebihi stok yang ada.';
            }
            log_query($this->db->last_query()); 
            return $response;
        }
    }
    function delete_cart($data)
    {
        $this->db->where('kode_item', $data['kode_item']);
        $produk = $this->db->get('tb_produk');
        $response = array('status' => array('code' => true,
                                            'msg'  => 'Berhasil dihapus dari Keranjang Belanja'));
        if($produk->num_rows() == 1)
        {
            $produk = $produk->row();
            $response['produk'] = $produk;
            $this->db->where('kode_transaksi', $data['kode_transaksi']);
            $this->db->where('kode_item', $data['kode_item']);
            $cart = $this->db->get('tb_transaksi');
            if($cart->num_rows() == 1)
            {
                $cart = $cart->row();
                $this->db->where('kode_transaksi', $data['kode_transaksi']);
                $this->db->where('kode_item', $data['kode_item']);
                $this->db->delete('tb_transaksi');
                if($this->db->affected_rows() == 0)
                {
                    $response['status']['code'] = false;
                    $response['status']['msg']  = 'Gagal di hapus dari keranjang belanja.';
                }
               
            }
            log_query($this->db->last_query());
            return $response;
        }
    }

    function remove_all_cart($kode_transaksi)
    {
        $this->db->where('kode_transaksi',$kode_transaksi);
        $this->db->delete('tb_transaksi');
        $remove = $this->db->affected_rows();
        log_query($this->db->last_query());
        return $remove;
        
    }

    function bayar($data)
    {
        $this->db->where('kode_transaksi', $data['kode_transaksi']);
        $transaksi = $this->db->get('tb_transaksi');
        if($transaksi->num_rows() != 0)
        {
            $this->db->select("IF(count(kode_faktur) = 0, LPAD(1,4,'0'),LPAD(max(RIGHT(kode_faktur,4))+1,4,'0')) AS 'next_faktur'");
            $this->db->where("DATE_FORMAT(tgl,'%m%y') = DATE_FORMAT(now(),'%m%y')");
            $faktur = $this->db->get('tb_faktur')->row();
            $faktur = KODE_TOKO.mdate('%m%y').$faktur->next_faktur;
            $tt = 0;
            $td = 0;
            foreach($transaksi->result_array() as $row)
            {
                $tt += ($row['harga'] * $row['qty']);
                $td += ((($row['diskon']/100)* $row['harga']) * $row['qty']);
            }
            if(!empty($data['member']))
            {
                $this->db->where('id', $data['member']);
                $member = $this->db->get('tb_member');
                if($member->num_rows() == 1)
                {
                    $member = $member->row();
                    $p = ceil($member->point/$tt*100);
                    $diskonpoint = $member->point;
                    if($p > 25)
                    {
                        $diskonpoint = $tt * 0.25;
                        $td += $diskonpoint;
                    }
                    else
                        $td += $member->point;

                    $this->db->where('id', $data['member']);
                    $this->db->set("point","(point - ".$diskonpoint.")",false);
                    $this->db->update('tb_member');

                    log_query($this->db->last_query());
                }
                
            }
            $insert = array('kode_faktur'   => $faktur,
                            'total_tagihan' => $tt,
                            'total_diskon'  => $td,
                            'total_bayar'   => $data['bayar'],
                            'cara_bayar'    => $data['cara_bayar'],
                            'ket'           => $data['keterangan'],
                            'member'        => $data['member'],
                            'karyawan'      => $this->session->userdata('id'),
                            'point'         => round(($tt-$td)/$this->config->item('div_point')));
            $this->db->insert('tb_faktur', $insert);
            log_query($this->db->last_query());

            if($this->db->affected_rows()== 1)
            {
                $this->db->where('kode_transaksi', $data['kode_transaksi']);
                $this->db->update('tb_transaksi', array('kode_transaksi' => $faktur));
                log_query($this->db->last_query());
                $this->db->where('id', $data['member']);
                $this->db->set('point', 'point + '.round(($tt-$td)/$this->config->item('div_point')).' ',false);
                $this->db->update('tb_member');
                log_query($this->db->last_query());
                $this->db->where('user_id', $this->session->userdata('id'));
                $this->db->where('date', mdate("%y/%m/%d", now()));
                $this->db->where('status', 0);
                $setor = $this->db->get('tb_setor');

                if($setor->num_rows() != 1)
                {
                    $tt = ($tt > $data['bayar']) ? $data['bayar'] : $tt;
                    $setor = array('invoice' =>  $faktur,
                                   'date'    => mdate("%y/%m/%d", now()),
                                   'user_id' => $this->session->userdata('id'),
                                   'status'  => 0,
                                   'pendapatan' => $tt);
                    $this->db->insert('tb_setor', array_merge(array("id" => null),$setor));
                    log_query($this->db->last_query(),$this->db->insert_id());
                }
                elseif($setor->num_rows() == 1)
                {
                    $tt = ($tt > $data['bayar']) ? $data['bayar'] : $tt;
                    $setor = $setor->row();
                    $this->db->where('id', $setor->id);
                    $this->db->set('pendapatan',"(pendapatan + $tt)", FALSE);
                    $this->db->set('invoice',"CONCAT(invoice,'#','$faktur')",FALSE);
                    $this->db->update('tb_setor');
                    log_query($this->db->last_query());
                }
            }
            return $this->invoice($faktur);
            
        }
    }
    function invoice($faktur)
    {
        $this->db->select('f.ket,f.kode_faktur, DATE_FORMAT(f.tgl,"%d/%m/%y %H:%i") AS "tgl",f.total_tagihan,f.total_diskon,f.total_bayar, p.nama_item,t.diskon,t.qty,t.harga ');
        $this->db->from('tb_faktur f');
        $this->db->join('tb_transaksi t', 'f.kode_faktur = t.kode_transaksi');
        $this->db->join('tb_produk p', 'p.kode_item = t.kode_item', 'left');
        $this->db->where('f.kode_faktur', $faktur);
        $this->db->order_by('t.id', 'asc');
        return $this->db->get();
    }
    function search_produk($get)
    {
        $like = array('kode_item' => $get['search'],
                      'nama_item' => $get['search'] );
        $this->db->join('tb_kategori k', 'k.id = p.kategori');
        $this->db->or_like($like);
        $this->db->limit($get['maxRows']);
        return $this->db->get('tb_produk p ');
    }
    
    

    function get_all_transaksi($kode)
    {
        $this->db->select('IF(max)');
        $this->db->like('kode_transaksi', $kode,'after');
        return $this->db->get('Table', limit, offset);
    }

    function datatable_invoice($where,$limit,$order,$like)
	{
		$this->db->select("*");
		$this->db->from("tb_faktur");
        $this->db->join('tb_member', 'member = id', 'left');
        if(count($like) != 0)
        {
            $this->db->group_start();
            $this->db->like($like);
            $this->db->group_end();
        }
        $this->db->group_start();
		$this->db->or_like($where);
        $this->db->group_end();

		$this->db->limit($limit['limit'],$limit['start']);
		$this->db->order_by($order['field'],$order['dir']);		
		return $this->db->get();
		
	}
    function datatable_count_invoice()
    {
        return $this->db->get('tb_faktur');
    }

    function get_faktur($faktur)
    {
        $this->db->where('kode_faktur', $faktur);
        return $this->db->get('tb_faktur');
    }

    //setor
    function detail_setor($id)
    {
        $this->db->select('s.*,CONCAT(u.first_name," ",last_name) AS "name", DATE_FORMAT(s.date,"%d-%m-%Y") AS "tgl"');
        $this->db->join('tb_users u', 'u.id = s.user_id');
        $this->db->where('s.id', $id);
        return $this->db->get('tb_setor s');
    }
    function cek_setor($user)
    {
        $this->db->where('user_id', $user);
        $this->db->where('status', 0);
        $this->db->where("date = DATE_SUB(CURRENT_DATE(),INTERVAL 1 DAY)");
        return $this->db->get('tb_setor');
    }

    function all_setor($setor = null)
    {
        $this->db->select('*, DATE_FORMAT(date,"%d-%m-%Y") AS "tgl"');
        
        $user_id = $this->session->userdata('id');  
        if($setor = null)      
            $this->db->where('user_id',$user_id);
        return $this->db->get('tb_setor');
    }

    function konfirmasi_setor($data)
    {
        $response = array("code" => 200,
                          "msg"  => "Konfirmasi Penyetoran berhasil");
        //$this->db->db_debug = FALSE;
        $this->db->trans_start();
        $this->db->join('tb_users u', 'u.id = s.user_id');
        $this->db->where('s.id', $data['id']);
        $setor = $this->db->get('tb_setor s')->row();
        $this->db->where('id', $data['id']);
        $this->db->set('status', 2,FALSE);
        $this->db->set('ket_status',$data['ket_status']);
        $this->db->set('date_status',mdate("%Y/%m/%d %H:%i:%s", now()),TRUE);
        $this->db->set('user_id_status',$this->session->userdata('id'));
        $this->db->update('tb_setor');
        log_query($this->db->last_query());

        $insert['kode']      = 'T020';
        $insert['transaksi'] = 'Setor Tunai Kasir';
        $insert['type']      = 'KREDIT';
        $insert['nominal']   = $setor->pendapatan;
        $insert['operator']  = $this->session->userdata('people');
        $insert['keterangan']       = 'Penyetoran kasir '.$setor->first_name." ". $setor->last_name;
        $this->db->insert('tb_rek', $insert);
        log_query($this->db->last_query(),$this->db->insert_id());
        $this->db->trans_complete();
        return $response;
    }

    function detail_transaksi($start_date = null, $finish_date = null)
    {
        if($start_date == null && $finish_date == null)
        {
            $this->db->where('tgl < ',"DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY)",FALSE);
        }
        else
        {
            $this->db->where('tgl < ', "STR_TO_DATE('$start_date','%d-%m-%Y')",FALSE);
        }
        $this->db->select("SUM(IF(type = 'KREDIT',nominal,0)) - SUM(IF(type = 'DEBET',nominal,0)) AS 'awal'");
        $this->db->order_by('tgl', 'ASC');
        $awal = $this->db->get('tb_rek')->row();

        if($start_date == null && $finish_date == null)
        {
            $this->db->where('tgl >= ',"DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY)",FALSE);
        }
        else
        {
            $this->db->where('tgl >= ', "STR_TO_DATE('$start_date','%d-%m-%Y')",FALSE);
            $this->db->where('tgl <= ', "STR_TO_DATE('$finish_date','%d-%m-%Y')",FALSE);
        }
        $this->db->select("*, DATE_FORMAT(tgl,'%d-%m-%Y %H:%i:%i') AS 'tgl'");
        $this->db->order_by('tgl', 'ASC');
        return array('awal' => $awal,
                     'all'  => $this->db->get('tb_rek'));

    }

    function get_transaksi($type)
    {
        $this->db->where('type', $type);
        $this->db->order_by('tgl', 'asc');
        return $this->db->get('tb_rek');
    }
    function save_transaksi($data,$type="KREDIT")
    {
        $type_text = ($type == "KREDIT")? "pemasukan":"pengeluaran";
        $response = array("code" => 200,
                          "msg"  => "Transaksi ".$type_text." berhasil di simpan");
        $this->db->db_debug = FALSE;
        $this->db->trans_start();
        $data['kode'] = "T010";
        $data['type'] = $type;
        $data['nominal'] = str_replace(".","",$data['nominal']);
        $this->db->insert('tb_rek', $data);
        log_query($this->db->last_query(),$this->db->insert_id());
        $this->db->trans_complete();
        if(!$this->db->trans_status())
        {
            $response['code'] = 201;
            $response['msg']  = "Transaksi ".$type_text." gagal di simpan silahkan ulangi kembali";
        }
        return $response;

    }

    
}

/* End of file M_transaksi.php */
?>