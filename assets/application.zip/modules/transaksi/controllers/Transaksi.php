<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transaksi extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model(array('M_transaksi','gudang/M_gudang','auth/M_auth'));
        $this->load->helper('date');
        $this->M_auth->cek_session();

    }

    public function back()
    {
        //$this->db->where('date < ', '2017-03-15 12:01:52',TRUE);
        $this->db->order_by('date', 'ASC');
        $query = $this->db->get('tb_log');
        foreach ($query->result_array() as $row) {
            $this->db->query($row['query']);
            echo "$row[query]<br>";
        }
    }
    
    function search_produk()
    {
        $get = $this->input->get();
        $respone = array();
        $produk = $this->M_transaksi->search_produk($get);
        foreach ($produk->result_array() as $row) {
            $diskon = (mysql_to_unix($row['finish_diskon']) >=  mysql_to_unix(mdate("%Y-%m-%d",time())) && mysql_to_unix($row['start_diskon']) <= mysql_to_unix(mdate("%Y-%m-%d",time()) )) ?number_format($row['diskon'],0,',','.') : null ;
            $respone[] = array('kode' => $row['kode_item'],
                         'label'=> $row['nama_item'] ,
                         'harga'=> $row['harga_jual'],
                         'image' => $row['thumbs'],
                         'kategori' => $row['nama_kategori'],
                         'discount' => $diskon);
        }
        echo json_encode( $respone);
        
    }
    function add_to_cart()
    { 
        $post = $this->input->post();
        $response = array();
        if($this->input->is_ajax_request())
        {
            $insert = array("kode_transaksi" => $post['id_cart'],
                            "kode_item"      => $post['kode_item'],
                            "qty"            => 1
                            );

            $produk = $this->M_transaksi->add_to_cart($insert);            
            $response['status'] = $produk['status'];
            $response['html'] = $this->html_list_cart($post['id_cart']);
            $response['produk'] = $produk['produk'];
            echo json_encode($response);
            return;
        }
        show_404();

    }
    function update_qty_cart()
    {
        $post = $this->input->post();
        $response = array();
        if($this->input->is_ajax_request())
        {
            $produk = $this->M_transaksi->update_qty_cart($post);       
            $response['status'] = $produk['status'];
            $response['html'] = $this->html_list_cart($post['kode_transaksi']);
            $response['produk'] = $produk['produk'];
            echo json_encode($response);
            return;
        }
        show_404();
    }
    function delete_cart()
    {
        $post = $this->input->post();
        $response = array();
        if($this->input->is_ajax_request())
        {
            $produk = $this->M_transaksi->delete_cart($post);       
            $response['status'] = $produk['status'];
            $response['html'] = $this->html_list_cart($post['kode_transaksi']);
            $response['produk'] = $produk['produk'];
            echo json_encode($response);
            return;
        }
        show_404();
    }

    function remove_all_cart()
    {
        if($this->input->is_ajax_request())
        {
            $post = $this->input->post('kode_transaksi');
            $this->M_transaksi->remove_all_cart($post);
            echo $post;
            return true;
        }
        show_404();
    }
    function table_list_cart()
    {
        $id_cart = $this->input->post('id_cart');
        echo json_encode($this->html_list_cart($id_cart));

    }
    private function html_list_cart($id_cart)
    {
        $html = "";
        $respone = array();
        $respone['total'] = 0;
        $all_cart = $this->M_transaksi->get_all_cart($id_cart);
        $respone['diskon'] = 0;
        $respone['total_item'] = 0;
        foreach ($all_cart->result_array() as $row) {
            $st = $row['harga'] * $row['qty'];
            $diskon = $row['qty'] * $row['diskon'];
            $respone['total'] += $st;
            $respone['total_item'] += $row['qty'];
            $respone['diskon'] += (($diskon/100)* $row['harga']);
            $edit_stok = "
                            <div class='form-horizontal'>
                                <fieldset>
                                    <div class='form-group'>
                                        <div class='col-lg-7 npr'>
                                            <input type='number' class='form-control' name='row-qty-$row[id]' min='1' value='$row[qty]' onChange='qty_save(&quot;$row[kode_item]&quot;,$(&quot;input[name=row-qty-$row[id]]&quot;).val(),event)' autofocus>
                                        </div>
                                        <div class='col-lg-2'>
                                            <button type='button' class='btn btn-primary save'  onclick='$(&quot;#row-".$row['id']."&quot;).popover(&quot;hide&quot;); qty_save(&quot;$row[kode_item]&quot;,$(&quot;input[name=row-qty-$row[id]]&quot;).val())'>
                                                <i class='fa fa-check fa-lg'></i>
                                            </button>
                                        </div>
                                        <div class='col-lg-2'>
                                            <button type='button' class='btn btn-primary btn-danger' onclick='$(&quot;#row-".$row['id']."&quot;).popover(&quot;hide&quot;);'>
                                                <i class='fa fa-close fa-lg '></i>
                                            </button>
                                        </div>
                                    </div>
                                </fieldset>  
                        </div>";
            $edit = '';
            $row['diskon'] =  ($row['diskon'] != null)? $row['diskon'].' %': null;
            $html .= "  <tr>
                        <td class='text-center'><a class='btn btn-danger btn-xs' href='javascript:delete_cart(&quot;$row[kode_item]&quot;);'><i class='fa fa-trash-o' aria-hidden='true'></i></a></td>
                        <td>$row[nama_item]</td>
                        <td class='text-right'>".number_format($row['harga'],0,',','.')."</td>
                        <td class='text-center'><a href='javascript:void(0);' id='row-$row[id]' rel='popover' data-placement='top' data-original-title='<i class=\"fa fa-fw fa-pencil\"></i> Tambah Quantity barang' data-html=\"true\" data-content=\"$edit_stok\" >$row[qty]</a></td>
                        <td class='text-right'>".$row['diskon']."</td>
                        <td class='text-right'>".number_format($st - (($diskon/100)* $row['harga']),0,',','.')."</td>
                    </tr>";
        }
        $respone['html'] = $html;
        $respone['text'] = array('total'        => number_format($respone['total'],0,',','.'),
                                 'diskon'       => number_format($respone['diskon'],0,',','.'),
                                 'grand_total'  => number_format($respone['total'] - $respone['diskon'],0,',','.')
                                );
        
        return $respone;
    }
    function datatable_list_produk()
    {
        $get = $this->input->get();
		$coloumns = array('kode_item',
						'nama_item',
						'nama_kategori',
						'harga_jual',
						'stok');

		$count_coloums = $get['iColumns'];
		$limit = array("start"	=> $get['iDisplayStart'],
						"limit" => $get['iDisplayLength']);
		$order = array("field"	=> $coloumns[($get['iSortCol_0'])],
						"dir"	=> $get['sSortDir_0']);
		$or_like = array();
		for($i=0; $i< $count_coloums; $i++)
		{
            
			$or_like["UPPER(".$coloumns[$i].")"] = strtoupper($get['sSearch']);
			
		}
        $like = array();
		for($i=0; $i< $count_coloums; $i++)
		{
            if(strlen($get['sSearch_'.$i]) != 0)
            {
                $like["UPPER(".$coloumns[$i].")"] = strtoupper($get['sSearch_'.$i]);
                
            }			
		}
		
		unset($or_like[0]);
        unset($like[0]);
		$data_filter = $this->M_gudang->datatable_list_produk($or_like,$limit,$order,$like);
        $query = $this->db->last_query();
		$field = $data_filter->list_fields();
        $output = array(
            "sEcho" => intval($get['sEcho']),
            "iTotalRecords" => $this->M_gudang->datatable_count_list_produk(),
            "iTotalDisplayRecords" => $this->M_gudang->datatable_list_produk($or_like,array(),$order,$like)->num_rows(),
            "data" => array()
        );
		foreach($data_filter->result_array() as $row)
		{
            $url = "javascript:add_cart(&quot;$row[kode_item]&quot;)";
			$arow = array();
            $arow[] = "<a href='$url'>$row[kode_item]</a>";
            $arow[]	= "<a href='$url'>$row[nama_item]</a>";
            $arow[]	= "<a href='$url'>$row[nama_kategori]</a>";
            $arow[]	= "<a class='' href='$url'>".number_format($row['harga_jual'],0,',','.')."</a>";
            $arow[]	= "<a href='$url'>$row[stok]</a>";

			$output['data'][] = $arow;
		}
		
		echo json_encode($output);
    }
    function penjualan()
    {
        log_message('debug', 'sql query fail in... ', false);
        $this->benchmark->mark('code_start');
        (!$this->input->is_ajax_request())?show_404() : true;
        $setor = $this->M_transaksi->cek_setor($this->session->userdata('id'));
        $html = $this->load->view('penjualan',[], TRUE);
        if($setor->num_rows() == 1)
        {
            
            $setor = $setor->row();

            $html = "<h3 class='text-center'>Maaf anda tidak bisa transaksi penjualan, anda belum menutup transaksi pada tanggal ".$setor->date. ". Silahkan menutup transaksi terlebih dahulu pada menu <a href='#laporan/kasir'>Laporan Kasir</a></h3>";
        }
        
        $this->benchmark->mark('code_end');

        echo json_encode(array("times" =>$this->benchmark->elapsed_time('code_start', 'code_end'),
                               "html"  => $html));
    }
    function pembayaran()
    {
        if($this->input->is_ajax_request())
        {
            $this->load->view('pembayaran', [], FALSE);
            return;
        }
        show_404();
    }
    function proses_pembayaran()
    {
        $post = $this->input->post();
        if(!empty($post))
        {
            $bayar = array('bayar'          => str_replace(".","",$post['bayar']),
                           'kode_transaksi' => $post['id_cart'],
                           'cara_bayar'     => $post['cara_bayar'],
                           'keterangan'     => $post['keterangan'],
                           'member'         => $post['member']);
            $transaksi = $this->M_transaksi->bayar($bayar);

            $this->cetak_invoice($transaksi);
            $kembalian = (str_replace(".","",$post['bayar']) - $post['total_tagihan']);
            $data['txt'] = number_format($kembalian,0,',','.');
            $data['number'] = $kembalian;
            echo json_encode($data);
        }
    }
    function list_penjualan()
    {
        if($this->input->is_ajax_request())
        {
            $this->load->view('list_produk',[], FALSE);
            return ;
        }
        show_404();
    }

    function invoice()
    {
        $this->benchmark->mark('code_start');
        $html = ($this->input->is_ajax_request())? $this->load->view('list_invoice',[], TRUE) : show_404();
        $this->benchmark->mark('code_end');
        echo json_encode(array("times" =>$this->benchmark->elapsed_time('code_start', 'code_end'),
                               "html"  => $html));
    }

    function re_cetak_invoice()
    {
        $faktur = $this->input->post('kode_faktur');
        $this->cetak_invoice($this->M_transaksi->invoice($faktur));
    }
    private function cetak_invoice($transaksi,$type = 'cash')
    {
        $this->load->library('Printer_epos');
        $this->printer_epos->prints(PRINTER_NAME);
        $this->print-> initialize();
        /* Text */
        //$this->print-> selectPrintMode(Printer::MODE_DOUBLE_WIDTH);
        $this->print-> setFont(2);
        $this->print-> selectPrintMode(40);
        $this->print-> setEmphasis(true);
        $this->print-> setJustification(1);
        $this->print-> text($this->config->item('receipt_header').".\n");
        $this->print-> setEmphasis(false); 
        $this->print-> setFont();
        $this->print-> selectPrintMode();
        
        //$this->print-> selectPrintMode($this->print->MODE_DOUBLE_WIDTH);
        $this->print-> text($this->config->item('receipt_address')."\n");
        $this->print-> text($this->config->item('phone')."\n");
        $this->print-> setJustification();
        $this->print-> feed();

        /* Title of receipt */
        $this->print->setLineSpacing(18);
        $row = $transaksi->row();
        $this->print-> text("=================================\n");
        $this->print-> text($this->printer_epos->th($row->tgl,$row->kode_faktur."/".$this->session->userdata('inisial')));
        $this->print-> text("---------------------------------\n");
        $jumlah = 0;
        $diskon = 0;
        $bayar = 0;
        $qty = 0;
        $ket = "";
        foreach($transaksi->result_array() as $row)
        {
            $ket = $row['ket'];
            $qty += $row['qty'];
            $sb = $row['qty'] * $row['harga'];
            $jumlah = $row['total_tagihan'];
            $sbdiskon = round($row['harga'] * ($row['diskon']/100)) * $row['qty'];
            $diskon = $row['total_diskon'];
            $bayar = $row['total_bayar'];
            $this->print->text($this->printer_epos->item($row['nama_item'],$row['qty'],$row['harga']));
            if($row['diskon'] != null || $row['diskon'] > 0) $this->print->text($this->printer_epos->diskon($sbdiskon));
        }
        $this->print->setLineSpacing(13);
        $this->print-> text("---------------------------------\n");
        $this->print->setLineSpacing(18);
        $this->print-> text(str_pad($qty." Item",9).str_pad("JUMLAH",10)." :".str_pad(number_format($jumlah,0,',','.'),12," ",STR_PAD_LEFT)."\n");
        $this->print->setLineSpacing(13);
        $this->print-> text(str_pad(" ",9).str_pad("DISKON",10)." :".str_pad(number_format($diskon,0,',','.'),12," ",STR_PAD_LEFT)."\n");
        $this->print->setLineSpacing(13);
        $this->print-> text("---------------------------------\n");
        $this->print->setLineSpacing(18);
        $this->print-> text(str_pad(" ",9).str_pad("TOTAL",10)." :".str_pad(number_format(($jumlah-$diskon),0,',','.'),12," ",STR_PAD_LEFT)."\n");
        $this->print->setLineSpacing(13);
        $this->print-> text(str_pad(" ",9).str_pad("BAYAR",10)." :".str_pad(number_format($bayar,0,',','.'),12," ",STR_PAD_LEFT)."\n");
        $this->print->setLineSpacing(13);
        $this->print-> text("---------------------------------\n");
        $this->print->setLineSpacing(13);
        $this->print-> text(str_pad(" ",9).str_pad("KEMBALIAN",10)." :".str_pad(number_format($bayar - ($jumlah-$diskon),0,',','.'),12," ",STR_PAD_LEFT)."\n");
        $this->print-> text("=================================\n");
        /* Title of receipt */
        $this->print->setLineSpacing();
        $this->print-> feed();
        if(strlen($ket) > 0 || $ket != null)
        {
            $this->print->setLineSpacing(18);
            $this->print-> text("Ket:\n");
            $this->print-> text($ket."\n\n");
        }
        $this->print->feed();
        $this->print-> setEmphasis(true);
        $this->print-> setJustification(1);
        $this->print-> text($this->config->item('receipt_footer')."\n");
        $this->print-> setJustification();
        $this->print-> setEmphasis(false);
        $this->print-> cut();
        $this->print-> pulse();

        /* Always close the printer! On some PrintConnectors, no actual
        * data is sent until the printer is closed. */
        $this->print-> close();
    }

    function bayar()
    {
       (!$this->input->is_ajax_request())? show_404():true;
        $post    = $this->input->post();
        $respone = array("code" => 200,
                         "msg"  => "Pembayaran selsesai");
        $this->db->where('kode_faktur', $post['faktur']);
        $bayar = $this->db->get('tb_faktur')->row();
        if($bayar->total_bayar < $bayar->total_tagihan)
        {
            $this->db->where('kode_faktur', $post['faktur']);
            $this->db->set('total_bayar', "(total_bayar + ".str_replace(".","",$post['bayar']).")",FALSE);
            $this->db->update('tb_faktur');
            log_query($this->db->last_query());
            $this->db->where('user_id', $this->session->userdata('id'));
            $this->db->where('date', mdate("%y/%m/%d", now()));
            $this->db->where('status', 0);
            $setor = $this->db->get('tb_setor');

            if($setor->num_rows() == 1)
            {
                $setor = $setor->row();            
                $this->db->where('id', $setor->id);
                $this->db->set('pendapatan',"(pendapatan + $post[sb])", FALSE);
                $this->db->set('invoice',"CONCAT(invoice,'#','$post[faktur]','-1')",FALSE);
                $this->db->update('tb_setor');
                log_query($this->db->last_query());
            }
            else
            {
                $setor = array('invoice' =>  $post['faktur'],
                               'date'    => mdate("%y/%m/%d", now()),
                               'user_id' => $this->session->userdata('id'),
                               'status'  => 0,
                               'pendapatan' => $post['sb']);
                $this->db->insert('tb_setor', array_merge(array("id" => null),$setor));
                log_query($this->db->last_query(),$this->db->insert_id());
            }
        
            $this->cetak_invoice($this->M_transaksi->invoice($post['faktur'],'dp'));
        }
        else
        {
            $respone = array("code" => 200,
                             "msg"  => "Pembayaran telah selasai dilakukan dan tidak ditemukan sisa tagihan");
        }
        echo json_encode($respone);
    }

    function setor($id)
    {
        $post = $this->input->post();
        $id = decode_url($id,'setor');
        $response = array("code" => 200,
                          "msg"  => "Anda berhasil melakukan penyetoran");
        $this->db->where('id', $id);
        $this->db->set('status', 1,FALSE);
        $this->db->set('ket_kasir',$post['ket_kasir']);
        $this->db->update('tb_setor');
        log_query($this->db->last_query());
        echo json_encode($response);

    }

    function konfirmasi_setor($id)
    {
        $post =$this->input->post();
        $id = decode_url($id,'konfirmasi');
        $post['id'] = $id;
        $response = $this->M_transaksi->konfirmasi_setor($post);
        echo json_encode($response);
    }

    function pemasukan()
    {
        $this->benchmark->mark('code_start');
        $post = $this->input->post();
        if(!empty($post))
        {
            echo json_encode($this->M_transaksi->save_transaksi($post));
            return;
        }
        $data['pemasukan'] = $this->M_transaksi->get_transaksi("KREDIT");
        $html = $this->load->view('pemasukan', $data, true);
        $this->benchmark->mark('code_end');
        echo json_encode(array("times" =>$this->benchmark->elapsed_time('code_start', 'code_end'),
                                "html"  => $html));
    }

    function pengeluaran()
    {
        $this->benchmark->mark('code_start');
        $post = $this->input->post();
        if(!empty($post))
        {
            echo json_encode($this->M_transaksi->save_transaksi($post,"DEBET"));
            return;
        }
        $data['pemasukan'] = $this->M_transaksi->get_transaksi("DEBET");
        $html = $this->load->view('pengeluaran', $data, true);
        $this->benchmark->mark('code_end');
        echo json_encode(array("times" =>$this->benchmark->elapsed_time('code_start', 'code_end'),
                                "html"  => $html));

    }

}

/* End of file Transaksi.php */
?>