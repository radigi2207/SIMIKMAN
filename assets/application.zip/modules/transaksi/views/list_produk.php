<div class="modal-header"> <i class="fa fa-th-large" aria-hidden="true"></i> Pencarian Produk</div>  
<div class="modal-body no-padding">
    <!--<div class="row">
        <section class="col col-6">
            <label class="input">
                <input type="text" name="nama_produk" placeholder="Masukan nama / kode produk">
            </label>
        </section>
        <section class="col col-6">
            <label class="select">
                <select name="gender">
                    <option value="0" selected="">Semua Produk</option>
                    <option value="1">Promo Diskon</option>
                    <option value="2">Minuman</option>
                    <option value="3">Makanan</option>
                    <option value="3">Kue Ulang Tahun</option>
                </select> <i></i> </label>
        </section>
    </div>-->
    <div class='row'>
        <section class='col col-lg-12'>
            <!--<table class='table table-striped table-hovered'>
                <thead>
                    <tr>
                        <th>Kode Barang</th>
                        <th>Item</th>
                        <th>Harga</th>
                        <th>Stok</th>
                    </tr>
                </thead>            
            </table>-->
            <table id="datatable_fixed_column" class="table table-striped table-bordered" width="100%">	
                <thead>
                    
                    <tr>
                        <th class="hasinput" style="width:17%">
                            <input type="text" class="form-control" placeholder="Filter Kode Item" />
                        </th>
                        <th class="hasinput" style="width:16%">
                            <input type="text" class="form-control" placeholder="Filter Nama Item" />
                        </th>
                        <th class="hasinput" style="width:16%">
                            <input type="text" class="form-control" placeholder="Filter Nama Kategori" />
                        </th>
                        <th class="hasinput" style="width:17%">
                            <input type="text" class="form-control" placeholder="Filter Harga" />
                        </th>
                        <th class="hasinput" style="width:16%">
                            <input type="text" class="form-control" placeholder="Filter Stok" />
                        </th>
                    </tr>
                    <tr>
                        <th>Kode Item</th>
                        <th>Nama Item</th>
                        <th>Kategori</th>
                        <th>Harga</th>
                        <th>Stok</th>
                    </tr>
                </thead>

                <tbody>
                    
                    
                </tbody>
        
            </table>
        </section>
    </div>
</div>
<div class="modal-footer">
	<button type="button" class="btn btn-danger" data-dismiss="modal">
		Keluar
	</button>
</div>            
</div>  
<script type="text/javascript">
	pageSetUp();

	var pagefunction = function() {
			
			
			var breakpointDefinition = {
				tablet : 1024,
				phone : 480
			};
	    var otable = $('#datatable_fixed_column').DataTable({
	    	"bFilter": true,
            "bServerSide": true,
            "language" : {
            "sSearchPlaceholder":"Silahkan masukan Kode Item, Nama Item, Kategori Item, Harga Item",
            "emptyTable":     "Tak ada data yang tersedia pada tabel",
            "info":           "Tampil _START_ sampai _END_ dari _TOTAL_ records",
            "infoEmpty":      "Tampil 0 sampai 0 dari 0 records",
            "infoFiltered":   "(Pencarian dari _MAX_ total records)",
            "infoPostFix":    "",
            "thousands":      ",",
            "lengthMenu":     "Tampil _MENU_ records",
            "loadingRecords": "Loading...",
            "processing":     "Memproses...",
            "search":         "_INPUT_",
            "zeroRecords":    "Tidak ada data yang cocok ditemukan",
            "paginate":{
            "first":      "Pertama",
            "last":       "Terakhir",
            "next":       "Berikutnya",
            "previous":   "Sebelumnya"
            }
            },
            "sAjaxSource": "<?=site_url("datatable/list_produk")?>",
			"sDom": "<'dt-toolbar'<'col-xs-12 col-sm-12 'f>r>"+
					"t"+
					"<'dt-toolbar-footer'<'col-sm-6 col-xs-12 hidden-xs'i><'col-xs-12 col-sm-6'p>>",		
        });
        otable.columns().every(function(){
            var that = this;
            $('.hasinput input').on('keyup',function(){
                
                if(that.search() !== this.value){
                    otable.column($(this).parent().index()+':visible')
                    .search(this.value).draw();

                }
                
            })
        });
        $('.dataTables_filter label').css('width','100%');
        $('.dataTables_filter label .form-control').css('width','100%');
	};
    loadScript("<?=base_url('assets')?>/js/plugin/datatables/jquery.dataTables.min.js", function(){
            loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.colVis.min.js", function(){
                loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.tableTools.min.js", function(){
                    loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.bootstrap.min.js", function(){
                        loadScript("<?=base_url('assets')?>/js/plugin/datatable-responsive/datatables.responsive.min.js", pagefunction)
                    });
                });
            });
        }); 
        

</script>