<div class='row'>
    <div class='col-lg-9'>
        <div class="well">
            <fieldset>
                <section>
                    <div class=" smart-form">
                        <label class="input">
                            <i class="icon-prepend fa fa-cart-plus input-lg"></i>
                            <input autofocus type="text" class="input-lg" id='search_produk' name='input-item' placeholder='Silahkan Masukan Nama atau Kode Produk'>
                        </label>
                    </div>
                    <!--<div class="col-lg-2">
                        <ul class="demo-btns">
                                <li>
                                    <a href="transaksi/list_penjualan" data-toggle="modal" data-target="#modal_produk" class="btn btn-default txt-color-teal" rel="popover-hover" data-placement="bottom" data-content="Cari Produk" id="detail_produk_list" data-original-title="" title=""><i class="fa fa-search fa-2x"></i></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" id="clear_all_cart" class="btn btn-default txt-color-blue" rel="popover-hover" data-placement="bottom" data-content="Kosongkan Penjualan" data-original-title="" title=""><i class="fa fa-trash-o fa-2x"></i></a>
                                </li>
                                
                            </ul>
                    </div>-->
                </section>
            </fieldset>
        </div>
        <div class="well order-list">
            <fieldset >
                <section>
                    <table class='table table-striped table-bordered table-hover' id="data-cart">
                        <thead>
                            <tr>
                                <th class='text-center'>Opsi</th>
                                <th class='text-center'>Nama Item</th>
                                <th class='text-center'>Harga</th>
                                <th class='text-center'>Qty</th>
                                <th class='text-center'>Diskon</th>                        
                                <th class='text-center'>Sub-Total</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </section>
            </fieldset>
			
			
		</div>
    </div>
    <div class='col-lg-3 '>
        <div class='row'>
                <div class='well'>
                    <fieldset>
                        <section>
                            <ul class="demo-btns">
                                <li>
                                    <a href="transaksi/list_penjualan" data-toggle='modal' data-target='#modal_produk' class="btn btn-default txt-color-teal"
                                    rel="popover-hover" data-placement="bottom" data-content="Cari Produk" id="detail_produk_list"><i class="fa fa-search fa-2x"></i></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);" id="clear_all_cart" class="btn btn-default txt-color-blue"
                                    rel="popover-hover" data-placement="bottom" data-content="Kosongkan Penjualan"><i class="fa fa-trash-o fa-2x"></i></a>
                                </li>
                                
                            </ul>                        
                        </section>
                    </fieldset>
                    <fieldset id="member-input">
                        <section class="smart-form">
                            <label class="input"> <i class="icon-prepend fa fa-user input-lg"></i>
                                <input type="text" class="input-lg" name="member" placeholder="member ID">
                                <b class="tooltip tooltip-top-right font-sm">Masukan ID Member atau nama member</b>
                            </label>
                        </section>
                    </fieldset>
                    <fieldset id="member-info" class="member">
                        <div class="avatar">
                            <img src="<?=base_url('assets/img/no-image.png')?>"></img>
                        </div>
                        <div class="details">
                            <div class="title">Radi Ginanjar, S.Kom</div>
                            <div class="sub-title">
                                <i class="fa fa-phone-square on-left"></i> 085723028647<br>
                                <i class="fa fa-gift on-left"></i> 20.000
                            </div>
                        </div>
                        <div class="footer">
                            <div class='left'><button class='btn btn-warning'><i class='fa fa-gift'></i> Tukar Poin</button></div>
                            <div class='right'> <button class='btn btn-danger' onClick="$('input[name=member]').val('');$('#member-info').fadeOut(300);setTimeout(function(){$('#member-input').fadeIn(500)},400)"><i class='fa fa-close'></i> Batal</button></div>
                        </div>
                    </fieldset>
                </div>

        </div>
        
        <div class='row well'>
            <div>               
                <strong class='pull-right'><span id='total_item'>0</span> Item</strong>
            </div>
            <br>
            <br>
            <div class='font-md'>
                <strong>Total : </strong>
                <span class='pull-right' id='total'>0,00</span>
            </div>
            <div class='font-md txt-color-red'>
                <strong>Diskon : </strong>
                <span class='pull-right' id='diskon'>0,00</span>
            </div>
            <br>
            <div class="total-tagihan text-success">
                <div >
                    <strong>Total Tagihan</strong>
                    
                </div>
                <div class='font-xl'>
                    <Strong><span class="pull-right " id='gt'></span></strong>
                </div>
                <div class='clearfix'>
                </div>
            </div>
            <br>
            <br>
            <div class='pembayaran hidden'>
                <form id="checkout-form" action="<?=site_url('pembayaran_tagihan')?>" method="post" class="smart-form" novalidate="novalidate">
                    <fieldset class='nmt npt npl npr bg-transparent'>
                                    <input type="hidden" name="id_cart">
                                    <input type="hidden" name="member">
                                    <input type="hidden" name="total_tagihan" class='text-right' placeholder="Total Tagihan" readonly id='ttg'>
                        <section>
                            <label class="label">Jenis Pembayaran</label>
                            <div class="inline-group">
                                <label class="radio">
                                    <input type="radio" name="cara_bayar" checked="checked" value="1">
                                    <i></i>Tunai</label>
                                <label class="radio">
                                    <input type="radio" name="cara_bayar" value="2">
                                    
                                    <i></i>Uang Muka</label>
                            </div>
                        </section>
                                
                        <section >
                            <label class="input"> <i class="icon-prepend input-lg fa fa-money"></i>
                                <input type="text" class='text-right input-lg' maxlength="13" name="bayar" placeholder="0,00" autocomplete="off">
                                <b class="tooltip tooltip-top-right font-sm">Masukan Nominal Pembayaran</b>
                            </label>
                        </section>
                        <section class='text-right nmb'>
                            <button type="submit" class="btn btn-primary btn-sm">
                                <i class='fa fa-money'></i> Bayar
                            </button>
                        </section>
                        <section class='nmb'>
                            <label class="label">Keterangan</label>
                            <label class="textarea">
                                <textarea rows="4" name="keterangan"></textarea>
                            </label>
                        </section>
                        
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</div>
<style>

</style>
<div class="modal fade" id="modal_produk" tabindex="-1" role="dialog" data-width='200px' aria-labelledby="remoteModalLabel" aria-hidden="true">  
    <div class="modal-dialog modal-lg">  
        <div class="modal-content">

        </div>  
    </div>  
</div>
<div class='row hidden'>
    <div class='col-lg-12 '>
        
			<!-- Widget ID (each widget will need unique ID)-->
			<div class="jarviswidget" id="wid-id-0">
				<header>
					<span class="widget-icon"> <i class="fa fa-list"></i> </span>
					<h2>DAFTAR PRODUK TERLARIS</h2>				
					
				</header>

				<!-- widget div-->
				<div>
					
					<!-- widget edit box -->
					<div class="jarviswidget-editbox">
						<!-- This area used as dropdown edit box -->
						<input class="form-control" type="text">	
					</div>
					<!-- end widget edit box -->
					
					<!-- widget content -->
					<div class="widget-body">
						
						<div class="col-sm-6 col-md-6 col-lg-2">
                            <!-- product -->
                            <div class="product-content sx product-wrap clearfix">
                                <div class="row">
                                    <div class="col-md-5 col-sm-12 col-xs-12">
                                        <div class="product-image"> 
                                            <img src="tmp/img/demo/e-comm/7.png" alt="194x228" class="img-responsive"> 
                                            <span class="tag1 sale">
                                                -5%
                                            </span> 
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-sm-12 col-xs-12">
                                        <div class="product-deatil">
                                            <h5 class="name">
                                                <a href="#">
                                                    Product Name Title Here <span>Category</span>
                                                </a>
                                            </h5>
                                            <p class="price-container">
                                                <span>$19</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end product -->
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-2">
                            <!-- product -->
                            <div class="product-content sx product-wrap clearfix">
                                <div class="row">
                                    <div class="col-md-5 col-sm-12 col-xs-12">
                                        <div class="product-image"> 
                                            <img src="tmp/img/demo/e-comm/7.png" alt="194x228" class="img-responsive"> 
                                            <span class="tag1 sale">
                                                -5%
                                            </span> 
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-sm-12 col-xs-12">
                                        <div class="product-deatil">
                                            <h5 class="name">
                                                <a href="#">
                                                    Product Name Title Here <span>Category</span>
                                                </a>
                                            </h5>
                                            <p class="price-container">
                                                <span>$19</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end product -->
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-2">
                            <!-- product -->
                            <div class="product-content sx product-wrap clearfix">
                                <div class="row">
                                    <div class="col-md-5 col-sm-12 col-xs-12">
                                        <div class="product-image"> 
                                            <img src="tmp/img/demo/e-comm/7.png" alt="194x228" class="img-responsive"> 
                                            <span class="tag1 sale">
                                                -5%
                                            </span> 
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-sm-12 col-xs-12">
                                        <div class="product-deatil">
                                            <h5 class="name">
                                                <a href="#">
                                                    Product Name Title Here <span>Category</span>
                                                </a>
                                            </h5>
                                            <p class="price-container">
                                                <span>$19</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end product -->
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-2">
                            <!-- product -->
                            <div class="product-content sx product-wrap clearfix">
                                <div class="row">
                                    <div class="col-md-5 col-sm-12 col-xs-12">
                                        <div class="product-image"> 
                                            <img src="tmp/img/demo/e-comm/7.png" alt="194x228" class="img-responsive"> 
                                            <span class="tag1 sale">
                                                -5%
                                            </span> 
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-sm-12 col-xs-12">
                                        <div class="product-deatil">
                                            <h5 class="name">
                                                <a href="#">
                                                    Product Name Title Here <span>Category</span>
                                                </a>
                                            </h5>
                                            <p class="price-container">
                                                <span>$19</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end product -->
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-2">
                            <!-- product -->
                            <div class="product-content sx product-wrap clearfix">
                                <div class="row">
                                    <div class="col-md-5 col-sm-12 col-xs-12">
                                        <div class="product-image"> 
                                            <img src="tmp/img/demo/e-comm/7.png" alt="194x228" class="img-responsive"> 
                                            <span class="tag1 sale">
                                            </span> 
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-sm-12 col-xs-12">
                                        <div class="product-deatil">
                                            <h5 class="name">
                                                <a href="#">
                                                    Product Name Title Here <span>Category</span>
                                                </a>
                                            </h5>
                                            <p class="price-container">
                                                <span>$19</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end product -->
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-2">
                            <!-- product -->
                            <div class="product-content sx product-wrap clearfix">
                                <div class="row">
                                    <div class="col-md-5 col-sm-12 col-xs-12">
                                        <div class="product-image"> 
                                            <img src="tmp/img/demo/e-comm/7.png" alt="194x228" class="img-responsive"> 
                                            <span class="tag1 sale">
                                                -5%
                                            </span> 
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-sm-12 col-xs-12">
                                        <div class="product-deatil">
                                            <h5 class="name">
                                                <a href="#">
                                                    Product Name Title Here <span>Category</span>
                                                </a>
                                            </h5>
                                            <p class="price-container">
                                                <span>$19</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end product -->
                        </div>
					</div>
					<!-- end widget content -->
					
				</div>
				<!-- end widget div -->
				
			</div>
			<!-- end widget -->

    </div>
</div>

<style>
</style>
<script>
$(document).ready(function(){
    if(localStorage.getItem('id_cart') == null)
    {
        localStorage.setItem('id_cart','<?=random_string('alnum',10)?>');
    }
    get_cart();
    $("input[name=bayar]").inputmask("decimal",{
        radixPoint:",", 
        groupSeparator: ".", 
        digits: 0,
        autoGroup: true,
        removeMaskOnSubmit:true
	});
    $('input[name=id_cart]').val(localStorage.getItem('id_cart'));
    $("#clear_all_cart").click(function(e) {
        $.SmartMessageBox({
            title : "Keranjang Belanja",
            content : "Apakah anda yakin akan menghapus data penjualan dari keranjang belanja ini?",
            buttons : '[Tidak][Ya]'
        }, function(ButtonPressed) {
            if (ButtonPressed === "Ya") {
                $.ajax({
                    url:"<?=site_url('remove_all_cart')?>",
                    data:{kode_transaksi:localStorage.getItem('id_cart')},
                    type:'post',
                    success:function(data)
                    {
                        get_cart();
                    }
                });
            }
            

        });
        e.preventDefault();
    });
    
});

var pagefunction = function() {

    var $checkoutForm = $('#checkout-form').validate({
    // Rules for form validation
        rules : {
            bayar:{
                required : true
            }
        },

        // Messages for form validation
        messages : {
            bayar : {
                required : 'Silahkan masukan nominal pembayaran'
            }
        },
        
        submitHandler : function(form) {
            $(form).ajaxSubmit({
                dataType:'json',
                before:function(){
                    alert();
                    return false;
                },
                success : function(data) {
                    console.log(data);
                    if(data.number < 1)
                        $('a[data-action=refreshContent]').click();
                    else
                    {
                        $.SmartMessageBox({
                            title : "<i class='fa fa-money'></i> Kembalian",
                            content : "<h3>"+data.txt+ " <i> => [ "+ terbilang(data.number)+" ]</i></h3>",
                            buttons : '[Keluar]'
                        }, function(ButtonPress) {
                            $('a[data-action=refreshContent]').click();                        
                        });
                    }
                },
                error:function(xhr, status, thrownError, error)
                {
                    $.ajax({
                        url:"<?=site_url('transaksi/table_list_cart')?>",
                        data:{id_cart:localStorage.getItem('id_cart')},
                        type:'post',
                        dataType:'json',
                        success:function(data)
                        {
                           $("#data-cart tbody").html(data.html);
                           $('#total').html(data.total);            
                           $("#diskon").html(data.diskon);
                           $("#gt").html(data.total - data.diskon);
                           $("#ttg").val(data.total - data.diskon)
                           $("[rel=popover], [data-rel=popover]").popover();
                           (data.total_item > 0) ? $(".pembayaran").removeClass('hidden'): $(".pembayaran").addClass('hidden');
                           $("input[name=bayar]").val("");
                           $("textarea[name=keterangan]").val("");
                        }
                    });
                }
            });
        },

        // Do not change code below
        errorPlacement : function(error, element) {
            error.insertAfter(element.parent());
        }
    });		
};

function get_cart()
{
    $.ajax({
        url:"<?=site_url('transaksi/table_list_cart')?>",
        data:{id_cart:localStorage.getItem('id_cart')},
        type:'post',
        dataType:'json',
        success:function(data)
        {
            $("#data-cart tbody").html(data.html);
            $('#total').html(data.text.total);            
            $("#diskon").html(data.text.diskon);
            $("#gt").html(data.text.grand_total);
            $("#ttg").val(data.total - data.diskon)
            $("[rel=popover], [data-rel=popover]").popover();
            (data.total_item > 0) ? $(".pembayaran").removeClass('hidden'): $(".pembayaran").addClass('hidden');
            $("#total_item").html(data.total_item);
        }
    });
}
pageSetUp();
shortcut.add("F1",function() {
	$('#search_produk').focus();
});
shortcut.add("F2",function() {
	$('#detail_produk_list').click();
});
shortcut.add("F4",function() {
    $('input[name=bayar]').focus();
});
shortcut.add("F3",function() {
    $('input[name=member]').focus();
});
shortcut.add("DELETE",function() {
    $('#clear_all_cart').click();
});
$("input[name=member]").autocomplete({
    source : function(request, response) {
        $.ajax({
            url : "<?=site_url('search_member')?>",
            dataType: "json",
            data : {
                featureClass : "P",
                style : "full",
                maxRows : 12,
                search : request.term
            },
            success : function(data) {
                response( $.map( data, function( item ) {
                    return {
                        id:item.id,
                        nama:item.nama,
                        point:item.point
                    }
                }));
            }
        });
    },
    minLength : 2,
    select : function(event, ui) {
        $.ajax({
            url:"<?=site_url('get_member_id')?>",
            data:{id:ui.item.id},
            dataType:'json',
            type:'post',
            success:function(data)
            {
                var point = (data.point == null)?0:data.point;
                $("#member-input").fadeOut(500);
                
                setTimeout(function(){$("#member-info").fadeIn(500);},500);

                $("#member-info .details .title").html(data.nama);
                $("#member-info .details .sub-title").html("<i class='fa fa-phone-square on-left'></i> "+data.no_hp+"<br>"+
                                                    "<i class='fa fa-gift on-left'></i> "+point);
            }

        });
        $("input[name=member]").val(ui.item.id);
        
    }
}).data( "ui-autocomplete" )._renderItem = function( ul, item ) {
    var inner_html = '<a class="suggest-item item-sm"><div class="item-image">' +
                    '</div>' +
                    '<div class="details">';
    inner_html += '<div class="name"> ' + 
                            item.nama +
                        '</div>' +
                        '<span class="attributes">' +
                            'Poin' + ' : <span class="value">' + item.point + '</span>' +
                        '</span>' +
                    '</div>';
    
    return $( "<li class='item-suggestions '></li>" )
        .data( "item.autocomplete", item.id )
        .append(inner_html)
        .appendTo( ul );
        
};
$('input[name=input-item]').focus();
$("#search_produk").autocomplete({
    source : function(request, response) {
        $.ajax({
            url : "<?=site_url('search_produk')?>",
            dataType: "json",
            data : {
                featureClass : "P",
                style : "full",
                maxRows : 12,
                search : request.term
            },
            success : function(data) {

                
                response( $.map( data, function( item ) {
                    return {
                        kode : item.kode,
                        label: item.label,
                        harga: item.harga,
                        image:item.image,
                        discount: item.discount,
                        category:item.kategori
                    }
                }));
            }
        });
    },
    minLength : 2,
    select : function(event, ui) {
        add_cart(ui.item.kode);
        
    },
    delay: 0,
    autoFocus: true,
    response : function(event,ui)
    {
        if(ui.content.length == 1)
        {
            add_cart(ui.content[0].kode);
            $("#search_produk").autocomplete( "close" );
        }
        
    }
}).data( "ui-autocomplete" )._renderItem = function( ul, item ) {
    var inner_html = '<a class="suggest-item"><div class="item-image">' +
                    '<img src="' + item.image + '" alt="">' +
                    '</div>' +
                    '<div class="details">';
    if(item.discount != null ) inner_html += '<span class="tag1"><strong>- '+item.discount+'</strong></span>';

    inner_html += '<div class="name"> ' + 
                            item.label +
                        '</div>' +
                        '<span class="attributes">' +
                            'Category' + ' : <span class="value">' + item.category + '</span>' +
                        '</span>' +
                    '</div>';
    
    return $( "<li class='item-suggestions'></li>" )
        .data( "item.autocomplete", item.value )
        .append(inner_html)
        .appendTo( ul );
        
};
function add_cart(kode)
{
    console.log(kode);
    $.ajax({
        url:"<?=site_url('add_to_cart')?>",
        data:{
            kode_item: kode,
            id_cart:localStorage.getItem('id_cart')
        },
        dataType:'json',
        type:'POST',
        success:function(data){
            $("#data-cart tbody").html(data.html.html);
            $('#total').html(data.html.text.total);            
            $("#diskon").html(data.html.text.diskon);
            $("#gt").html(data.html.text.grand_total);
            $("#ttg").val(data.html.total - data.html.diskon);
            $('#search_produk').val('');
            (data.html.total_item > 0) ? $(".pembayaran").removeClass('hidden'): $(".pembayaran").addClass('hidden');
            $("#total_item").html(data.html.total_item);
            if(data.status.code)
            {
                var color = "#739E73";
                var time  = 3000;
            }
            else
            {
                var color = "#C46A69";
                var time  = 6000;
            }
            $.smallBox({
                title : "["+data.produk.kode_item+"] "+ data.produk.nama_item,
                content : "<i>"+data.status.msg+"</i>",
                color : color,
                iconSmall : "fa fa-shopping-cart bounce animated",
                timeout : time
            });
            $("[rel=popover], [data-rel=popover]").popover();
        }
    });
}
function qty_save(kode_item,new_qty, event)
{
    $.ajax({
        url:'<?=site_url('update_qty_cart')?>',
        data:{
            kode_item:kode_item,
            qty:new_qty,
            kode_transaksi:localStorage.getItem('id_cart')
        },
        dataType:'json',
        type:'post',
        success:function(data){
            $("#data-cart tbody").html(data.html.html);
            $('#total').html(data.html.text.total);
            
            $("#diskon").html(data.html.text.diskon);
            $("#gt").html(data.html.text.grand_total);
            
            $("#ttg").val(data.html.total - data.html.diskon);
            (data.html.total_item > 0) ? $(".pembayaran").removeClass('hidden'): $(".pembayaran").addClass('hidden');
            $("[rel=popover], [data-rel=popover]").popover();
            $("#total_item").html(data.html.total_item);
            if(data.status.code)
            {
                var color = "#739E73";
                var time  = 3000;
            }
            else
            {
                var color = "#C46A69";
                var time  = 6000;
            }
            $.smallBox({
                title : "["+data.produk.kode_item+"] "+ data.produk.nama_item,
                content : "<i>"+data.status.msg+"</i>",
                color : color,
                iconSmall : "fa fa-shopping-cart bounce animated",
                timeout : time
            });
            $("[rel=popover], [data-rel=popover]").popover();
        }

    });
}
function delete_cart(kode_item)
{
    $.ajax({
        url:'<?=site_url('delete_cart')?>',
        data:{
            kode_item:kode_item,
            kode_transaksi:localStorage.getItem('id_cart')
        },
        dataType:'json',
        type:'post',
        success:function(data){
            $("#data-cart tbody").html(data.html.html);
            $('#total').html(data.html.text.total);
            
            $("#diskon").html(data.html.text.diskon);
            $("#gt").html(data.html.text.grand_total);            
            
            $("#ttg").val(data.html.total - data.html.diskon);
            (data.html.total_item > 0) ? $(".pembayaran").removeClass('hidden'): $(".pembayaran").addClass('hidden');
            $("[rel=popover], [data-rel=popover]").popover();
            $("#total_item").html(data.html.total_item);
            if(data.status.code)
            {
                var color = "#739E73";
                var time  = 3000;
            }
            else
            {
                var color = "#C46A69";
                var time  = 6000;
            }
            $.smallBox({
                title : "["+data.produk.kode_item+"] "+ data.produk.nama_item,
                content : "<i>"+data.status.msg+"</i>",
                color : color,
                iconSmall : "fa fa-trash-o bounce animated",
                timeout : time
            });
            $("[rel=popover], [data-rel=popover]").popover();
        }
    })

}
loadScript("<?=base_url("assets/js/plugin/jquery-form/jquery-form.min.js")?>", pagefunction);
</script>