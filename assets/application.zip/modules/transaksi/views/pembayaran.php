<div class="modal-header"> <i class="fa fa-shopping-cart" aria-hidden="true"></i> Pembayaran Tagihan</div>  
<div class="modal-body">  
              
    <form id="checkout-form" action="<?=site_url('pembayaran_tagihan')?>" method="get" class="smart-form" novalidate="novalidate">

		<fieldset class='nmt npt'>
				<section >
					<label class='label'>Total Tagihan</label>
					<label class="input"> <i class="icon-prepend fa fa-money"></i>
						<input type="hidden" name="id_cart">
						<input type="text" name="total_tagihan" class='text-right' placeholder="Total Tagihan" readonly id='ttg'>
					</label>
				</section>
			<div class="row">
				<section class="col col-6">
					<label class="label">Jenis Pembayaran</label>
					<div class="inline-group">
						<label class="radio">
							<input type="radio" name="cara_bayar" checked="checked" value="1">
							<i></i>Tunai</label>
						<label class="radio">
							<input type="radio" name="cara_bayar" value="2">
							<i></i>Uang Muka</label>
					</div>
				</section>
				<section class="col col-6">
					<label class='label'>Nominal Pembayaran</label>
					<label class="input"> <i class="icon-prepend fa fa-money"></i>
						<input type="text" class='text-right' name="bayar" placeholder="0,00" autofocus>
					</label>
				</section>
			</div>
			<section>
				<label class="label">Kembalian</label>
				<label class="textarea"> 										
					<textarea rows="3" class="custom-scroll"></textarea> 
				</label>
			</section>
		</fieldset>
		<footer>
			<button type="submit" class="btn btn-primary">
				Bayar
			</button>
			<button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>  
		</footer>  
		<div class="message">
			<i class="fa fa-check fa-lg"></i>
			<p>
				Your comment was successfully added!
			</p>
		</div>
	</form>
              
</div>  
<script type="text/javascript">
	pageSetUp();
	
	function bayar(event)
	{
		console.log(event);
		return false;
	}	
	// PAGE RELATED SCRIPTS

	// pagefunction
	
	var pagefunction = function() {

		var $checkoutForm = $('#checkout-form').validate({
		// Rules for form validation
			rules : {
				bayar:{
					required : true
				}
			},
	
			// Messages for form validation
			messages : {
				bayar : {
					required : 'Silahkan masukan nominal pembayaran'
				}
			},
			
			submitHandler : function(form) {
				$(form).ajaxSubmit({
					success : function() {
						$("#checkout-form").addClass('submited');
						$.ajax({
							url:"<?=site_url('transaksi/table_list_cart')?>",
							data:{id_cart:localStorage.getItem('id_cart')},
							type:'post',
							dataType:'json',
							success:function(data)
							{
								$("#data-cart tbody").html(data.html);
								$('#total').val(data.total);            
								$("#diskon").val(data.diskon);
								$("#gt").val(data.total - data.diskon);
								$("[rel=popover], [data-rel=popover]").popover();
							}
						});
					},
					error:function(xhr, status, thrownError, error)
					{
						$.smallBox({
							title : "Pembayaran Tagihan",
							content : "<i class='fa fa-clock-o'></i> <i>Pembayaran tagihan yang anda lakukan Gagal. Silahkan ulangi kembali</i>",
							color : "#C46A69",
							iconSmall : "fa fa-times fa-2x fadeInRight animated",
							timeout : 4000
						});
					}
				});
			},
	
			// Do not change code below
			errorPlacement : function(error, element) {
				error.insertAfter(element.parent());
			}
		});		
	};
	$(document).ready(function(){
		$('input[name=id_cart]').val(localStorage.getItem('id_cart'));
		$('#ttg').val($('#gt').val());
		shortcut.add("F1",function() {
			$('input[name=bayar]').focus();
		});
	});
	
	// end pagefunction
	
	// Load form valisation dependency 
	loadScript("<?=base_url("assets/js/plugin/jquery-form/jquery-form.min.js")?>", pagefunction);

</script>