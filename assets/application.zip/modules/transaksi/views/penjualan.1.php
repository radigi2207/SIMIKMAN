<div class='row'>
    <div class='col-lg-9 '>
        
			<!-- Widget ID (each widget will need unique ID)-->
			<div class="jarviswidget" id="wid-id-0">
                <header>
					<span class="widget-icon"> <i class="fa fa-list"></i> </span>
					<h2>DAFTAR PRODUK</h2>			
						<div class="widget-toolbar smart-form npl npr">
							
							<label class="select">
                                <select name="kategori">
                                    <option value="0" selected="">Semua Kategori</option>
                                    <option value="1">less than 5000$</option>
                                    <option value="2">5000$ - 10000$</option>
                                    <option value="3">10000$ - 20000$</option>
                                    <option value="4">more than 20000$</option>
                                </select> <i></i>
                            </label>

						</div>
					
				</header>

				<!-- widget div-->
				<div>
					
					<!-- widget edit box -->
					<div class="jarviswidget-editbox">
						<!-- This area used as dropdown edit box -->
						<input class="form-control" type="text">	
					</div>
					<!-- end widget edit box -->
					
					<!-- widget content -->
					<div class="widget-body">
						
						<div class="col-sm-6 col-md-6 col-lg-4">
                            <!-- product -->
                            <div class="product-content sx product-wrap clearfix">
                                <div class="row">
                                        <div class="col-md-5 col-sm-12 col-xs-12">
                                            <div class="product-image"> 
                                                <img src="tmp/img/demo/e-comm/7.png" alt="194x228" class="img-responsive"> 
                                                <span class="tag2 sale">
                                                    Sale
                                                </span> 
                                            </div>
                                        </div>
                                        <div class="col-md-7 col-sm-12 col-xs-12">
                                        <div class="product-deatil">
                                                <h5 class="name">
                                                    <a href="#">
                                                        Product Name Title Here <span>Category</span>
                                                    </a>
                                                </h5>
                                                <p class="price-container">
                                                    <span>$99</span>
                                                </p>
                                                <span class="tag1"></span> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end product -->
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-4">
                            <!-- product -->
                            <div class="product-content sx product-wrap clearfix">
                                <div class="row">
                                        <div class="col-md-5 col-sm-12 col-xs-12">
                                            <div class="product-image"> 
                                                <img src="tmp/img/demo/e-comm/7.png" alt="194x228" class="img-responsive"> 
                                                <span class="tag2 sale">
                                                    Sale
                                                </span> 
                                            </div>
                                        </div>
                                        <div class="col-md-7 col-sm-12 col-xs-12">
                                        <div class="product-deatil">
                                                <h5 class="name">
                                                    <a href="#">
                                                        Product Name Title Here <span>Category</span>
                                                    </a>
                                                </h5>
                                                <p class="price-container">
                                                    <span>$99</span>
                                                </p>
                                                <span class="tag1"></span> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end product -->
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-4">
                            <!-- product -->
                            <div class="product-content sx product-wrap clearfix">
                                <div class="row">
                                        <div class="col-md-5 col-sm-12 col-xs-12">
                                            <div class="product-image"> 
                                                <img src="tmp/img/demo/e-comm/7.png" alt="194x228" class="img-responsive"> 
                                                <span class="tag2 sale">
                                                    Sale
                                                </span> 
                                            </div>
                                        </div>
                                        <div class="col-md-7 col-sm-12 col-xs-12">
                                        <div class="product-deatil">
                                                <h5 class="name">
                                                    <a href="#">
                                                        Product Name Title Here <span>Category</span>
                                                    </a>
                                                </h5>
                                                <p class="price-container">
                                                    <span>$99</span>
                                                </p>
                                                <span class="tag1"></span> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end product -->
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-4">
                            <!-- product -->
                            <div class="product-content sx product-wrap clearfix">
                                <div class="row">
                                        <div class="col-md-5 col-sm-12 col-xs-12">
                                            <div class="product-image"> 
                                                <img src="tmp/img/demo/e-comm/7.png" alt="194x228" class="img-responsive"> 
                                                <span class="tag2 sale">
                                                    Sale
                                                </span> 
                                            </div>
                                        </div>
                                        <div class="col-md-7 col-sm-12 col-xs-12">
                                        <div class="product-deatil">
                                                <h5 class="name">
                                                    <a href="#">
                                                        Product Name Title Here <span>Category</span>
                                                    </a>
                                                </h5>
                                                <p class="price-container">
                                                    <span>$99</span>
                                                </p>
                                                <span class="tag1"></span> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end product -->
                        </div>


					</div>
					<!-- end widget content -->
					
				</div>
				<!-- end widget div -->
				
			</div>
			<!-- end widget -->

    </div>

    <div class='col-lg-3'>
        <div class='row' style='height:400px;'>
            <div class='col-lg-12' style='height:100%'>
                <div class="well" style='height:95%'>
                    
                    <table class='table table-triped table-bordered'>
                        <thead>
                            <tr>
                                <th class='text-center'>Item</th>
                                <th class='text-center'>Harga</th>
                                <th class='text-center'>Qty</th>                        
                                <th class='text-center'>Sub-Total</th>
                            </tr>
                        </thead>
                    </table>
                    
                </div>
            </div>
        </div>
        <div class'row'>
            <div class='col-lg-12 ' style='height:100%'>
                <div class='well'  style='height:30%'>
                    <ul class="demo-btns">
                        <li>
                            <a href="javascript:void(0);" class="btn btn-default txt-color-blueLight"
                            rel="popover-hover" data-placement="bottom" data-content="Penjualan baru"><i class="fa fa-shopping-cart fa-2x"></i></a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" class="btn btn-default txt-color-blue"
                            rel="popover-hover" data-placement="bottom" data-content="Kosongkan Penjualan"><i class="fa fa-trash-o fa-2x"></i></a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" class="btn btn-default txt-color-teal"
                            rel="popover-hover" data-placement="bottom" data-content="Member"><i class="fa fa-user fa-2x"></i></a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" class="btn btn-default txt-color-teal"
                            rel="popover-hover" data-placement="bottom" data-content="Cari Produk"><i class="fa fa-search fa-2x"></i></a>
                        </li>

                    </ul>
                </div>
                <div class='well form-horizontal'  style='height:60%'>
                    <fieldset>
                        <div class="form-group">
                            <label class="col-md-4 control-label">Total</label>
                            <div class="col-md-8">
                                <div class="input-group">
                                    <input class="form-control text-right" type="text" readonly disabled>
                                </div>
                            </div>

                        </div>

                        <div class="form-group ">
                            <label class="col-md-4 control-label">Diskon</label>
                            <div class="col-md-8">
                                <div class="input-group">
                                    <input class="form-control text-right" readonly disabled type="text">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-4 control-label">Grand Total</label>
                            <div class="col-md-8">
                                <div class="input-group">
                                    <input class="form-control text-right" readonly disabled type="text">
                                </div>
                            </div>
                        </div>
                        <a href="transaksi/pembayaran" class="btn btn-success btn-lg btn-block"  data-toggle="modal" data-target="#modal_bayar">
                            <i class='fa fa-money'></i> Bayar
                        </a>
                        
                        
                    </fieldset>
                </div>
            </div>
        </div>
        <div class="modal fade" id="modal_bayar" tabindex="-1" role="dialog" aria-labelledby="remoteModalLabel" aria-hidden="true">  
            <div class="modal-dialog">  
                <div class="modal-content">

                </div>  
            </div>  
        </div>
    </div>
</div>


<style>
/*.demo-btns>li:after{
    content:' ';
    float:right;
    margin-right:7px !important;

}
.demo-btns>li:last-child{
    margin-right:-7px !important;

}*/
</style>
<script>
pageSetUp();
shortcut.add("F11",function() {
	alert("Hello!");
});
</script>