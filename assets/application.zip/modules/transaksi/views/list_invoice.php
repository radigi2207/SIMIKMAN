<section id="widget-grid" class="">
	<div class="row">
		<article class="col-sm-12 col-md-12 col-lg-12">
			<div class="jarviswidget jarviswidget-color-darken" id="wid-id-1" data-widget-editbutton="false" data-widget-custombutton="false"
             data-widget-deletebutton="false">
				<header>
                    <span class="widget-icon"> <i class="fa fa-cart-arrow-down"></i> </span>
                    <h2>
                        Invoice
                    </h2>
                </header>
				<div>
					<div class="widget-body no-padding">
                        <table id="invoice" class="table table-striped table-bordered table-hover" width="100%">
                            <thead>
                                <tr>
                                    <th class="hasinput" style="width:15%">
                                        <input type="text" class="form-control" placeholder="Filter No Invoice" />
                                    </th>
                                    <th class="hasinput" style="width:15%">
                                        <input type="text" class="form-control" placeholder="Filter ID Pelanggan" />
                                    </th>
                                    <th class="hasinput icon-addon" >
                                        <input type="text" class=" date form-control text-center" id='tgl_transaksi' placeholder="Filter Tgl. Transaksi" />
                                        <label for="dateselect_filter" class="glyphicon glyphicon-calendar no-margin padding-top-15 padding-5" rel="tooltip" title="" data-original-title="Purchase Date"></label>
                                    </th>
                                    <th class="hasinput" style="width:15%">
                                        <input type="text" class="form-control" placeholder="Filter Total Tagihan" />
                                    </th>
                                    <th class="hasinput" style="width:15%">
                                        <input type="text" class="form-control" placeholder="Filter Keterangan" />
                                    </th>
                                    <th style="width:10%">
                                    </th>
                                    <th style="width:10%">
                                       
                                    </th>
                                </tr>
                                <tr>
                                    <th data-class="expand" class='text-center'>No Invoice</th>
                                    <th class='text-center'>Id Pelanggan</th>
                                    <th class='text-center' data-hide="phone">Tgl. Transaksi</th>
                                    <th class='text-center' data-hide="phone">Total Tagihan</th>
                                    <th class='text-center' data-hide="phone,tablet">Keterangan</th>
                                    <th class='text-center' >Status</th>
                                    <th class='text-center' data-hide="phone,tablet">Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
					</div>
				</div>
			</div>
		</article>
	</div>
</section>
<div class="modal fade" id="modal_bayar" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="remoteModalLabel" aria-hidden="true">  
    <div class="modal-dialog">  
        <div class="modal-content">

        </div>  
    </div>  
</div>
<script type="text/javascript">
pageSetUp();
$(document).ready(function(){
    $("#modal_bayar").on("shown.bs.modal",function(){
        $(this).find("input[name=bayar]").focus();
    });
});
    var pagefunction = function() {

    $('#tgl_transaksi, #tgl_bayar').datepicker({
        dateFormat : 'yy-mm-dd',
        prevText : '<i class="fa fa-chevron-left"></i>',
        nextText : '<i class="fa fa-chevron-right"></i>'
    });
    
	var responsiveHelper_datatable_fixed_column = undefined;
    var breakpointDefinition = {
				tablet : 1024,
				phone : 480,
                desktop:1366
			};
    
    var itable = $('#invoice').DataTable({
            "sDom": "<'dt-toolbar'<'col-xs-12 col-sm-6'f>r>"+
                "t"+
                "<'dt-toolbar-footer'<'col-sm-6 col-xs-12 hidden-xs'i><'col-xs-12 col-sm-6'p>>",
            "bFilter": true,
            "bServerSide": true,
            "language" : {
                "sSearchPlaceholder":"Silahkan masukan Kode Item, Nama Item, Kategori Item, Harga Item",
                "emptyTable":     "Tak ada data yang tersedia pada tabel",
                "info":           "Tampil _START_ sampai _END_ dari _TOTAL_ records",
                "infoEmpty":      "Tampil 0 sampai 0 dari 0 records",
                "infoFiltered":   "(Pencarian dari _MAX_ total records)",
                "infoPostFix":    "",
                "thousands":      ",",
                "lengthMenu":     " _MENU_",
                "loadingRecords": "Loading...",
                "processing":     "Memproses...",
                "search":         "_INPUT_",
                "zeroRecords":    "Tidak ada data yang cocok ditemukan",
                "paginate":{
                    "first":      "Pertama",
                    "last":       "Terakhir",
                    "next":       "Berikutnya",
                    "previous":   "Sebelumnya"
                }
            },            
            "columnDefs":[{"targets" : 5,
                           "orderable":false},
                          {"targets" : 6,
                           "orderable":false}],
            "sAjaxSource": "<?=site_url("tablegrid/invoice")?>",
            "autoWidth" : true,
			"preDrawCallback" : function() {
				// Initialize the responsive datatables helper once.
				if (!responsiveHelper_datatable_fixed_column) {
					responsiveHelper_datatable_fixed_column = new ResponsiveDatatablesHelper($('#invoice'), breakpointDefinition);
				}
			},
			"rowCallback" : function(nRow) {
				responsiveHelper_datatable_fixed_column.createExpandIcon(nRow);
			},
			"drawCallback" : function(oSettings) {
				responsiveHelper_datatable_fixed_column.respond();
			}
        });

        itable.columns().every(function(){
            var that = this;
            
            $('.hasinput input').on('keyup',function(){
                if(that.search() !== this.value){
                    itable.column($(this).parent().index()+':visible')
                    .search(this.value).draw();

                }
                
            });
            $('.hasinput .date').on('change',function(){
                if(that.search() !== this.value){
                    itable.column($(this).parent().index()+':visible')
                    .search(this.value).draw();

                }
            });
        });
    };
    


loadScript("<?=base_url('assets')?>/js/plugin/datatables/jquery.dataTables.min.js", function(){
    loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.colVis.min.js", function(){
        loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.tableTools.min.js", function(){
            loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.bootstrap.min.js", function(){
                loadScript("<?=base_url('assets')?>/js/plugin/datatable-responsive/datatables.responsive.min.js", pagefunction)
            });
        });
    });
});

function invoice(faktur)
{
    $.ajax({
        url : "<?=site_url('transaksi/re_cetak_invoice')?>",
        data:{kode_faktur:faktur},
        type:"post",
        success:function(){

        }
    });
}
</script>