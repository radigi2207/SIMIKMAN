<section >
    <div class="row">
        <div class="col-sm-12 col-xs-12 col-lg-6 ">
            <div class="jarviswidget jarviswidget-color-darken">
				<header>
					<span class="widget-icon"> <i class="fa fa-edit"></i> </span>
					<h2>Form Pemasukan </h2>				
					
				</header>

				<!-- widget div-->
				<div>
					
					<!-- widget edit box -->
					<div class="jarviswidget-editbox">
						<!-- This area used as dropdown edit box -->
						
					</div>
					<!-- end widget edit box -->
					
					<!-- widget content -->
					<div class="widget-body no-padding">
						
						<form action="<?=site_url('pemasukan')?>" id="pemasukan" class="smart-form" method="post" novalidate="novalidate">
							<header>
								Pemasukan
							</header>
							<fieldset>
								<section>
									<label class="input"> <i class="icon-prepend fa fa-money"></i>
										<input type="text" name="transaksi" placeholder="Transaksi">
									</label>
								</section>
								<section>
									<label class="input"> <span class="icon-prepend"><?=$this->config->item('currency_symbol')?></span>
										<input type="text" maxlength="13" class="text-right" name="nominal" placeholder="Jumlah Uang">
									</label>
								</section>
								
								<section>
									<label class="label"></label>
									<label class="textarea">										
										<textarea rows="3" name="keterangan" placeholder="Keterangan"></textarea> 
									</label>
								</section>
							</fieldset>
							<footer>
								<button type="submit" class="btn btn-primary">
									Simpan
								</button>
							</footer>
						</form>						
						
					</div>
					<!-- end widget content -->
					
				</div>
				<!-- end widget div -->
				
			</div>
            
        </div>
        <div class="col-sm-12 col-xs-12 col-lg-6 ">
            <div class="well">
                <div id="chart_pemasukan" class="chart no-padding"></div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12">
            <div class="well">
                <h1>Daftar transaksi</h1>
                
                <div class="alert alert-info">
                    Silahkan pilih tanggal untuk melihat rincian transaksi pemasukan
                </div>
                
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th style="width:10%">Tanggal</th>
                            <th style="width:30%">Transaksi</th>
                            <th style="width:15%">Nominal</th>
                            <th style="width:45%">Keterangan</th>
                        </tr>                                            
                    </thead> 
                    <tbody>
                        <?foreach($pemasukan->result_array() as $row):?>
                        <tr>
                            <td><?=mdate("%d-%m-%Y",strtotime($row['tgl']))?></td>
                            <td><?=$row['transaksi']?></td>
                            <td class="text-right"><?=number_format($row['nominal'],0,',','.')?></td>
                            <td><?=$row['keterangan']?></td>
                        </tr>                                         
                        <?endforeach;?>                                                                                                
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="4">
                            </td>
                        </tr>
                    </tfoot>  
                </table>
            
                
            </div>

        </div>

    </div>
</section>
<script type="text/javascript">
var plot_7;
$(document).ready(function(){
	$('#tgl').datepicker({
        dateFormat : 'dd-mm-yy',
        prevText : '<i class="fa fa-chevron-left"></i>',
        nextText : '<i class="fa fa-chevron-right"></i>'
    });
});
pageSetUp()

var pagefunction = function(){
	$("input[name=nominal]").inputmask("decimal",{
        radixPoint:",", 
        groupSeparator: ".",
        digits: 0,
        autoGroup: true,
        removeMaskOnSubmit:true
	});
	var simpan = $("#pemasukan").validate({

         rules : {
            transaksi:{
                required:true,
            },
            nominal:{
                required : true,
            }            
        },

        // Messages for form validation
        messages : {
            transaksi:{
                required:'Silahkan masukan nama transaksi'
            },
            nominal:{
                required: "Silahkan masukan nominal pemasukan",
            }
        },
        submitHandler : function(form) {
            $(form).ajaxSubmit({
                dataType:'json',
                success : function(data) {
                    if(data.code == 200)
                    {
                        var color = "#739E73";
                        var time  = 3000;
                    }
                    else
                    {
                        var color = "#C46A69";
                        var time  = 6000;
                    }
                    $.smallBox({
                        title : "Transaksi Pengeluaran",
                        content : "<i>"+data.msg+"</i>",
                        color : color,
                        iconSmall : "fa fa-arrow-up bounce animated",
                        timeout : time
                    });
                    $('a#refresh').click();
                   
                }
            });
        },

        // Do not change code below
        errorPlacement : function(error, element) {
            error.insertAfter(element.parent());
        }
    });
	var p;
    if ($('#chart_pemasukan').length){ 
        var day_data = [
            {"period": "2012-10-01", "nominal": 3407},
        ];
        p = Morris.Line({
            element: 'chart_pemasukan',
            data: day_data,
            xkey: 'period',
            ykeys: ['nominal'],
            labels: ['nominal'],
            /* custom label formatting with `xLabelFormat` */
            xLabelFormat: function(d) { return (d.getMonth()+1)+'-'+d.getDate()+'-'+d.getFullYear(); },
            /* setting `xLabels` is recommended when using xLabelFormat */
            xLabels: 'day'
        });
    }

	$.ajax({
		url:"<?=site_url('laporan/chart_transaksi')?>",
		dataType:'json',
		success:function(data){
			p.setData(data);
		}
	});
}

loadScript("<?=base_url('assets')?>/js/plugin/morris/raphael.min.js", function(){
    loadScript("<?=base_url('assets')?>/js/plugin/morris/morris.min.js", function(){
        loadScript("<?=base_url("assets/js/plugin/jquery-form/jquery-form.min.js")?>",pagefunction);
    });
});
// loadScript("<?=base_url('assets')?>/js/plugin/flot/jquery.flot.cust.min.js", function(){
//     loadScript("<?=base_url('assets')?>/js/plugin/flot/jquery.flot.resize.min.js", function(){
//         loadScript("<?=base_url('assets')?>/js/plugin/flot/jquery.flot.fillbetween.min.js", function(){
//             loadScript("<?=base_url('assets')?>/js/plugin/flot/jquery.flot.orderBar.min.js", function(){
//                 loadScript("<?=base_url('assets')?>/js/plugin/flot/jquery.flot.pie.min.js", function(){
//                     loadScript("<?=base_url('assets')?>/js/plugin/flot/jquery.flot.time.min.js", function(){
//                         loadScript("<?=base_url('assets')?>/js/plugin/flot/jquery.flot.tooltip.min.js", function(){
//                             loadScript("<?=base_url("assets/js/plugin/jquery-form/jquery-form.min.js")?>", pagefunction);
//                         });
//                     });
//                 });
//             });
//         });
//     });
// });
</script>