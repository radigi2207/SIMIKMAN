<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_laporan extends CI_Model {

    public function __construct()
    {
        parent::__construct();
        //Do your magic here
    }

    function chart_transaksi($type = "KREDIT")
    {
        $select = array();
        for ($i=0; $i < 7; $i++)
        {
            $date = date_create(mdate("%Y-%m-%d",now()));
            $date = date_sub($date,date_interval_create_from_date_string($i.' days'));
            $date = date_format($date,'Y/m/d');
            $select[] = "SUM(IF('$date' = DATE_FORMAT(tgl,'%Y/%m/%d'),nominal,0)) AS '$date'";
        }

        $this->db->select(join($select,','));
        $this->db->where('type', $type);
        return $this->db->get('tb_rek');
    }

    function laporan_barang($where = null, $order=null, $limit=null)
    {
        if($where == null && $order == null && $limit == null)
            return $this->db->count_all('tb_transaksi');
        
        $this->db->select("f.kode_faktur,p.kode_item, p.nama_item,t.tgl,t.qty, CONCAT(u.first_name,' ',u.last_name) AS 'sales'");
        $this->db->join('tb_faktur f', 'f.kode_faktur = t.kode_transaksi');
        $this->db->join('tb_users u', 'f.karyawan = u.id');
        $this->db->join('tb_produk p', 'p.kode_item = t.kode_item');
        $this->db->like($where);
        if($limit != null)
            $this->db->limit($limit['limit'],$limit['start']);
        $this->db->order_by($order['field'], $order['dir']);
        return $this->db->get('tb_transaksi t');
    }
    

}

/* End of file M_laporan.php */
?>