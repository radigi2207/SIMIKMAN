<section>
	<div class="row">
        <div class="col-sm-12">
            <div class="jarviswidget jarviswidget-color-darken">
				<header>
					<span class="widget-icon"> <i class="fa fa-cart-arrow-down"></i> </span>
					<h2>Laporan Barang Keluar</h2>
				</header>
                <div>
					<div class="widget-body no-padding">
                        <table class="table table-striped table-bordered table-hover" width="100%" id="laporan-barang" >
                            <thead>
                                <tr class="smart-form">
                                    <th class="hasinput" style="width:15%">
                                        <label class="input"> <i class="icon-prepend fa fa-ticket"></i>
                                            <input type="text" class="form-control">
                                        </label>
                                    </th>
                                    <th class="hasinput" style="width:15%">
                                        <label class="input"> <i class="icon-prepend fa fa-barcode"></i>
                                            <input type="text" class="form-control">
                                        </label>
                                    </th>
                                    <th class="hasinput" style="width:25%">
                                        <label class="input"> <i class="icon-prepend fa fa-cube"></i>
                                            <input type="text" class="form-control">
                                        </label>
                                    </th>
                                    <th class="hasinput" style="width:10%">
                                        <label class="input"> <i class="icon-prepend fa fa-calendar"></i>
                                            <input type="text"  class="date text-center form-control datepicker" placeholder="Tanggal" data-dateformat="dd-mm-yy">
                                        </label>
                                    </th>
                                    <th class="hasinput" style="width:10%">
                                        <label class="input"> <i class="icon-prepend fa fa-cart-plus"></i>
                                            <input type="text" class="form-control">
                                        </label>
                                    </th>
                                    <th class="hasinput" style="width:20%">
                                        <label class="input"> <i class="icon-prepend fa fa-user"></i>
                                            <input type="text" class="form-control">
                                        </label>
                                    </th>
                                </tr>
                                <tr>
                                    <th data-class="expand">No. Faktur</th>
                                    <th data-hide='phone'>upc/ean/isbn</th>
                                    <th>Nama Produk</th>
                                    <th data-hide='phone, tablet'>Tanggal</th>
                                    <th data-hide='phone, tablet'>Qty</th>
                                    <th data-hide='phone, tablet'>Sales</th>
                                </tr>
                            </thead>
                            <tbody>
                           
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script type="text/javascript">
pageSetUp();
	
	var pagefunction = function() {
		
		var laporan_barang = undefined;
		
		var breakpointDefinition = {
			tablet : 1024,
			phone : 480
		};

        $(".curency").inputmask("decimal",{
            radixPoint:",", 
            groupSeparator: ".", 
            digits: 0,
            autoGroup: true
        });
	    var otable = $('#laporan-barang').DataTable({
			"sDom": "<'dt-toolbar'<'col-xs-12 col-sm-6 hidden-xs'><'col-sm-6 col-xs-12 hidden-xs'<'toolbar'>>r>"+
					"t"+
					"<'dt-toolbar-footer'<'col-sm-6 col-xs-12 hidden-xs'i><'col-xs-12 col-sm-6'p>>",
			"autoWidth" : true,
            "bFilter": true,
            "bServerSide": true,
            "language" : {
                "sSearchPlaceholder":"Silahkan masukan Kode Item, Nama Item, Kategori Item, Harga Item",
                "emptyTable":     "Tak ada data yang tersedia pada tabel",
                "info":           "Tampil _START_ sampai _END_ dari _TOTAL_ records",
                "infoEmpty":      "Tampil 0 sampai 0 dari 0 records",
                "infoFiltered":   "(Pencarian dari _MAX_ total records)",
                "infoPostFix":    "",
                "thousands":      ",",
                "lengthMenu":     " _MENU_",
                "loadingRecords": "Loading...",
                "processing":     "Memproses...",
                "search":         "_INPUT_",
                "zeroRecords":    "Tidak ada data yang cocok ditemukan",
                "paginate":{
                    "first":      "Pertama",
                    "last":       "Terakhir",
                    "next":       "Berikutnya",
                    "previous":   "Sebelumnya"
                }
            },
            "columns" :[
                {"name" : "f.kode_faktur"},
                {"name" : "p.kode_item"},
                {"name" : "p.nama_item"},
                {"name" : "t.tgl"},
                {"name" : "t.qty"},
                {"name" : "sales"},
            ],

            "ajax": {
                "url" :"<?=site_url("tablegrid/laporan_barang")?>"
            },
            "autoWidth" : true,
			"preDrawCallback" : function() {
				// Initialize the responsive datatables helper once.
				if (!laporan_barang) {
					laporan_barang = new ResponsiveDatatablesHelper($('#laporan-barang'), breakpointDefinition);
				}
			},

			"rowCallback" : function(nRow) {
				laporan_barang.createExpandIcon(nRow);
			},
			"drawCallback" : function(oSettings) {
				laporan_barang.respond();
			}		
		
	    });

	    // Apply the filter
	    $("#laporan-barang thead th input[type=text]").on( 'keyup change', function () {
	    	
	        otable
	            .column( $(this).parent().parent().index()+':visible' )
	            .search( this.value )
	            .draw();
	            
	    } );
	    /* END COLUMN FILTER */   

	};

	// load related plugins
	
loadScript("<?=base_url('assets')?>/js/plugin/datatables/jquery.dataTables.min.js", function(){
    loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.colVis.min.js", function(){
        loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.tableTools.min.js", function(){
            loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.bootstrap.min.js", function(){
                loadScript("<?=base_url('assets')?>/js/plugin/datatable-responsive/datatables.responsive.min.js", pagefunction)
            });
        });
    });
});
</script>