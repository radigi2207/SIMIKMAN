<section id="widget-grid" class="">

	<!-- row -->
	<div class="row">

		<!-- NEW WIDGET START -->
		<article class="col-xs-12 col-sm-6 col-md-6 col-lg-6">

			<!-- Widget ID (each widget will need unique ID)-->
			<div class="jarviswidget well jarviswidget-color-darken" data-widget-sortable="false" data-widget-deletebutton="false" data-widget-editbutton="false" data-widget-colorbutton="false">
				<header>
					<span class="widget-icon"> <i class="fa fa-barcode"></i> </span>
					<h2>Item #44761 </h2>

				</header>

				<!-- widget div-->
				<div>

					<!-- widget edit box -->
					<div class="jarviswidget-editbox">
						<!-- This area used as dropdown edit box -->

					</div>
					<!-- end widget edit box -->

					<!-- widget content -->
					<div class="widget-body no-padding">
						<div class="widget-body-toolbar">
							<div class="row">
								<div class="col-sm-8 col-sm-offset-4 text-align-right">
									<div class="btn-group">
										
									</div>

								</div>

							</div>

						</div>

						<div>
							<table class="table table-border table-striped table-hover" id="setor">
								<thead>
									<tr class="smart-form">
										<th class="hasinput">
											<label class="input"> <i class="icon-prepend fa fa-calendar"></i>
												<input type="text"  class="date text-center form-control datepicker" placeholder="Tanggal" data-dateformat="dd-mm-yy">
											</label>
										</th>
										<th class="hasinput" width="30%">
											<label class="input"> <i class="icon-prepend fa fa-money"></i>
												<input type="text" class="curency form-control" placeholder="Pendapatan">
											</label>											
										</th>
										<th class="hasinput" width="30%">
										</th>
									</tr>
									<tr>
										<th><center>Tanggal</center></th>
										<th><center>Pendapatan</center></th>
										<th><center>Status</center></th>
									</tr>
								</thead>
								<tbody>
								<?foreach($setor->result_array() as $row)
								{
									if($row['status'] == 0)
										$status = "<span class='bg-color-orange label'>kasir</span>";
									elseif($row['status'] == 1)
										$status = '<a href="'.site_url('modal/setor/'.encode_url($row['id'],'konfirmasi')).'" data-toggle="modal" data-target="#modal_setor" class="btn btn-xs btn-primary"> <i class="fa fa-check"></i> Konfirmasi</a>';
									else
										$status = "<span class='bg-color-green label'>selesai</span>";
									?>
									<tr>
										<td><center><?=$row['tgl']?></center></td>
										<td class='text-right'><?=number_format($row['pendapatan'],0,',','.')?></td>
										<td><center><?=$status?></center></td>
									</tr>
									<?
								}
								?>
								</tbody>
							</table>
						</div>

					</div>
					<!-- end widget content -->

				</div>
				<!-- end widget div -->

			</div>
			<!-- end widget -->

		</article>
		<!-- WIDGET END -->

	</div>

	<!-- end row -->

</section>
<div class="modal fade" id="modal_setor" tabindex="-1" data-backdrop="static" data-keyboard="false" role="modal" aria-labelledby="remoteModalLabel" aria-hidden="true">  
    <div class="modal-dialog">  
        <div class="modal-content">

        </div>  
    </div>  
</div>
<script type="text/javascript">


	pageSetUp();
	
	var pagefunction = function() {
		
		var setor = undefined;
		
		var breakpointDefinition = {
			tablet : 1024,
			phone : 480
		};

        $(".curency").inputmask("decimal",{
            radixPoint:",", 
            groupSeparator: ".", 
            digits: 0,
            autoGroup: true
        });

		// $('.date').datepicker({
		// 	dateFormat : 'yy-mm-dd',
		// 	prevText : '<i class="fa fa-chevron-left"></i>',
		// 	nextText : '<i class="fa fa-chevron-right"></i>'
		// });

		/* END BASIC */
		
		/* COLUMN FILTER  */
	    var otable = $('#setor').DataTable({
			"sDom": "<'dt-toolbar'<'col-xs-12 col-sm-6 hidden-xs'><'col-sm-6 col-xs-12 hidden-xs'<'toolbar'>>r>"+
					"t"+
					"<'dt-toolbar-footer'<'col-sm-6 col-xs-12 hidden-xs'i><'col-xs-12 col-sm-6'p>>",
			"autoWidth" : true,
			"columnDefs":[{"targets" : 2,
                           "orderable":false}],
			"preDrawCallback" : function() {
				// Initialize the responsive datatables helper once.
				if (!setor) {
					setor = new ResponsiveDatatablesHelper($('#setor'), breakpointDefinition);
				}
			},
			"rowCallback" : function(nRow) {
				setor.createExpandIcon(nRow);
			},
			"drawCallback" : function(oSettings) {
				setor.respond();
			}		
		
	    });

	    // Apply the filter
	    $("#setor thead th input[type=text]").on( 'keyup change', function () {
	    	
	        otable
	            .column( $(this).parent().parent().index()+':visible' )
	            .search( this.value )
	            .draw();
	            
	    } );
	    /* END COLUMN FILTER */   

	};

	// load related plugins
	
loadScript("<?=base_url('assets')?>/js/plugin/datatables/jquery.dataTables.min.js", function(){
    loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.colVis.min.js", function(){
        loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.tableTools.min.js", function(){
            loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.bootstrap.min.js", function(){
                loadScript("<?=base_url('assets')?>/js/plugin/datatable-responsive/datatables.responsive.min.js", pagefunction)
            });
        });
    });
});


	
</script>