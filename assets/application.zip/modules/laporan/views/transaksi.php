<div class="alert alert-block alert-success">
	<h4 class="alert-heading">Laporan Transaksi</h4>
	<p>
		Untuk Melihat detail transaksi pendapatan dan pengeluaran silahkan masukan tanggal transaksi!
	</p>
</div>
<section id="widget-grid" class="">

	<!-- row -->
	<div class="row">

		<!-- NEW WIDGET START -->
		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

			<!-- Widget ID (each widget will need unique ID)-->
			<div class="jarviswidget well jarviswidget-color-darken" data-widget-sortable="false" data-widget-deletebutton="false" data-widget-editbutton="false" data-widget-colorbutton="false">
				<header>
					<span class="widget-icon"> <i class="fa fa-barcode"></i> </span>
					<h2>Item #44761 </h2>

				</header>

				<!-- widget div-->
				<div>

					<!-- widget edit box -->
					<div class="jarviswidget-editbox">
						<!-- This area used as dropdown edit box -->

					</div>
					<!-- end widget edit box -->

					<!-- widget content -->
					<div class="widget-body no-padding">
						<div class="widget-body-toolbar ">
                            <div class="row">

								<section class="col col-xs-6 col-sm-3 col-md-2 col-lg-2 smart-form">
                                    <label class="input"> <i class="icon-append fa fa-calendar"></i>
                                        <input type="text" name="startdate" readonly id="startdate" placeholder="Tanggal awal">
                                    </label>
                                </section>
                                <section class="col col-xs-6 col-sm-3 col-md-2 col-lg-2 smart-form">
                                    <label class="input"> <i class="icon-append fa fa-calendar"></i>
                                        <input type="text" name="finishdate" id="finishdate" placeholder="Tanggal akhir">
                                    </label>
                                </section>
                                

								<section class="col col-lg-8 text-align-right hidden">
									<div class="btn-group">
										<a href="javascript:void(0)" class="btn btn-sm btn-primary"> <i class="fa fa-print"></i> Print</a>
									</di>
								</section>

							</div>
						</div>
                        <div>
							<table class="table table-striped" id="detail">
								<thead>
									<tr>
										<th>Tanggal</th>
										<th>Transaksi</th>
										<th class='text-right'>Debet</th>
										<th class='text-right'>Kredit</th>
										<th class='text-right'>Saldo</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td></td>
										<td>Saldo Awal</td>
										<td></td>
										<td></td>
										<td class='text-right'><?=number_format($transaksi['awal']->awal,0,',','.')?></td>
									</tr>
									<?
									$debet = 0;
									$kredit = 0;
									$nominal = $transaksi['awal']->awal;
									foreach($transaksi['all']->result_array() as $row)
									{
										if($row['type'] == 'DEBET')
										{
											$debet += $row['nominal'];
											$nominal -= $row['nominal'];
											echo "<tr>
													<td>$row[tgl]</td>
													<td>$row[transaksi]</td>
													<td class='text-right'>".number_format($row['nominal'],0,',','.')."</td>
													<td class='text-right'>-</td>
													<td class='text-right'>".number_format($nominal,0,',','.')."</td>
												</tr>";
										}

										if($row['type'] == 'KREDIT')
										{
											$kredit += $row['nominal'];
											$nominal += $row['nominal'];
											echo "<tr>
													<td>$row[tgl]</td>
													<td>$row[transaksi]</td>
													<td class='text-right'>-</td>
													<td class='text-right'>".number_format($row['nominal'],0,',','.')."</td>
													<td class='text-right'>".number_format($nominal,0,',','.')."</td>
													
												</tr>";
										}
										
									}
									?>
									<tr>
										<td></td>
										<td>Mutasi Transaksi</td>
										<td class='text-right'><?=number_format($debet,0,',','.')?></td>
										<td class='text-right'><?=number_format($kredit,0,',','.')?></td>
										<td></td>
									</tr>
									<tr>
										<td></td>
										<td>Saldo Akhir</td>
										<td></td>
										<td></td>
										<td class='text-right'><?=number_format($nominal,0,',','.')?></td>
									</tr>
								</tbody>
							</table>
                        </div>
                    </div>
                </div>
            </div>
        </article>
    </div>
</section>
<script type="text/javascript">
pageSetUp();
$(document).ready(function(){
	$('#startdate').datepicker({
        dateFormat : 'dd-mm-yy',
        prevText : '<i class="fa fa-chevron-left"></i>',
        nextText : '<i class="fa fa-chevron-right"></i>',
        onSelect : function(selectedDate) {
            $('#finishdate').datepicker('option', 'minDate', selectedDate);
			transaksi();
        }
    });
    
    $('#finishdate').datepicker({
        dateFormat : 'dd-mm-yy',
        prevText : '<i class="fa fa-chevron-left"></i>',
        nextText : '<i class="fa fa-chevron-right"></i>',
        onSelect : function(selectedDate) {
            $('#startdate').datepicker('option', 'maxDate', selectedDate);
			transaksi();
        }
    });
});
function transaksi()
{
	var finishdate = $('#finishdate').val();
	var startdate  = $('#startdate').val();

	if(startdate.length != 0 && finishdate.length != 0)
	{
		var tr = "<tr><td colspan='5' class='text-center'><i class='fa fa-gear fa-spin'></i> Silahkan tunggu sedang mengambil data</td></tr>";
		$("#detail tbody").html(tr);
		$.ajax({
			url :"<?=site_url('laporan/transaksi')?>",
			data:{startdate : startdate,finishdate:finishdate},
			type:'post',
			success:function(data){
				$("#detail tbody").html(data);
			}
		});
		// console.log(startdate);
	}
}

	
</script>