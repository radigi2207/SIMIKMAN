<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('transaksi/M_transaksi','transaksi');
        $this->load->model('M_laporan','laporan');
    }

    public function index()
    {
        
    }

    function kasir()
    {
        $this->benchmark->mark('code_start');
        
        $data['setor'] = $this->transaksi->all_setor();

        $html = $this->load->view('kasir', $data, TRUE);

        $this->benchmark->mark('code_end');

        echo json_encode(array("times" =>$this->benchmark->elapsed_time('code_start', 'code_end'),
                               "html"  => $html));
       
    }

    function setor()
    {
        $this->benchmark->mark('code_start');
        $data['setor'] = $this->transaksi->all_setor('setor');
        $html = $this->load->view('setor', $data, TRUE);
        $this->benchmark->mark('code_end');

        echo json_encode(array("times" =>$this->benchmark->elapsed_time('code_start', 'code_end'),
                               "html"  => $html));
       
    }

    public function transaksi()
    {
        $this->benchmark->mark('code_start');
        (!$this->input->is_ajax_request()) ? show_404() : true;
        $post = $this->input->post();
        if(!empty($post))
        {

            $data =  $this->transaksi->detail_transaksi($post['startdate'],$post['finishdate']);
            ?>
            <tr>
                <td></td>
                <td>Saldo Awal</td>
                <td></td>
                <td></td>
                <td class='text-right'><?=number_format($data['awal']->awal,0,',','.')?></td>
            </tr>
            <?
            $debet = 0;
            $kredit = 0;
            $nominal = $data['awal']->awal;
            foreach($data['all']->result_array() as $row)
            {
                if($row['type'] == 'DEBET')
                {
                    $debet += $row['nominal'];
                    $nominal -= $row['nominal'];
                    echo "<tr>
                            <td>$row[tgl]</td>
                            <td>$row[transaksi]</td>
                            <td class='text-right'>".number_format($row['nominal'],0,',','.')."</td>
                            <td class='text-right'>-</td>
                            <td class='text-right'>".number_format($nominal,0,',','.')."</td>
                        </tr>";
                }

                if($row['type'] == 'KREDIT')
                {
                    $kredit += $row['nominal'];
                    $nominal += $row['nominal'];
                    echo "<tr>
                            <td>$row[tgl]</td>
                            <td>$row[transaksi]</td>
                            <td class='text-right'>-</td>
                            <td class='text-right'>".number_format($row['nominal'],0,',','.')."</td>
                            <td class='text-right'>".number_format($nominal,0,',','.')."</td>
                            
                        </tr>";
                }
                
            }
            ?>
            <tr>
                <td></td>
                <td>Mutasi Transaksi</td>
                <td class='text-right'><?=number_format($debet,0,',','.')?></td>
                <td class='text-right'><?=number_format($kredit,0,',','.')?></td>
                <td></td>
            </tr>
            <tr>
                <td></td>
                <td>Saldo Akhir</td>
                <td></td>
                <td></td>
                <td class='text-right'><?=number_format($nominal,0,',','.')?></td>
            </tr>
            <?
        }
        else
        {
            $data['transaksi'] = $this->transaksi->detail_transaksi();
            $html = $this->load->view('transaksi', $data, TRUE);
            $this->benchmark->mark('code_end');

            echo json_encode(array("times" =>$this->benchmark->elapsed_time('code_start', 'code_end'),
                                "html"  => $html));
        }

    }

    function chart_transaksi($type ="KREDIT")
    {
        $response  = array();
        $data = $this->laporan->chart_transaksi($type);
        $row = $data->result_array();
        $field = $data->list_fields();
        sort($field);
        foreach ($field as $key) {
            $response[] = array("period" => mdate("%Y-%m-%d",strtotime($key)),
                                "nominal" => $row[0][$key]);
        }
        // echo $i;
        // echo $this->db->last_query();
        echo json_encode($response);
    }


    function barang()
    {
        $this->benchmark->mark('code_start');
        //$data['barang'] = $this->laporan->barang();
        $html = $this->load->view('barang', [], TRUE);
        $this->benchmark->mark('code_end');

        echo json_encode(array("times" =>$this->benchmark->elapsed_time('code_start', 'code_end'),
                            "html"  => $html));
    }

}

/* End of file Laporan.php */
?>