<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tablegrid extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model(array('transaksi/M_transaksi','karyawan/karyawan_model'));
        $this->load->model('laporan/M_laporan','laporan');
    }

    public function index()
    {
        

    }

    function pegawai()
    {
        $get = $this->input->get();
        // echo json_encode($get);
        // exit;
		$coloumns = array('id',
						'first_name',
						'phone');

		$count_coloums = count($get['columns']);
		$limit = array("start"	=> $get['start'],
						"limit" => $get['length']);
		$order = array("field"	=> $coloumns[($get['order'][0]['column'])],
						"dir"	=> $get['order'][0]['dir']);
        $like = array('u.id' => $get['search']['value'],
                      'u.first_name' => $get['search']['value'],
                      'u.last_name' => $get['search']['value'],
                      'u.phone' => $get['search']['value']);
		

		$data_filter = $this->karyawan_model->get_user_all($like,$limit,$order);
        $query = $this->db->last_query();
		$field = $data_filter->list_fields();
        $limit['start'] = 0;
        $limit['limit'] = 1000;
        $all_data = $this->karyawan_model->get_user_all(array('u.id' => ''),$limit,$order)->num_rows();
        $output = array(
            //"sEcho" => intval($get['sEcho']),
            "iTotalRecords" => $all_data,
            "iTotalDisplayRecords" => $all_data,
            "aaData" => array(),
            "field" => $field,
            'query' => $query,
            'get' => $get
        );
        $id = 0;
        $i = 0;
        $akses = $this->karyawan_model->get_akses();
        $menu = array();
        $menuhtml = "";
        foreach($akses->Result_array() as $row)
        {
            if($row['user'] != $id)
            {
                
                $menu[$row['user']][] = "<span class='label label-success'><i class='fa $row[icon]'></i> $row[title]</span>";
                // $menu[$row['user']]['html'] =  $menuhtml;
                $id = $row['user'];
            }
            else
            {
                $menu[$row['user']][] = "<span class='label label-success'><i class='fa $row[icon]'></i> $row[title]</span>";
            }
        }
        $output['menu'] = $menu;
        $transaksi = $this->karyawan_model->get_transaksi_user();
		foreach($data_filter->result_array() as $row)
		{
                $pendapatan = 0;
                $penjualan  = 0;
                foreach($transaksi->result_array() as $tr)
                {
                    if($row['id'] == $tr['id'])
                    {
                        $pendapatan = $tr['pendapatan'];
                        $penjualan = $tr['total_penjualan'];
                    }
                }

            	$arow = array();
                $arow['0'] = "";
                $arow['id'] = "$row[id]";
                $arow['name']	= ucfirst($row['first_name']." ". $row['last_name']);
                $arow['email']	= "$row[email]";
                $arow['phone']	= "$row[phone]";
                $arow['status']	= ($row['active'] == 1)? '<center><span class="label label-success">'.strtoupper($this->lang->line('common_active')).'</span></center>':'<center><span class="label label-danger">'.strtoupper($this->lang->line('common_not_active')).'</span></center>';

                $arow['username'] = $row['username'];
                $arow['menu']    = (isset($menu[$row['id']]))?join($menu[$row['id']]," ") : "";
                $arow['opsi']    = '<a name="" id="" class="btn btn-default btn-xs" href="#profile/'.encode_url($row['id'],'profile').'" role="button"> Profil</a>'.
                                   '<a style="margin-left:5px" class="pull-right btn btn-xs btn-danger" onClick="hapus(event,&quot;'.site_url('karyawan/hapus/'.encode_url($row['id'],'hapus')).'&quot;)" href="#"><i class="fa fa-trash"></i> hapus</a>'.
                                   '<a  class="pull-right btn btn-xs btn-info"  href="#karyawan/edit/'.encode_url($row['id'],'edit').'"><i class="fa fa-edit"></i> edit</a>';
                $arow['start_date'] = mdate("%d-%m-%Y", $row['created_on']);
                $arow['pendapatan'] = "Rp. ".number_format($pendapatan,0,',','.');
                $arow['total_penjualan'] = $penjualan;
                $arow['address']    = $row['address'];
                $output['aaData'][] = $arow;
            
            
		}
		
		echo json_encode($output);
    }
    function laporan_barang()
    {
        $post = $this->input->get();
        $limit = array("limit" => $post['length'],
                       "start" => $post['start']);
        $order = array("field"	=> $post['columns'][$post['order'][0]['column']]['name'],
						"dir"	=> $post['order'][0]['dir']);
        
        $where = array();
        for($i=0;$i < count($post['columns']);$i++)
        {
            if($post['columns'][$i]['searchable'] && $post['columns'][$i]['name'] != 't.tgl' && $post['columns'][$i]['name'] != 'sales')
            {
                $where[$post['columns'][$i]['name']] = $post['columns'][$i]['search']['value'];                
            }
            elseif($post['columns'][$i]['name'] == 't.tgl')
            {
                $where["DATE_FORMAT(t.tgl,'%d-%m-%Y')"] = $post['columns'][$i]['search']['value'];                
            }
            else
            {
                $where["CONCAT(u.first_name,' ',u.last_name)"] = $post['columns'][$i]['search']['value'];
            }
        }
        $data_filter = $this->laporan->laporan_barang($where,$order,$limit);
        $all_data = $this->laporan->laporan_barang();
        $output = array(
            "sEcho" => intval($post['draw']),
            "iTotalRecords" => $all_data,
            "iTotalDisplayRecords" => $this->laporan->laporan_barang($where,$order)->num_rows(),
            "data" => array(),
            'get' => $post
        );
        foreach ($data_filter->result_array() as $row) {
            $arow = array();
            $arow[] = $row['kode_faktur'];
            $arow[] = $row['kode_item'];
            $arow[] = $row['nama_item'];
            $arow[] = mdate("%d-%m-%Y",strtotime($row['tgl']));
            $arow[] = $row['qty'];
            $arow[] = $row['sales'];


            $output['data'][] = $arow;
        }
        echo json_encode($output);

    }

    function invoice()
    {

        $get = $this->input->get();
		$coloumns = array('kode_faktur',
						'id',
						'tgl',
						'total_tagihan',
						'ket');

		$count_coloums = $get['iColumns'];
		$limit = array("start"	=> $get['iDisplayStart'],
						"limit" => $get['iDisplayLength']);
		$order = array("field"	=> $coloumns[($get['iSortCol_0'])],
						"dir"	=> $get['sSortDir_0']);
		$or_like = array();
        for($i=0; $i< count($coloumns); $i++)
		{
            if($i == 3)
            {
                $or_like['(total_tagihan - total_diskon)'] = $get['sSearch'];

            }
            else
            {
			    $or_like["UPPER(".$coloumns[$i].")"] = strtoupper($get['sSearch']);
            }
			
		}
        $like = array();
		for($i=0; $i< count($coloumns); $i++)
		{
            if(strlen($get['sSearch_'.$i]) != 0)
            {
                if($i == 3)
                {
                    $like['(total_tagihan - total_diskon)'] = $get['sSearch_'.$i];

                }
                else
                {
                    $like["UPPER(".$coloumns[$i].")"] = strtoupper($get['sSearch_'.$i]);
                }
                    
                
            }			
		}
		
		unset($or_like[0]);
        unset($like[0]);
		$data_filter = $this->M_transaksi->datatable_invoice($or_like,$limit,$order,$like);
        $query = $this->db->last_query();
		$field = $data_filter->list_fields();
        $all_data = $this->M_transaksi->datatable_count_invoice()->num_rows();
        $output = array(
            "sEcho" => intval($get['sEcho']),
            "iTotalRecords" => $all_data,
            "iTotalDisplayRecords" => $all_data,
            "aaData" => array(),
            "field" => $field,
            'query' => $query,
            'get' => $get
        );
		foreach($data_filter->result_array() as $row)
		{
            $button = "";
            if(($row['total_tagihan'] - $row['total_diskon']) > $row['total_bayar'])
                $button = "<a class='btn btn-primary btn-xs pull-right' href='".site_url('modal/bayar/'.$row['kode_faktur'])."' data-toggle='modal' data-target='#modal_bayar'>
                <span class='fa fa-money'>&nbsp; </span>Bayar";
			$arow = array();
            $arow[] = "$row[kode_faktur]";
            $arow[]	= "<center>$row[member]</center>";
            $arow[]	= "$row[tgl]";
            $arow[]	= "<span class='pull-right'>".number_format($row['total_tagihan'] - $row['total_diskon'],0,',','.')."</span>";
            $arow[]	= "$row[ket]";
            $arow[]	= (($row['total_tagihan'] - $row['total_diskon']) <= $row['total_bayar'])? "<span class='center-block padding-5 label label-success'>Lunas</span>" : "<span class='center-block padding-5 label label-warning'>Uang muka</span>";
            $arow[]	= "<a href='javascript:invoice(\"$row[kode_faktur]\")' class=' pull-left btn btn-default btn-xs'><i class='fa fa-print'></i> cetak".
                      $button;

			$output['aaData'][] = $arow;
		}
		
		echo json_encode($output);

    }



}

/* End of file Tablegrid.php */
?>