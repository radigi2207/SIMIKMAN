<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_main extends CI_Model {

    function s_penjualan($group = false)
    {
        $select = array();
        for($i=1;$i<= 12; $i++)
        {
            $select[] = 'SUM(IF(MONTH(t.tgl) = '.$i.', t.qty, 0)) AS bln_'.$i;
        }
        if($group)
            $select[] = 't.kode_item';

        $this->db->select(join($select,','));

        if($group)
        {
            $this->db->group_by('t.kode_item');
        }

        return $this->db->get('tb_transaksi t');
    }
    function s_pemasukan()
    {
        $select = array();
        for($i=1;$i<= 12; $i++)
        {
            $select[] = 'SUM(IF(MONTH(t.tgl) = '.$i.', t.nominal,0)) AS bln_'.$i;
        }
        $this->db->select(join($select,','));
        $this->db->where('t.type', 'KREDIT');
        return $this->db->get('tb_rek t');
    }

    function s_item()
    {
        return $this->db->get('tb_produk');
    }

    function s_member()
    {
        return $this->db->get('tb_member');
    }
    function s_penjual_produk()
    {
        $this->db->select("p.kode_item, p.nama_item, IFNULL(SUM(t.qty),0) AS 'jml'");
        $this->db->join('tb_produk p', 't.kode_item = p.kode_item', 'RIGHT');
        $this->db->group_by('p.kode_item');
        $this->db->order_by("'jml'", 'desc');
        return $this->db->get("tb_transaksi t");
    }
    

}

/* End of file M_main.php */
?>