<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_main');
	}

	public function index()
	{
		if(!empty($this->session->userdata('login')) && $this->session->userdata('login'))
		{
			$this->load->view('template');
			return;
		}
		redirect(site_url('auth'));
		
	}

	function dasbord()
	{
		$this->benchmark->mark('code_start');
		$data['penjualan'] = $this->M_main->s_penjualan()->result_array();
		$data['pemasukan'] = $this->M_main->s_pemasukan()->result_array();
		$data['items']     = $this->M_main->s_item()->num_rows();
		$data['members']     = $this->M_main->s_member()->num_rows();
		$data['penjualan_produk']= $this->M_main->s_penjual_produk();
		
		$data['penjualan_group'] = $this->M_main->s_penjualan(true);
		//echo $this->db->last_query();exit;
		$html = $this->load->view('dasbord',$data,true);
		$this->benchmark->mark('code_end');

        echo json_encode(array("times" =>$this->benchmark->elapsed_time('code_start', 'code_end'),
                               "html"  => $html));

	}
}
