<div class="alert alert-block alert-success">
	<h4 class="alert-heading"><?=$title?></h4>
	<p>
		Silahkan masukan informasi pegawai baru dengan benar sesuai dengan kartu identitas!
	</p>
</div>
<section id="widget-grid" class="">


	<!-- START ROW -->

	<div class="row">
		<!-- NEW COL START -->
		<article class="col-sm-12 col-md-12 col-lg-6">
			<div class="jarviswidget" id="wid-id-1" data-widget-editbutton="false" data-widget-custombutton="false">
				
				<div>
					<div class="jarviswidget-editbox">
					</div>
					<div class="widget-body no-padding">
						
						<form  action="<?=current_url()?>" id="karyawan" method="post" class="smart-form" novalidate="novalidate">
                            <header>
                                <?=$this->lang->line("employees_basic_information");?>
                            </header>
							<fieldset>
								<div class="row">
									<section class="col col-4">
										<label class="input"> <i class="icon-prepend fa fa-user"></i>
											<input type="text" name="fname" value="<?=$user['first_name']?>" placeholder="<?=$this->lang->line("common_first_name");?>">
										</label>
									</section>
									<section class="col col-5">
										<label class="input"> <i class="icon-prepend fa fa-user"></i>
											<input type="text" name="lname" value="<?=$user['last_name']?>" placeholder="<?=$this->lang->line("common_last_name");?>">
										</label>
									</section>
                                    <section class="col col-3">
										<label class="input"> <i class="icon-prepend fa fa-user"></i>
											<input type="text" name="inisial" value="<?=$user['inisial']?>" placeholder="Nama alias">
										</label>
									</section>
								</div>

								<div class="row">
									<section class="col col-6">
										<label class="input"> <i class="icon-prepend fa fa-envelope-o"></i>
											<input type="email" name="email" value="<?=$user['email']?>" placeholder="<?=$this->lang->line("common_email");?>">
										</label>
									</section>
									<section class="col col-6">
										<label class="input"> <i class="icon-prepend fa fa-phone"></i>
											<input type="tel" name="phone" value="<?=$user['phone']?>" placeholder="<?=$this->lang->line("common_phone_number");?>">
										</label>
									</section>
								</div>
                                <section>
                                    <label class="input"> <i class="icon-prepend fa fa-location-arrow"></i>
                                        <input type"text" name="address" value="<?=$user['address']?>" placeholder="<?=$this->lang->line("common_address_1")?>">
                                    </label>
                                </section>
							</fieldset>
                            <header>
                                <?=$this->lang->line("employees_login_info");?>
                            </header>
                            <fieldset>
                                <div class="row">
                                    <section class="col col-6">
                                        <label class="input"> <i class="icon-append fa fa-user"></i>
                                            <input type="text" name="username" value="<?=$user['username']?>" placeholder="<?=$this->lang->line('employees_username')?>">
                                    </section>
                                    <section class="col col-6">
                                        <?=ucfirst($this->lang->line('common_active'))?>
                                        <span class="onoffswitch">
                                            <input type="checkbox" name="active" value="1" class="onoffswitch-checkbox" <?=($user['active'] == 1 || $user['active'] == null)? ' checked ':''?> id="st3">
                                            <label class="onoffswitch-label" for="st3"> 
                                                <span class="onoffswitch-inner" data-swchon-text="YES" data-swchoff-text="NO"></span> 
                                                <span class="onoffswitch-switch"></span> 
                                            </label> 
                                        </span>
                                        <!--<label class="toggle">
                                            <input type="checkbox" name="active" value='1' checked>
                                            <i data-swchon-text="YES" data-swchoff-text="NO"></i><?=ucfirst($this->lang->line('common_active'))?>
                                        </label>-->
                                    </section>
                                </div>
								<section>
									<label class="input"> <i class="icon-append fa fa-lock"></i>
										<input type="password" name="password" placeholder="<?=$this->lang->line('employees_password')?>" id="password">
								</section>

								<section>
									<label class="input"> <i class="icon-append fa fa-lock"></i>
										<input type="password" name="passwordConfirm" placeholder="<?=$this->lang->line('employees_repeat_password')?>">
								</section>
							</fieldset>
                            <fieldset>
                                <div class="alert alert-block alert-info">
                                    <h4 class="alert-heading"><i class="fa fa-user-secret"></i><?=$this->lang->line("employees_permission_info")?></h4>
                                    <p><?php echo $this->lang->line("employees_permission_desc"); ?></p>
                                </div>
                                <div class="tree smart-form" style="padding:0px 13px">
                                <ul id="level-akses">
                                    <?
                                    foreach($menu->result_array() as $row)
                                    {
                                        
                                        echo '<li><label class="checkbox inline-block">
                                                        <input type="checkbox" name="menu[]" value="'.$row['id_menu'].'"';
                                        echo ($akses[$row['id_menu']] )? ' checked ':'';
                                        echo ($row['disable'])? ' disabled ': '';
                                        echo '>
                                                        <i ></i> '.$row['title'].'</label>';
                                        
                                        if($row['url'] == null)
                                        {
                                            echo '<ul>';
                                            foreach($menu_c->result_array() as $row_c)
                                            {
                                                if($row['id_menu'] == $row_c['parent'])
                                                {
                                                    echo '<li><label class="checkbox inline-block">
                                                        <input type="checkbox" name="menu[]" value="'.$row_c['id_menu'].'"';
                                                    echo ($akses[$row_c['id_menu']])? ' checked ':'';
                                                    echo ($row_c['disable'])? ' disabled ': '';
                                                    echo '>
                                                        <i ></i> '.$row_c['title'].'</label>';
                                                }

                                            }
                                            echo '</ul>';
                                        }

                                        echo '</li>';

                                    }
                                    ?>
                                </ul>
						    </div>
                            </fieldset>
							<footer>
								<button type="submit" class="btn btn-primary">
									<?=$this->lang->line("common_submit");?>
								</button>
							</footer>
						</form>

					</div>
					<!-- end widget content -->
					
				</div>
				<!-- end widget div -->
				
			</div>
			<!-- end widget -->
			
		

		</article>
    </div>
</section>

<script type="text/javascript">

pageSetUp();
$(document).ready(function(){
    $("input[name=phone]").inputmask({
        mask: ["(999)999-9999-99"],
        placeholder: "X",
        removeMaskOnSubmit:true
	});
});

var pagefunction = function(){
    <?=(empty($user['first_name']))? "drawBreadCrumb(['Pengaturan','Karyawan','Baru']);" : "drawBreadCrumb(['Pengaturan','Karyawan','Edit','".$user['first_name']." ". $user['last_name']."']);";?> 
    var new_kategori = $("#karyawan").validate({
        // Rules for form validation
        rules : {
            fname:{
                required:true
            },
            username:{
                required : true,
                minlength :5
            },
            password : {
                <?
                echo ($user['password'] == null) ? "required:true," : "required:false,";
                ?>
                minlength : 8,
            },
            passwordConfirm : {
                <?
                echo ($user['password'] == null) ? "required:true," : "required:false,";
                ?>
                equalTo : '#password'
            },
            
        },

        // Messages for form validation
        messages : {
            fname:{
                required:'<?=$this->lang->line('common_first_name_required');?>'
            },
            username:{
                required: "<?=$this->lang->line('employees_username_required'); ?>",
     			minlength: "<?=$this->lang->line('employees_username_minlength'); ?>"
            },
            password : {
                required : '<?=$this->lang->line('employees_password_required');?>',
                minlength: "<?=$this->lang->line('employees_password_minlength'); ?>"
            },
            passwordConfirm : {
                required : '<?=$this->lang->line('employees_password_minlength');?>',
                equalTo : '<?=$this->lang->line('employees_password_must_match');?>'
            },
            
            
        },

        // Ajax form submition
        submitHandler : function(form) {
            $(form).ajaxSubmit({
                dataType:'json',
                success : function(data) {
                    
                    if(data.code == 200)
                    {
                        var color = "#739E73";
                        var time  = 3000;
                        <?
                        echo ($user['password'] == null) ? "$('#karyawan').resetForm();" : "$('span#refresh').click();";
                        ?>
                        ;
                    }
                    else
                    {
                        var color = "#C46A69";
                        var time  = 6000;
                    }
                    $.smallBox({
                        title : "<?=$this->lang->line('employees_new')?>",
                        content : "<i>"+data.msg+"</i>",
                        color : color,
                        iconSmall : "fa fa-user-plus bounce animated",
                        timeout : time
                    });
                }
            });
        },

        // Do not change code below
        errorPlacement : function(error, element) {
            error.insertAfter(element.parent());
        }
    });
};
var checktree = function(){
    $('#level-akses').checktree();
}
loadScript("<?=base_url("assets/js/plugin/checkbox-tree/jquery-checktree.js")?>",checktree);
loadScript("<?=base_url("assets/js/plugin/jquery-form/jquery-form.min.js")?>", pagefunction);
</script>