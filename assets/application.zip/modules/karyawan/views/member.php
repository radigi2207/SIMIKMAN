<section id="widget-grid" class="">
	<div class="row">
		<article class="col-sm-12 col-md-12 col-lg-12">
			<div class="jarviswidget jarviswidget-color-darken" id="wid-id-1" data-widget-editbutton="false" data-widget-custombutton="false"
             data-widget-deletebutton="false">
				<header>
                    <span class="widget-icon"> <i class="fa fa-users"></i> </span>
                    <h2>
                        Member
                    </h2>
                </header>
                <div>
                    <div class="widget-body no-padding">
                        <table id="member" class="table table-striped table-bordered table-hover" width="100%">
                            <thead>
                                <tr>
                                    <th data-class="expand" class="text-center">ID Member</th>
                                    <th>Nama Member</th>
                                    <th data-hide='phone'class="">Telp / HP</th>
                                    <th data-hide='phone' class="">Poin</th>
                                    <th data-hide='phone, tablet' class="">Penukaran Poin</th>
                                    <th data-hide='phone, tablet' class="">Tgl. Regristrasi</th>
                                    <th data-hide='phone, tablet' class="text-center">Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?foreach($member->result_array() as $row):?>
                                <tr>
                                    <td class='text-center'><?=$row['id']?></td>
                                    <td><?=$row['nama']?></td>
                                    <td class='text-cente'><?=$row['no_hp']?></td>
                                    <td class='text-cente'><?=number_format($row['point'],0,',','.')?></td>
                                    <td><??></td>
                                    <td class='text-cente'><?=$row['tgl_insert']?></td>
                                    <td>
                                        <center>
                                            <a data-toggle="modal" data-target="#modal_new_member" class="btn btn-xs btn-success" href="<?=site_url('modal/new_member/'.$row['id'])?>"><i class="fa fa-edit"></i> edit</a>
                                        </center>
                                    </td>
                                </tr>
                                <?endforeach;?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </article>
    </div>
</section>
<div class="modal fade" id="modal_new_member" tabindex="-1" data-backdrop="static" data-keyboard="false" role="modal" aria-labelledby="remoteModalLabel" aria-hidden="true">  
    <div class="modal-dialog">  
        <div class="modal-content">

        </div>  
    </div>  
</div>
<div class="launcher visible-xs">
<button href="<?=site_url('modal/new_member')?>" data-toggle="modal" data-target="#modal_new_member"class="btn btn-primary btn-circle btn-lg "><i class="fa fa-plus"></i></button>
</div>

<script type="text/javascript">
    pageSetUp();
    var pagefunction = function() {
    
	var responsiveHelper_datatable_fixed_column = undefined;
    var breakpointDefinition = {
				tablet : 1024,
				phone : 480
			};
    
    var itable = $('#member').DataTable({
            "sDom": "<'dt-toolbar'<'col-xs-12 col-sm-6'f><'col-sm-6 col-xs-12 hidden-xs'l>r>"+
                "t"+
                "<'dt-toolbar-footer'<'col-sm-6 col-xs-12 hidden-xs'i><'col-xs-12 col-sm-6'p>>",
            "bFilter": true,
            "language" : {
                "sSearchPlaceholder":"Silahkan masukan kategori",
                "emptyTable":     "Tak ada data yang tersedia pada tabel",
                "info":           "Tampil _START_ sampai _END_ dari _TOTAL_ records",
                "infoEmpty":      "Tampil 0 sampai 0 dari 0 records",
                "infoFiltered":   "(Pencarian dari _MAX_ total records)",
                "infoPostFix":    "",
                "thousands":      ",",
                "lengthMenu":     " _MENU_",
                "loadingRecords": "Loading...",
                "processing":     "Memproses...",
                "search":         "_INPUT_",
                "zeroRecords":    "Tidak ada data yang cocok ditemukan",
                "paginate":{
                    "first":      "Pertama",
                    "last":       "Terakhir",
                    "next":       "Berikutnya",
                    "previous":   "Sebelumnya"
                }
            },
            "autoWidth" : true,
			"preDrawCallback" : function() {
				// Initialize the responsive datatables helper once.
				if (!responsiveHelper_datatable_fixed_column) {
					responsiveHelper_datatable_fixed_column = new ResponsiveDatatablesHelper($('#member'), breakpointDefinition);
				}
			},
			"rowCallback" : function(nRow) {
				responsiveHelper_datatable_fixed_column.createExpandIcon(nRow);
			},
			"drawCallback" : function(oSettings) {
				responsiveHelper_datatable_fixed_column.respond();
			}
        });
        $('.dataTables_length label').prepend('<a class="btn btn-primary btn-sm" href="<?=site_url('modal/new_member')?>" data-toggle="modal" data-target="#modal_new_member"'+
                             '><span class="fa fa-user-plus">&nbsp; </span>member Baru</a> ');
        
    };
    


loadScript("<?=base_url('assets')?>/js/plugin/datatables/jquery.dataTables.min.js", function(){
    loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.colVis.min.js", function(){
        loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.tableTools.min.js", function(){
            loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.bootstrap.min.js", function(){
                loadScript("<?=base_url('assets')?>/js/plugin/datatable-responsive/datatables.responsive.min.js", pagefunction)
            });
        });
    });
});
</script>