<section>
    <div class="row">
        <article class="col-lg-4 col-lg-offset-4 col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-12">
            <div class="well no-padding">
                <div class="alert alert-block alert-success nmb">
                    <h4 class="alert-heading">Pengaturan Kata Sandi</h4>
                    <p>
                        Silahkan masukan kata sandi baru
                    </p>
                </div>
                <form action="<?=site_url('profile')?>" id="pengaturan" class="smart-form"  method="post" novalidate="novalidate">
                    
                    <fieldset>
                        <section>
                            <label class="input"> <i class="icon-prepend fa fa-unlock"></i>
                                <input type="password" name="currentpassword" placeholder="Kata Sandi sebelumnya">
                            </label>
                        </section>
                        <section>
                            <label class="input"> <i class="icon-append fa fa-lock"></i>
                                <input type="password" name="password" placeholder="<?=$this->lang->line('employees_password')?>" id="password">
                        </section>

                        <section>
                            <label class="input"> <i class="icon-append fa fa-lock"></i>
                                <input type="password" name="passwordConfirm" placeholder="<?=$this->lang->line('employees_repeat_password')?>">
                        </section>
                    </fieldset>
                    <footer>
                        <button type="submit" class="btn btn-primary">
                            Simpan
                        </button>
                    </footer>
                </form>
            </div>
        </article>
    </div>
</section>
<script type="text/javascript">
pageSetUp();
var pagefunction = function(){
    var formp = $("#pengaturan").validate({
        // Rules for form validation
        rules : {
            currentpassword:{
                required : true
            },
            password : {
               required:true,
               minlength : 8
            },
            passwordConfirm : {
                required:true,
                equalTo : '#password'
            },
            
        },

        // Messages for form validation
        messages : {
            currentpassword : {
                required : '<?=$this->lang->line('employees_password_required');?>',
            },
            password : {
                required : '<?=$this->lang->line('employees_password_required');?>',
                minlength: "<?=$this->lang->line('employees_password_minlength'); ?>"
            },
            passwordConfirm : {
                required : '<?=$this->lang->line('employees_password_minlength');?>',
                equalTo : '<?=$this->lang->line('employees_password_must_match');?>'
            },
            
            
        },

        // Ajax form submition
        submitHandler : function(form) {
            $(form).ajaxSubmit({
                dataType:'json',
                success : function(data) {
                    
                    if(data.code == 200)
                    {
                        var color = "#739E73";
                        var time  = 3000;
                        $('a#refresh').click();
                    }
                    else
                    {
                        var color = "#C46A69";
                        var time  = 6000;
                    }
                    $.smallBox({
                        title : "<?=$this->lang->line('employees_new')?>",
                        content : "<i>"+data.msg+"</i>",
                        color : color,
                        iconSmall : "fa fa-user-plus bounce animated",
                        timeout : time
                    });
                }
            });
        },

        // Do not change code below
        errorPlacement : function(error, element) {
            error.insertAfter(element.parent());
        }
    });
};
loadScript("<?=base_url("assets/js/plugin/jquery-form/jquery-form.min.js")?>", pagefunction);
</script>