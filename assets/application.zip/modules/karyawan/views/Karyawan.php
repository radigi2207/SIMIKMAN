<div class="row">
	<div class="col-xs-12 col-sm-7 col-md-7 col-lg-4">
		<h1 class="page-title txt-color-blueDark"><i class="fa fa-table fa-fw "></i> Data <span>> Karyawan</span></h1>
	</div>
	<div class="col-xs-12 col-sm-5 col-md-5 col-lg-8">
		<ul id="sparks" class="">
			<li class="sparks-info">				
				<h5> Pemasukan <span class="txt-color-greenLight"> <i class="fa fa-arrow-circle-up"></i>&nbsp;<?=number_short(array_sum($pemasukan[0]))?></span></h5>
				<div class="sparkline txt-color-greenLight hidden-mobile hidden-md hidden-sm">
					<?=join($pemasukan[0],',')?>
				</div>
			</li>
			<li class="sparks-info hidden">
				<h5> Pengeluaran <span class="txt-color-purple"><i class="fa fa-arrow-circle-down"></i>&nbsp;</span></h5>
				<div class="sparkline txt-color-purple hidden-mobile hidden-md hidden-sm">
					12,11,10,9,8,7,6,5,4,3,2,1
				</div>
			</li>
			<li class="sparks-info">
				<h5> penjualan <span class="txt-color-greenDark"><i class="fa fa-shopping-cart"></i>&nbsp;<?=number_format(array_sum($penjualan[0]),0,',','.')?></span></h5>
				<div class="sparkline txt-color-greenDark hidden-mobile hidden-md hidden-sm">
					<?=join($penjualan[0],',')?>
				</div>
			</li>
			<li class="sparks-info">				
				<h5> Total Item <span class="txt-color-greenLight"> <i class="fa fa-tags"></i>&nbsp;<?=number_short($items)?></span></h5>
			</li>
			<li class="sparks-info">				
				<h5> Total Pelanggan <span class="txt-color-greenLight"> <i class="fa fa-karyawans"></i>&nbsp;<?=number_short($members)?></span></h5>
			</li>
		</ul>
	</div>
</div>
<section id="widget-grid">
	<div class="row">
		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<div class="jarviswidget well" >
				<header>
					<span class="widget-icon"> <i class="fa fa-users"></i> </span>
					<h2>Ddata Karyawan</h2>
				</header>
				<div>
					<div class="jarviswidget-editbox">
					</div>
					<div class="widget-body no-padding">
						
						<div class="table-responsive">
						
							<table id="karyawan" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
								<thead>
									<tr>
										<th></th>
										<th>ID</th>
										<th>Nama Lengkap</th>
										<th>E-mail</th>
										<th>No. Telepon</th>
										<th>Status</th>
									</tr>
								</thead>
								<tbody>
                                    
                                </tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</article>
	</div>
</section>
<script type="text/javascript">
	pageSetUp();
	
	var pagefunction = function() {

		function format ( d ) {
		    // `d` is the original data object for the row
		    return '<table cellpadding="5" cellspacing="0" border="0" class="table table-hover table-condensed">'+
				'<tr>'+
					'<td><?=$this->lang->line('common_address_1')?></td>'+
					'<td>'+d.address+'</td>'+
				'</tr>'+
		        '<tr>'+
		            '<td width="150px">Tgl. Mulai Bekerja:</td>'+
		            '<td>'+d.start_date+'</td>'+
		        '</tr>'+
		        '<tr>'+
		            '<td>Total Penjualan:</td>'+
		            '<td>'+d.total_penjualan+' Item</td>'+
		        '</tr>'+
		        '<tr>'+
		            '<td>Total Pendapatan:</td>'+
		            '<td>'+d.pendapatan+'</td>'+
		        '</tr>'+
				'<tr>'+
					'<td>Hak Akses Menu:</td>'+
					'<td style="line-height:23px;">'+d.menu+'</td>'+
				'</tr>'+
		        '<tr>'+
		            '<td>Opsi:</td>'+
		            '<td>'+d.opsi+'</td>'+
		        '</tr>'+
		    '</table>';
		}
		var table = $('#karyawan').DataTable( {
			"sDom": "<'dt-toolbar'<'col-xs-6 col-sm-6'f><'col-sm-6 col-xs-6 toolbar-left'>r>"+
                "t"+
                "<'dt-toolbar-footer'<'col-sm-6 col-xs-12 hidden-xs'i><'col-xs-12 col-sm-6'p>>",
            "bFilter": true,
	        "bDestroy": true,
			"language" : {
                "sSearchPlaceholder":"Silahkan masukan kata kunci pencarian",
                "emptyTable":     "Tak ada data yang tersedia pada tabel",
                "info":           "Tampil _START_ sampai _END_ dari _TOTAL_ records",
                "infoEmpty":      "Tampil 0 sampai 0 dari 0 records",
                "infoFiltered":   "(Pencarian dari _MAX_ total records)",
                "infoPostFix":    "",
                "thousands":      ",",
                "lengthMenu":     " _MENU_",
                "loadingRecords": "Loading...",
                "processing":     "Memproses...",
                "search":         "_INPUT_",
                "zeroRecords":    "Tidak ada data yang cocok ditemukan",
                "paginate":{
                    "first":      "Pertama",
                    "last":       "Terakhir",
                    "next":       "Berikutnya",
                    "previous":   "Sebelumnya"
                }
            },
	        "order": [[1, 'asc']],
			"bServerSide": true,
			"ajax": "<?=site_url('tablegrid/pegawai')?>",
			"columns": [
				{
					"class":          "details-control",
					"orderable":      false,
					"data":           null,
					"defaultContent": ""
				},
				{ "data": "id" },
				{ "data": "name" },
				{ "data": "email" },
				{ "data": "phone" },
				{ "data": "status" }

			]
	    } );
		$('.toolbar-left').prepend('<nav><a class="btn btn-primary btn-sm pull-right" href="karyawan/reg_new"><span class="fa fa-user-plus">&nbsp; </span>Karyawan Baru</a> </nav>');

		$('#karyawan tbody').on('click', 'td.details-control', function () {
	        var tr = $(this).closest('tr');
	        var row = table.row( tr );
	 
	        if ( row.child.isShown() ) {
	            row.child.hide();
	            tr.removeClass('shown');
	        }
	        else {
	            row.child( format(row.data()) ).show();
	            tr.addClass('shown');
	        }
	    });

	};

	var pagedestroy = function(){

	}
    loadScript("<?=base_url('assets')?>/js/plugin/datatables/jquery.dataTables.min.js", function(){
        loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.colVis.min.js", function(){
            loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.tableTools.min.js", function(){
                loadScript("<?=base_url('assets')?>/js/plugin/datatables/dataTables.bootstrap.min.js", function(){
                    loadScript("<?=base_url('assets')?>/js/plugin/datatable-responsive/datatables.responsive.min.js", pagefunction)
                });
            });
        });
    });
	function hapus(e,url)
	{		
		e.preventDefault();
		$.SmartMessageBox({
			title : "<i class='fa fa-trash-o'> <?=$this->lang->line('employees_employee')?></i>",
			content : "<?=$this->lang->line('employees_confirm_delete')?>",
			buttons : '[No][Yes]'
		}, function(ButtonPressed) {
			if (ButtonPressed === "Yes") {
				$.ajax({
					url : url,
					success:function(){
						$('a[data-action=refreshContent]').click();
					}
				});
				
				return true;
			}
			if (ButtonPressed === "No") {
				return false;
			}

		});
	}
</script>
