<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Karyawan extends CI_Controller {

    //private $karyawan ;

    public function __construct()
    {
        parent::__construct();
        $this->load->model('karyawan_model','karyawan');
        $this->load->model('main/M_main', 'main');
        $this->load->helper('security');

       // $this->karyawan_model = $this->karyawan_model_model;
    }

    public function index()
    {
        $this->benchmark->mark('code_start');
        (!$this->input->is_ajax_request()) ? show_404():true;
        $data['user']   = $this->karyawan->user();
        $data['penjualan'] = $this->main->s_penjualan()->result_array();
		$data['pemasukan'] = $this->main->s_pemasukan()->result_array();
		$data['items']     = $this->main->s_item()->num_rows();
		$data['members']     = $this->main->s_member()->num_rows();
		$data['penjualan_produk']= $this->main->s_penjual_produk();
		$data['penjualan_group'] = $this->main->s_penjualan(true);
        $html = $this->load->view('karyawan', $data, TRUE);
        $this->benchmark->mark('code_end');

        echo json_encode(array("times" =>$this->benchmark->elapsed_time('code_start', 'code_end'),
                               "html"  => $html));
    }

    function member()
    {
        $this->benchmark->mark('code_end');
        (!$this->input->is_ajax_request())? show_404():true;
        $data['member'] = $this->karyawan->get_member();
        $html = $this->load->view('member', $data, TRUE);
        $this->benchmark->mark('code_end');
        echo json_encode(array("times" =>$this->benchmark->elapsed_time('code_start', 'code_end'),
                               "html"  => $html));
    }

    function new_member()
    {
        $post = $this->input->get();

        unset($post['_']);
        $response = array("code" => 200,
                          "msg"  => $post['nama']. " Berhasil ditambahkan sebagai member",
                          "post" => $post);
        $this->db->db_debug = FALSE;
        $post['operator'] = $this->session->userdata('people');
        if(!$this->db->insert('tb_member', $post))
        {
            $response['code'] = 201;
            $response['msg']  = $post['nama'].' Gagal ditambahkan sebagai member';
        }
        
        echo json_encode($response);
    }
    function edit_member()
    {
        $post = $this->input->get();
        $response = array("code" => 200,
                          "msg"  => "Perubahan data berhasil di simpan. untuk melihat hasil perubahan silahkan refresh halaman");
        $this->db->db_debug = FALSE;
        if(!$this->karyawan->edit_member($post))
        {
            $response['code'] = 201;
            $response['msg']  = "Perubahan data gagal disimpan. silahkan ulangi kembali";
        }

        echo json_encode($response);
    }

    function autocomplete_member()
    {
        $get = $this->input->get();
        $respone = array();
        $produk = $this->karyawan->search_member($get);
        foreach ($produk->result_array() as $row) {

            $respone[] = array('id' => $row['id'],
                         'nama'=> $row['nama'] ,
                         'point'=> number_format($row['point'],0,',','.'));
        }
        echo json_encode( $respone);
    }

    function member_id()
    {
        $post = $this->input->post();
        echo ($this->input->is_ajax_request())? json_encode($this->karyawan->get_member($post['id'])->row()):show_404();
    }

    function reg_new()
    {
        (!$this->input->is_ajax_request())? '':true;
        $post = $this->input->post();
        if(!empty($post))
        {
            $options = ['cost' => 5,
                        'salt' => mcrypt_create_iv(22, MCRYPT_DEV_URANDOM),
                        ];
            $data = array(
                'username' => $post['username'],
                'password' => password($post['password'],$options),
                'email'    => $post['email'],
                'active'   => 1,
                'first_name'    => $post['fname'],
                'last_name'     => $post['lname'],
                'phone'         => $post['phone'],
                'address'       => $post['address'],
                'active'        => $post['active']

            );
            $post['menu'] = (!empty($post['menu']))?$post['menu'] : false;
            echo json_encode($this->karyawan->reg_user($data,$post['menu']));            
        }
        else
        {
            $this->edit();
        }
        
    }

    function edit($id = null)
    {
        $this->benchmark->mark('code_start');
        $id = ($id != null)? decode_url($id,'edit'):$id;
        $post = $this->input->post();
        if(!empty($post) && $id != null)
        {
            $post['active'] = (isset($post['active']) && $post['active'] == 1)? 1:0;
            $data = array(
                'username' => $post['username'],
                'email'    => $post['email'],
                'active'   => 1,
                'first_name'    => $post['fname'],
                'last_name'     => $post['lname'],
                'phone'         => $post['phone'],
                'id'            => $id,
                'address'       => $post['address'],
                'active'        => $post['active'],
                'inisial'         => $post['inisial']

            );
            $post['menu'] = (!empty($post['menu']))?$post['menu'] : false;
            echo json_encode($this->karyawan->edit_user($data,$post['menu'])); 
            return;
        }
        $data['menu'] = $this->karyawan->menu_parent();
        $data['menu_c'] = $this->karyawan->menu_child();

        $user = $this->karyawan->get_user_id($id);
        $field = array();
        $menu  = array();
        $row_field = $user->list_fields();
        $akses = $this->karyawan->get_akses_user($id);
        foreach($data['menu']->result_array() as $row)
        {
            $menu[$row['id_menu']] = false;
        }
        foreach($data['menu_c']->result_array() as $row)
        {
            $menu[$row['id_menu']] = false;
        }
        if($user->num_rows() == 0)
        {
            for($i =0 ; $i < count($row_field);$i++)
            {
                $field[$row_field[$i]] = null;

            }
            

        }
        else
        {
            $field = $user->result_array()[0];
            foreach($data['menu']->result_array() as $row)
            {
                foreach ($akses->result_array() as $key) {
                    if($key['menu'] == $row['id_menu'])
                        $menu[$row['id_menu']] = true;
                }
                
            }
            foreach($data['menu_c']->result_array() as $row)
            {
                foreach ($akses->result_array() as $key) {
                    if($key['menu'] == $row['id_menu'])
                        $menu[$row['id_menu']] = true;
                }
            }

        }

        $data['user'] = $field;
        $data['akses'] = $menu;
        $data['title']  = '<i class="fa fa-edit"></i>'.$this->lang->line('employees_update');
        $html = $this->load->view('new', $data, TRUE);
        $this->benchmark->mark('code_end');

        echo json_encode(array("times" =>$this->benchmark->elapsed_time('code_start', 'code_end'),
                               "html"  => $html));

    }

    function hapus($id)
    {
        $id = decode_url($id,'hapus');
        $this->db->where('id', $id);
        $this->db->delete('tb_users');
        log_query($this->db->last_query());

        $this->db->where('user', $id);
        $this->db->delete('tb_akses');
        
        log_query($this->db->last_query());
    }

    function profile()
    {
        $this->benchmark->mark('code_start');
        $post = $this->input->post();
        if(!empty($post))
        {
            echo json_encode($this->karyawan->edit_password($post));

            $this->session->sess_destroy();
            delete_cookie('auth');
            return;
        }
        $html = $this->load->view('profile', [], TRUE);
        $this->benchmark->mark('code_end');
        echo json_encode(array("times" => $this->benchmark->elapsed_time('code_start','code_end'),
                               "html"  => $html));
    }

}
?>