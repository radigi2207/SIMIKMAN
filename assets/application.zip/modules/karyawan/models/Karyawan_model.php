<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Karyawan_model extends CI_Model {

    public function __construct()
    {
        parent::__construct();
        //Do your magic here
    }
    function get_member($id = null)
    {
        if($id != null)
        {
            $this->db->where('id', $id);
        }

        $this->db->order_by('nama', 'asc');
        return $this->db->get('tb_member');
    }

    function edit_member($post)
    {
        unset($post['_']);
        $this->db->where('id',$post['id']);
        $up = $this->db->update('tb_member',$post);
        log_query($this->db->last_query());
        return $up;
    }

    function search_member($data)
    {
        $like = array('id' => $data['search'],
                      'nama' => $data['search'] );
        $this->db->or_like($like);
        $this->db->limit($data['maxRows']);
        return $this->db->get('tb_member ');
    }

    function reg_user($data,$akses)
    {

        $response = array(
            "code" => 200,
            "msg"  => $this->lang->line("employees_successful_adding")
        );
        $this->db->db_debug = FALSE;
        $data['created_on'] = time();
        $this->db->insert('tb_users', array_merge(array("id" => null),$data));
        log_query($this->db->last_query(), $this->db->insert_id());
        $error = $this->db->error();
        if($error['code'] != 0)
        {
            $response = array(
                "code" => 201,
                "msg"  => $this->lang->line("employees_username_duplicate")
            );
        }
        else
        {
            $id = $this->db->insert_id();
            if($akses != false)
            {
                $menu = array();
                foreach($akses as $row)
                {
                    array_push($menu,array("user" => $id,
                                    "menu" => $row));
                }
                $this->db->insert_batch('tb_akses', $menu);
            }
        }

        return $response;
    }

    function edit_user($data,$akses)
    {
        $this->db->where('id', $data['id']);
        $user = $this->db->get('tb_users');
        $response = array(
            "code" => 200,
            "msg"  => $this->lang->line("employees_successful_updating")
        );
        if($user->num_rows() == 1)
        {
            $this->db->where('id', $data['id']);
            $this->db->update('tb_users', $data);
            log_query($this->db->last_query());
            $this->db->where('user', $data['id']);
            $this->db->delete('tb_akses');
            log_query($this->db->last_query());
            if($akses != false)
            {
                $menu = array();
                foreach($akses as $row)
                {
                    array_push($menu,array("user" => $data['id'],
                                    "menu" => $row));
                }
                $this->db->insert_batch('tb_akses', $menu);
                log_query($this->db->last_query());
            }
        }
        else
        {
            $response = array(
                "code" => 201,
                "msg"  => $this->lang->line("employees_username_duplicate")
            );
        }
        return $response;
    }

    function get_user_id($id)
    {
        $this->db->where('id',$id);
        return $this->db->get('tb_users');
    }
    function get_akses_user($id)
    {

        $this->db->where('user',$id);
        return $this->db->get('tb_akses');
    }
    function user()
    {
        return $this->db->get('tb_users');
    }

    function get_user_all($where,$limit,$order)
    {
        $this->db->select("*");
		$this->db->from("tb_users u");
        $this->db->group_start();
        $this->db->where('IFNULL(company,0) != ', 'DEVELOPER');
        $this->db->group_end();
        $this->db->group_start();
        $this->db->not_like('company ', 'DEVELOPER');
		$this->db->or_like($where);
        $this->db->group_end();
		$this->db->limit($limit['limit'],$limit['start']);
		$this->db->order_by($order['field'],$order['dir']);		
		return $this->db->get();

    }

    function get_transaksi_user()
    {
        $this->db->select('u.id,sum(t.qty) AS "total_penjualan", SUM((t.harga -round(t.harga * IFNULL(t.diskon,0)/100))*t.qty) AS "pendapatan"');
        $this->db->join('tb_faktur f', 'f.kode_faktur = t.kode_transaksi', 'left');
        $this->db->join('tb_user u', 'u.id = f.karyawan', 'left');
        $this->db->join('tb_produk p', 'p.kode_item = t.kode_item', 'left');
        $this->db->group_by('u.id');
        return $this->db->get('tb_transaksi t');
        
    }

    function get_akses()
    {
        $this->db->join('tb_menu m', 'm.id_menu = a.menu', 'left');
        return $this->db->get('tb_akses a');
    }
    
    function menu_parent()
    {
        $this->db->where('parent',null);
        $this->db->order_by('posisi', 'asc');
        return $this->db->get('tb_menu');
    }
    function menu_child()
    {

        $this->db->where('parent !=', null);
        $this->db->order_by('posisi', 'asc');
        return $this->db->get('tb_menu');
    }

    function edit_password($data)
    {
        $response = array("code" => 200,
                          "msg"  => "Password baru berhasil disimpan");
        $this->db->where('id', $this->session->userdata('id'));
        $users = $this->db->get("tb_users")->row();
        if(password_verify($data['currentpassword'],$users->password))
        {
            $options = ['cost' => 5,
                        'salt' => mcrypt_create_iv(22, MCRYPT_DEV_URANDOM),
                        ];
            $this->db->where('id', $this->session->userdata('id'));
            $this->db->set('password', password($data['password'],$options));
            $this->db->update('tb_users');
            log_query($this->db->last_query());
            return $response;
            
        }
        $response = array("code" => 200,
                          "msg"  => "Password lama yang anda masukan salah silahkan ulangi kembali");
        return $response;


    }

    

}

/* End of file M_user.php */
?>