<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * The user name of the git hub user who owns the repo
 */
$config['github_user'] = 'jimdoescode';

/**
 * The repo on GitHub we will be updating from
 */
$config['github_repo'] = 'Test-Auto-Updater';

/**
 * The branch to update from
 */
$config['github_branch'] = 'master';

/**
 * The current commit the files are on.
 * 
 * NOTE: You should only need to set this initially it will be
 * automatically set by the library after subsequent updates.
 */
$config['current_commit'] = 'f96cdc59488f187d4e5d43d3f5a1e6d3311779a5';

/**
 * A list of files to never perform an update on
 */
$config['ignored_files'] = array('application/config/config.php',
                                 'application/config/github_updater.php',
                                 'application/libraries/Github_updater.php');

/**
 * Flag to indicate if the downloaded and extracted update files
 * should be removed
 */
$config['clean_update_files'] = true;